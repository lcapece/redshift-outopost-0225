# SVV Table Info Import Bug Report

## Issue Summary
Users are encountering errors when attempting to import SVV_TABLE_INFO data via clipboard paste, specifically related to null value constraints in the database.

## Environment Details
- **Browser**: Chrome 122.0.6261.112
- **Operating System**: Windows 11
- **Application Version**: 1.0.0
- **Timestamp**: March 4, 2025 16:45 UTC
- **User Role**: Authenticated

## Steps to Reproduce
1. Execute SVV_TABLE_INFO query in Redshift:
   ```sql
   SELECT * FROM svv_table_info;
   ```
2. Copy results from Redshift query tool
3. Navigate to Data Import page in application
4. Click "Import Data" button
5. Paste copied data into the import modal
6. Click "Import" button

## Expected Behavior
- Data should be validated and imported successfully
- Progress bar should show import progress
- Success message should be displayed upon completion

## Actual Behavior
- Error message displayed: "null value in column 'unsorted_pct' of relation 'imported_svv_data' violates not-null constraint"
- Import process fails
- No data is imported into the system

## Error Messages
```
Error importing SVV data: {
  "code": "23502",
  "details": {},
  "hint": {},
  "message": "null value in column \"unsorted_pct\" of relation \"imported_svv_data\" violates not-null constraint"
}
```

## Content Analysis
### Source Data Format
- Format: Pipe-delimited text
- Source Application: Redshift Query Editor
- Expected Columns: 17 (all SVV_TABLE_INFO columns)
- Actual Columns Present: 17
- Sample Row Count: ~500 rows

### Data Validation Issues
1. Null values present in required numeric columns
2. Empty string values being treated as nulls
3. Missing data type conversion for numeric fields

## Recent Changes
- Migration to new database schema (March 4, 2025)
- Addition of not-null constraints on numeric columns
- Implementation of staging table for data import

## Impact
- Users unable to import table metrics
- Blocking issue for database analysis features
- Affects all users attempting to import SVV_TABLE_INFO data

## Root Cause Analysis
1. SVV_TABLE_INFO can return NULL values for certain metrics
2. Application not properly handling NULL or empty string values
3. Database constraints too strict for real-world data
4. Missing data validation and transformation in import process

## Recommendations
1. Update data import service to handle NULL values:
   - Convert NULL/empty strings to appropriate default values (0 for numeric fields)
   - Add proper data type validation and conversion
   - Implement comprehensive error handling

2. Modify database schema:
   - Add default values for numeric columns
   - Consider allowing NULL values for certain metrics
   - Implement proper data validation at database level

3. Enhance user feedback:
   - Add detailed error messages
   - Show validation results before import
   - Provide data format requirements in UI

## Additional Notes
- Issue affects all table imports regardless of table size
- No workaround currently available
- High priority fix required due to blocking nature of issue

## Attachments
- Error logs
- Sample data causing the error
- Database schema definition
- Current validation rules

## Related Issues
- #123: Database schema migration
- #145: Data import validation
- #167: Error handling improvements

## Status
- **Priority**: High
- **Severity**: Blocking
- **Assigned To**: Database Team
- **Status**: Open