# News Collection and Generation System Documentation
Last Updated: March 15, 2025 16:45 UTC

## Active Collection Methods

### 1. AWS Official Sources
- **Type**: Web Scraper
- **Status**: Active
- **Frequency**: Every 6 hours
- **Source URLs**:
  - `https://aws.amazon.com/about-aws/whats-new/recent/redshift/` (What's New)
  - `https://aws.amazon.com/blogs/database/category/database/amazon-redshift/` (Database Blog)
  - `https://aws.amazon.com/blogs/big-data/tag/amazon-redshift/` (Big Data Blog)
- **Selector Configuration**:
  ```json
  {
    "whats_new": {
      "article_selector": ".lb-content-item",
      "title_selector": ".lb-title",
      "date_selector": ".lb-date"
    },
    "blog": {
      "article_selector": ".blog-post",
      "title_selector": ".blog-post-title",
      "date_selector": ".blog-post-date"
    }
  }
  ```

### 2. RSS Feeds
- **Type**: RSS Parser
- **Status**: Active
- **Frequency**: Every 4 hours
- **Feeds**:
  - AWS Database Blog RSS
  - AWS Big Data Blog RSS
  - AWS What's New RSS

### 3. Third-Party Content
- **Type**: API Integration
- **Status**: Inactive (Pending approval)
- **Providers**:
  - Perplexity API (Technical content enhancement)
  - OpenRouter API (Content summarization)

## Image Generation Workflow

### 1. Unsplash Integration
- **Service**: Unsplash API
- **Status**: Active
- **Configuration**:
  ```json
  {
    "accessKey": "cNEJcYhiXtNbTS6I5BSszHEuGkTAsWIxVc2Ut1ZaKYg",
    "searchParams": {
      "query": "aws redshift data warehouse",
      "perPage": 10,
      "orientation": "landscape"
    }
  }
  ```
- **Usage**: Primary and secondary article images
- **Storage**: External URLs only (no local storage)

### 2. Image Selection Process
1. Primary Image:
   - Search query: "aws redshift data warehouse"
   - Fallback query: "cloud database analytics"
   - Random selection from top 10 results

2. Secondary Image (for articles > 400 words):
   - Search query: "cloud database analytics"
   - Fallback query: "data technology"
   - Random selection excluding primary image

## Collection Schedule (UTC)

### Daily Schedule
| Time (UTC) | Task | Service |
|------------|------|---------|
| 00:00 | AWS What's New Scrape | Web Scraper |
| 02:00 | Database Blog Scrape | Web Scraper |
| 04:00 | Big Data Blog Scrape | Web Scraper |
| 06:00 | RSS Feed Collection | RSS Parser |
| 08:00 | Content Enhancement | Claude API |
| 10:00 | Image Generation | Unsplash API |
| 12:00 | Repeat Cycle | All Services |

### Retry Configuration
- Maximum attempts: 3
- Retry delay: 15 minutes
- Failure threshold: 3 consecutive failures

## Content Generation Pipeline

### 1. Article Processing
- Content extraction
- HTML cleaning
- Metadata extraction
- Related article detection

### 2. AI Enhancement (Claude 3.7 Sonnet)
- Technical accuracy verification
- Content expansion
- Summary generation
- Tag extraction

### 3. Publishing Flow
- Draft creation
- Image attachment
- Related article linking
- Publication scheduling

## Current System Status

### Last Successful Operations
- Article Collection: 2025-03-15 15:30 UTC
- Content Enhancement: 2025-03-15 15:45 UTC
- Image Generation: 2025-03-15 15:47 UTC
- Publication: 2025-03-15 16:00 UTC

### Error Log (Past 24 Hours)
```log
2025-03-15 14:15 UTC [WARNING] Rate limit approached for Unsplash API
2025-03-15 13:22 UTC [ERROR] Failed to scrape AWS Blog - 503 Service Unavailable
2025-03-15 13:23 UTC [INFO] Retry successful for AWS Blog scrape
2025-03-15 12:01 UTC [WARNING] High latency detected in content processing
```

### Service Status
| Service | Status | Last Check |
|---------|---------|------------|
| Web Scraper | Active | 16:00 UTC |
| RSS Parser | Active | 15:45 UTC |
| Claude API | Active | 15:50 UTC |
| Unsplash API | Active | 15:55 UTC |
| Content Pipeline | Active | 16:00 UTC |

### Queue Status
- Pending Collection: 0 items
- Pending Enhancement: 2 items
- Pending Images: 1 item
- Ready for Publication: 3 items

## Monitoring and Alerts

### Health Checks
- Collection Services: Every 5 minutes
- API Services: Every minute
- Content Pipeline: Every 15 minutes

### Alert Thresholds
- Collection Failure: 3 consecutive failures
- API Response Time: > 2000ms
- Queue Size: > 10 pending items
- Error Rate: > 5% of operations

### Current Alert Status
- No critical alerts active
- 1 warning: Unsplash API rate limit at 80%

## Recovery Procedures

### Service Failures
1. Automatic retry with exponential backoff
2. Fallback to secondary sources
3. Manual intervention if required

### Data Recovery
- Real-time backup to Supabase
- Point-in-time recovery available
- 30-day retention period

## Performance Metrics

### Collection Success Rate (24h)
- Web Scraper: 98.5%
- RSS Parser: 100%
- API Integration: 99.7%

### Processing Times (Average)
- Article Collection: 2.3s
- Content Enhancement: 4.5s
- Image Generation: 1.2s
- Total Pipeline: 8.0s

### Resource Utilization
- API Quota Usage: 65%
- Storage Usage: 42%
- Processing Queue: 15% capacity

## Maintenance Windows

### Scheduled Maintenance
- Daily: 22:00-22:30 UTC (Index optimization)
- Weekly: Sunday 02:00-03:00 UTC (Full system maintenance)
- Monthly: First Sunday 04:00-06:00 UTC (Database optimization)

### Emergency Maintenance
- Unplanned maintenance requires:
  - 2 team member approval
  - Incident report creation
  - Status page update