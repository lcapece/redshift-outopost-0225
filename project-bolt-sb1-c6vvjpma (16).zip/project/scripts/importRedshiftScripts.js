import { createClient } from '@supabase/supabase-js';
import axios from 'axios';
import * as cheerio from 'cheerio';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

// Load environment variables
dotenv.config();

// Initialize Supabase client
const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// GitHub repository information
const GITHUB_REPO = 'awslabs/amazon-redshift-utils';
const SCRIPTS_PATH = 'src/AdminScripts';
const GITHUB_API_URL = `https://api.github.com/repos/${GITHUB_REPO}/contents/${SCRIPTS_PATH}`;
const RAW_CONTENT_BASE_URL = `https://raw.githubusercontent.com/${GITHUB_REPO}/master/${SCRIPTS_PATH}`;

// Function to format SQL script content with syntax highlighting
function formatSqlScript(content) {
  // This is a simple formatter that adds HTML classes for syntax highlighting
  
  // Replace SQL keywords with highlighted spans
  const keywords = [
    'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'ON',
    'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET', 'UNION', 'ALL',
    'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP', 'TABLE', 'VIEW',
    'INDEX', 'CONSTRAINT', 'PRIMARY', 'FOREIGN', 'KEY', 'REFERENCES',
    'AS', 'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS', 'NULL',
    'TRUE', 'FALSE', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT',
    'COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'WITH'
  ];
  
  let formattedContent = content;
  
  // Replace SQL keywords with spans
  keywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    formattedContent = formattedContent.replace(regex, `<span class="text-blue-600 font-bold">$&</span>`);
  });
  
  // Replace strings with spans
  formattedContent = formattedContent.replace(/'([^']*)'/g, `<span class="text-green-600">'$1'</span>`);
  
  // Replace numbers with spans
  formattedContent = formattedContent.replace(/\b(\d+)\b/g, `<span class="text-purple-600">$1</span>`);
  
  // Replace comments with spans
  formattedContent = formattedContent.replace(/--([^\n]*)/g, `<span class="text-gray-500">--$1</span>`);
  
  // Replace multi-line comments with spans
  formattedContent = formattedContent.replace(/\/\*([\s\S]*?)\*\//g, `<span class="text-gray-500">/*$1*/</span>`);
  
  // Add line numbers and wrap in pre tag
  const lines = formattedContent.split('\n');
  formattedContent = lines.map((line, index) => {
    return `<div class="flex"><span class="text-gray-400 w-10 text-right pr-4 select-none">${index + 1}</span><span>${line}</span></div>`;
  }).join('\n');
  
  return `<pre class="bg-gray-50 p-4 rounded-lg overflow-x-auto text-sm font-mono">${formattedContent}</pre>`;
}

// Function to extract description from SQL script content
function extractDescriptionFromContent(content) {
  // Look for comments at the beginning of the file
  const commentRegex = /^--\s*(.*?)$/m;
  const multilineCommentRegex = /\/\*([\s\S]*?)\*\//;
  
  let description = '';
  
  // Try to find single-line comments at the beginning
  const lines = content.split('\n').slice(0, 10); // Look at first 10 lines
  for (const line of lines) {
    const match = line.match(commentRegex);
    if (match && match[1].trim()) {
      if (!description) {
        description = match[1].trim();
      } else {
        description += ' ' + match[1].trim();
      }
    } else if (line.trim() && !line.trim().startsWith('--')) {
      // Stop when we hit a non-comment line
      break;
    }
  }
  
  // If no description found, try multiline comments
  if (!description) {
    const multilineMatch = content.match(multilineCommentRegex);
    if (multilineMatch) {
      description = multilineMatch[1].trim()
        .replace(/\n\s*\*/g, ' ') // Remove * from each line
        .replace(/\s+/g, ' '); // Normalize whitespace
    }
  }
  
  // If still no description, generate one based on the filename
  if (!description) {
    return null;
  }
  
  return description;
}

// Function to determine script type based on file extension and content
function determineScriptType(filename, content) {
  const extension = path.extname(filename).toLowerCase();
  
  if (extension === '.sql') {
    // Check if it contains PL/pgSQL specific syntax
    if (content.includes('BEGIN') && content.includes('END;') && 
        (content.includes('DECLARE') || content.includes('FUNCTION') || content.includes('PROCEDURE'))) {
      return 'PL/pgSQL';
    }
    return 'SQL';
  } else if (extension === '.py') {
    return 'Python';
  } else if (extension === '.sh') {
    return 'Shell';
  } else {
    return 'Other';
  }
}

// Function to determine script category based on content and filename
function determineCategory(filename, content, description) {
  const lowerContent = content.toLowerCase();
  const lowerFilename = filename.toLowerCase();
  const lowerDescription = description ? description.toLowerCase() : '';
  
  // Check for monitoring scripts
  if (lowerContent.includes('stl_alert') || 
      lowerContent.includes('svv_table_info') || 
      lowerContent.includes('pg_stat') ||
      lowerFilename.includes('monitor') ||
      lowerDescription.includes('monitor')) {
    return 'Monitoring';
  }
  
  // Check for security scripts
  if (lowerContent.includes('grant') || 
      lowerContent.includes('revoke') || 
      lowerContent.includes('permission') ||
      lowerContent.includes('privilege') ||
      lowerFilename.includes('user') ||
      lowerFilename.includes('permission') ||
      lowerFilename.includes('priv') ||
      lowerDescription.includes('security') ||
      lowerDescription.includes('permission') ||
      lowerDescription.includes('privilege')) {
    return 'Security';
  }
  
  // Check for optimization scripts
  if (lowerContent.includes('vacuum') || 
      lowerContent.includes('analyze') || 
      lowerContent.includes('performance') ||
      lowerFilename.includes('perf') ||
      lowerFilename.includes('optim') ||
      lowerDescription.includes('performance') ||
      lowerDescription.includes('optimize')) {
    return 'Optimization';
  }
  
  // Check for maintenance scripts
  if (lowerContent.includes('vacuum') || 
      lowerContent.includes('maintenance') ||
      lowerFilename.includes('maint') ||
      lowerDescription.includes('maintenance')) {
    return 'Maintenance';
  }
  
  // Check for diagnostic scripts
  if (lowerContent.includes('stl_error') || 
      lowerContent.includes('svl_qlog') ||
      lowerFilename.includes('diag') ||
      lowerFilename.includes('error') ||
      lowerDescription.includes('diagnos') ||
      lowerDescription.includes('troubleshoot')) {
    return 'Diagnostics';
  }
  
  // Default to DBA Helper Queries
  return 'DBA Helper Queries';
}

// Function to extract tags from content and filename
function extractTags(filename, content, description) {
  const tags = new Set();
  const lowerContent = content.toLowerCase();
  const lowerFilename = filename.toLowerCase();
  const lowerDescription = description ? description.toLowerCase() : '';
  
  // Add tag based on script type
  const scriptType = determineScriptType(filename, content);
  tags.add(scriptType.toLowerCase());
  
  // Check for common Redshift concepts
  if (lowerContent.includes('vacuum')) tags.add('vacuum');
  if (lowerContent.includes('analyze')) tags.add('analyze');
  if (lowerContent.includes('wlm') || lowerContent.includes('workload management')) tags.add('wlm');
  if (lowerContent.includes('table') && lowerContent.includes('info')) tags.add('table-info');
  if (lowerContent.includes('permission') || lowerContent.includes('grant') || lowerContent.includes('privilege')) tags.add('permissions');
  if (lowerContent.includes('performance')) tags.add('performance');
  if (lowerContent.includes('monitoring')) tags.add('monitoring');
  if (lowerContent.includes('maintenance')) tags.add('maintenance');
  
  // Add tag based on filename
  const filenameWithoutExt = path.basename(filename, path.extname(filename));
  if (filenameWithoutExt.includes('_')) {
    filenameWithoutExt.split('_').forEach(part => {
      if (part.length > 3) { // Only add meaningful parts
        tags.add(part.toLowerCase());
      }
    });
  }
  
  // Limit to 5 tags
  return Array.from(tags).slice(0, 5);
}

// Main function to import scripts
async function importScripts() {
  console.log('Starting import of Redshift scripts from GitHub...');
  
  try {
    // Fetch the list of files in the repository
    const response = await axios.get(GITHUB_API_URL);
    const files = response.data.filter(file => file.type === 'file' && file.name.endsWith('.sql'));
    
    console.log(`Found ${files.length} SQL scripts to import`);
    
    // Process each file
    for (const file of files) {
      try {
        console.log(`Processing ${file.name}...`);
        
        // Check if script already exists
        const { data: existingScript, error: checkError } = await supabase
          .from('redshift_scripts')
          .select('id')
          .eq('title', file.name)
          .maybeSingle();
        
        if (checkError) {
          console.error(`Error checking for existing script ${file.name}:`, checkError);
          continue;
        }
        
        if (existingScript) {
          console.log(`Script ${file.name} already exists, skipping`);
          continue;
        }
        
        // Fetch the raw content of the file
        const contentResponse = await axios.get(`${RAW_CONTENT_BASE_URL}/${file.name}`);
        const scriptContent = contentResponse.data;
        
        // Extract description from content
        let description = extractDescriptionFromContent(scriptContent);
        if (!description) {
          // Generate a description based on the filename
          const filenameWithoutExt = path.basename(file.name, path.extname(file.name));
          description = filenameWithoutExt
            .replace(/_/g, ' ')
            .replace(/([A-Z])/g, ' $1')
            .replace(/\s+/g, ' ')
            .trim();
          
          // Capitalize first letter
          description = description.charAt(0).toUpperCase() + description.slice(1);
          
          // Add a generic description
          description = `${description} - A utility script for Amazon Redshift database administration.`;
        }
        
        // Determine script type
        const scriptType = determineScriptType(file.name, scriptContent);
        
        // Determine category
        const category = determineCategory(file.name, scriptContent, description);
        
        // Extract tags
        const tags = extractTags(file.name, scriptContent, description);
        
        // Format the script content
        const formattedContent = formatSqlScript(scriptContent);
        
        // Create the script object
        const script = {
          id: uuidv4(),
          title: file.name,
          description,
          script_content: scriptContent,
          original_url: file.html_url,
          category,
          script_type: scriptType,
          published_at: new Date().toISOString().split('T')[0],
          tags,
          formatted_content: formattedContent,
          author: 'AWS',
          status: 'published'
        };
        
        // Insert the script into the database
        const { error: insertError } = await supabase
          .from('redshift_scripts')
          .insert(script);
        
        if (insertError) {
          console.error(`Error inserting script ${file.name}:`, insertError);
          continue;
        }
        
        console.log(`Successfully imported ${file.name}`);
        
        // Add a small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
      }
    }
    
    console.log('Import completed successfully!');
  } catch (error) {
    console.error('Error fetching repository contents:', error);
  }
}

// Run the import
importScripts()
  .then(() => console.log('Script import process completed'))
  .catch(error => console.error('Error in import process:', error));