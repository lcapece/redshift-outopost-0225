export interface ScriptSource {
  id: string;
  url: string;
  description: string;
  type: 'github' | 'webpage' | 'api' | 'other';
  priority: 'high' | 'medium' | 'low';
  enabled: boolean;
  lastScraped: string | null;
  scrapeFrequency: number; // in hours
  status: 'pending' | 'completed' | 'failed';
  errorMessage?: string;
  metadata?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface ScriptContent {
  id: string;
  sourceId: string;
  title: string;
  content: string;
  language: 'sql' | 'python' | 'shell' | 'other';
  description: string;
  tags: string[];
  version: number;
  extractedAt: string;
  status: 'pending_validation' | 'validated' | 'invalid';
  metadata?: Record<string, any>;
  createdAt: string;
  updatedAt: string;
}

export interface ScriptVersion {
  id: string;
  scriptId: string;
  content: string;
  version: number;
  changedBy: string;
  changeReason?: string;
  createdAt: string;
}

export interface ScrapeLog {
  id: string;
  sourceId: string;
  startTime: string;
  endTime: string | null;
  status: 'in_progress' | 'completed' | 'failed';
  scriptsFound: number;
  scriptsExtracted: number;
  scriptsUpdated: number;
  errorMessage?: string;
  metadata?: Record<string, any>;
  createdAt: string;
}

export interface ScriptStats {
  totalSources: number;
  activeSources: number;
  totalScripts: number;
  scriptsByLanguage: Record<string, number>;
  scriptsByStatus: Record<string, number>;
  lastScraped: string | null;
  scrapesInLast24Hours: number;
  scrapesInLast7Days: number;
  failedScrapes: number;
}