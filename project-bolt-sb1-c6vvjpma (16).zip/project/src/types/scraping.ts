export interface ScrapeUrl {
  url: string;
  dateAdded: Date;
  lastScrapeDate: Date | null;
  nextScheduledScrape: Date | null;
  status: 'pending' | 'success' | 'failed';
  comments: string;
  active: boolean;
  deletedAt: Date | null;
  createdBy: string;
  updatedBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ScrapeUrlWithStats extends ScrapeUrl {
  totalScrapes: number;
  successfulScrapes: number;
  failedScrapes: number;
  maxItemsFound: number;
  avgItemsFound: number;
  maxPagesScrapes: number;
  avgScrapeDurationSeconds: number;
}

export interface ScrapeAuditLog {
  id: string;
  url: string;
  action: string;
  changes: any;
  performedBy: string;
  performedAt: Date;
}

export interface ScrapeHistory {
  id: string;
  url: string;
  startTime: Date;
  endTime: Date | null;
  status: 'pending' | 'success' | 'failed';
  errorMessage: string | null;
  pagesScrapes: number;
  itemsFound: number;
  createdAt: Date;
}

export interface ScrapeUrlFilters {
  status?: 'pending' | 'success' | 'failed';
  active?: boolean;
  dateRange?: {
    start: Date;
    end: Date;
  };
  search?: string;
}

export interface ScrapeUrlSort {
  field: keyof ScrapeUrl | keyof ScrapeUrlWithStats;
  direction: 'asc' | 'desc';
}

export interface ScrapeUrlPagination {
  page: number;
  pageSize: number;
  total: number;
}