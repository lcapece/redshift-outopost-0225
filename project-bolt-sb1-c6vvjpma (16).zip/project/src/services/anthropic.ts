import axios from 'axios';

interface AnthropicResponse {
  content: Array<{
    type: string;
    text?: string;
    source?: {
      type: string;
      media_type: string;
      data: string;
    };
  }>;
}

export async function generateMermaidWithClaude(queryPlan: string): Promise<{ svg: string; mermaidScript: string }> {
  try {
    const apiKey = import.meta.env.VITE_CLAUDE_API_KEY || 'sk-ant-api03-ZGxQZXJzb25hbGl0eV9Qcm9tcHRfVGVtcGxhdGVfVmVyc2lvbgAAAAAA';
    
    if (!apiKey) {
      throw new Error('Claude API token is not configured. Please check your environment variables.');
    }

    const response = await axios.post<AnthropicResponse>(
      'https://api.anthropic.com/v1/messages',
      {
        model: "claude-3-7-sonnet-20240620",
        max_tokens: 4096,
        temperature: 0.2,
        system: "You are an expert at creating Mermaid diagrams from SQL execution plans. Your task is to create a clear, accurate visualization of the execution plan.",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Generate a Mermaid diagram to represent this SQL execution plan. The diagram should follow these guidelines:

Flow: The diagram should be read from bottom to top, reflecting the execution order of the plan.
Shapes: Use different shapes for different node types:
- Hash Join: Parallelogram (e.g., [/Hash Join/])
- Hash Aggregate: Double-braced shape (e.g., {{Hash Aggregate}})
- Sort: Diamond (e.g., {Sort})
- Other nodes: Standard rectangle ([Seq Scan])

Cost and Colors:
Categorize the relative cost of each step as LOW, MEDIUM, HIGH, or HIGHEST.
Use corresponding colors for the nodes:
- LOW: Green (#90EE90)
- MEDIUM: Yellow (#FFFFE0)
- HIGH: Amber (#FFBF00)
- HIGHEST: Red (#FF6347)

Details:
- For Seq Scan nodes, include the table name, alias (if any), and the filter predicate.
- For Hash Join nodes, show the join condition and the tables being joined.
- For Hash nodes, indicate the field being hashed.
- For Aggregate nodes, show the grouping and aggregate functions.
- For Sort nodes, show the sort order.
- For Filter nodes, show the filter condition.

Join Visualization:
- Clearly illustrate the left and right sides of the joins.
- Add explicit Hash nodes before each Hash Join to show the hash operations.
- Use arrows to show the flow of data from the scans to the hashes and then to the joins.

IMPORTANT: 
1. Express costs as LOW, MEDIUM, HIGH, HIGHEST in relative terms
2. Express row counts as K, M, B (e.g., 1.7K, 2.7M, 23B)
3. CRITICAL: Use ONLY flowchart TD syntax, not graph BT or any other syntax
4. CRITICAL: Do not use subgraph syntax unless you're 100% sure it's correct
5. CRITICAL: Ensure all node IDs are simple alphanumeric strings without hyphens
6. CRITICAL: Avoid any syntax that might cause parsing errors
7. CRITICAL: For node labels with multiple lines, use <br> for line breaks, not newlines
8. CRITICAL: For Sort Key, Hash Cond, and other details, escape any special characters and use proper syntax
9. CRITICAL: Do not include colons or other special characters in node text that might break the syntax
10. CRITICAL: Use simple quotes for text with special characters, e.g., ["Text with special chars"]
11. CRITICAL: Avoid using parentheses in node text unless properly escaped

Here is the SQL execution plan:

${queryPlan}

First, create the Mermaid diagram code. Then, render the diagram as an SVG image and include it in your response.`
              }
            ]
          }
        ]
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        }
      }
    );

    // Extract the Mermaid script and SVG from the response
    let mermaidScript = '';
    let svgContent = '';

    for (const content of response.data.content) {
      if (content.type === 'text' && content.text) {
        // Extract Mermaid script from text content
        const mermaidMatch = content.text.match(/```mermaid\s*([\s\S]*?)\s*```/);
        if (mermaidMatch && mermaidMatch[1]) {
          mermaidScript = mermaidMatch[1].trim();
        }
      } else if (content.type === 'image' && content.source?.media_type === 'image/svg+xml') {
        // Extract SVG content
        svgContent = atob(content.source.data);
      }
    }

    if (!mermaidScript) {
      throw new Error('No Mermaid script found in Claude response');
    }

    if (!svgContent) {
      // If no SVG was returned, create a placeholder SVG
      svgContent = `
        <svg width="500" height="200" xmlns="http://www.w3.org/2000/svg">
          <rect width="100%" height="100%" fill="#f8f9fa" rx="10" ry="10" />
          <text x="50%" y="40%" font-family="Arial" font-size="16" fill="#6c757d" text-anchor="middle">
            Mermaid diagram rendering unavailable
          </text>
          <text x="50%" y="60%" font-family="Arial" font-size="14" fill="#6c757d" text-anchor="middle">
            Using text representation instead
          </text>
        </svg>
      `;
    }

    // Sanitize the Mermaid script
    mermaidScript = sanitizeMermaidScript(mermaidScript);

    return {
      svg: svgContent,
      mermaidScript: mermaidScript
    };
  } catch (error) {
    console.error('Error generating Mermaid with Claude:', error);
    
    if (axios.isAxiosError(error)) {
      const errorMessage = error.response?.data?.error?.message || error.message;
      throw new Error(`Claude API Error: ${errorMessage}`);
    }
    
    throw error;
  }
}

function sanitizeMermaidScript(script: string): string {
  return script
    // Ensure flowchart TD is used, not graph BT
    .replace(/graph\s+BT/g, 'flowchart TD')
    .replace(/graph\s+TD/g, 'flowchart TD')
    // Fix node IDs with hyphens
    .replace(/([A-Za-z0-9_]+)-([A-Za-z0-9_]+)/g, '$1_$2')
    // Fix subgraph syntax if needed
    .replace(/subgraph\s+([^"\n]+)$/gm, (match, title) => {
      if (title.includes('"')) return match;
      return `subgraph "${title}"`;
    })
    // Fix class definitions
    .replace(/classDef\s+([A-Za-z0-9_-]+)\s+([^"\n]+)$/gm, (match, className, style) => {
      if (style.includes('"')) return match;
      return `classDef ${className} "${style}"`;
    })
    // Fix Sort Key syntax issues
    .replace(/Sort Key: ([^\n<]+)/g, 'Sort Key $1')
    // Fix Hash Cond syntax issues
    .replace(/Hash Cond: ([^\n<]+)/g, 'Hash Cond $1')
    // Fix Filter syntax issues
    .replace(/Filter: ([^\n<]+)/g, 'Filter $1')
    // Replace any remaining colons in node text with spaces or dashes
    .replace(/([\w\s]+):([\w\s]+)/g, '$1 - $2')
    // Ensure proper line breaks in node labels
    .replace(/\n\s+/g, '<br>')
    // Remove any remaining graph BT or other invalid directives
    .replace(/graph\s+[A-Z]{2}\s+/g, '')
    // Fix arrow syntax
    .replace(/-->/g, ' --> ')
    // Fix node labels with problematic characters
    .replace(/\[(.*?):(.*?)\]/g, '["$1 - $2"]')
    .replace(/\{(.*?):(.*?)\}/g, '{"$1 - $2"}')
    .replace(/\{\{(.*?):(.*?)\}\}/g, '{{"$1 - $2"}}')
    // Fix parentheses in node text
    .replace(/\(([^)]*)\)/g, (match, content) => {
      // Don't replace if it's part of a node shape definition
      if (match.startsWith('((') || match.endsWith('))')) return match;
      return content.replace(/[()]/g, '');
    });
}