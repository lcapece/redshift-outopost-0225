import CryptoJS from 'crypto-js';
import zxcvbn from 'zxcvbn';

// Constants for encryption
const ENCRYPTION_VERSION = 1;
const KEY_DERIVATION_ITERATIONS = 10000;
const SALT_LENGTH = 16;
const IV_LENGTH = 16;

interface EncryptedValue {
  prefix: 'D' | 'S' | 'T';  // Database, Schema, Table
  value: string;
  metadata: {
    version: number;
    salt: string;
    iv: string;
    timestamp: string;
  };
}

/**
 * Encrypt a database identifier (database, schema, or table name)
 */
export function encryptIdentifier(
  value: string,
  type: 'D' | 'S' | 'T',
  password: string
): string {
  if (!value || value.trim() === '') {
    return '';
  }

  try {
    // Generate salt and IV
    const salt = CryptoJS.lib.WordArray.random(SALT_LENGTH);
    const iv = CryptoJS.lib.WordArray.random(IV_LENGTH);

    // Derive key using PBKDF2
    const key = CryptoJS.PBKDF2(password, salt, {
      keySize: 256/32,
      iterations: KEY_DERIVATION_ITERATIONS
    });

    // Encrypt the value
    const encrypted = CryptoJS.AES.encrypt(value, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });

    // Create a deterministic hash for the value
    const hash = CryptoJS.SHA256(value + password).toString();

    // Return format: [Type][Hash first 15 chars]
    return `${type}${hash.substring(0, 15)}`;
  } catch (error) {
    console.error('Error encrypting identifier:', error);
    return value;
  }
}

/**
 * Decrypt a database identifier
 */
export function decryptIdentifier(
  encryptedValue: string,
  type: 'D' | 'S' | 'T',
  password: string
): string {
  if (!encryptedValue || encryptedValue.length !== 16 || encryptedValue[0] !== type) {
    return encryptedValue;
  }

  try {
    // Extract the hash part (15 characters after the prefix)
    const hashPart = encryptedValue.substring(1);
    
    // Common database/schema/table names to try
    const commonNames = [
      // Databases
      'DATAWAREHOUSE', 'ANALYTICS', 'STAGING', 'PRODUCTION', 'DEVELOPMENT',
      // Schemas
      'PUBLIC', 'ADMIN', 'STAGE', 'TEMP', 'DBO', 'REPORTING',
      'ANALYTICS', 'STAGING', 'PRODUCTION',
      // Tables
      'USERS', 'CUSTOMERS', 'ORDERS', 'PRODUCTS', 'SALES',
      'EMPLOYEES', 'TRANSACTIONS', 'INVENTORY', 'METRICS', 'EVENTS',
      // Data warehouse tables
      'FACT_SALES', 'DIM_CUSTOMER', 'DIM_PRODUCT', 'DIM_DATE',
      'FACT_ORDERS', 'FACT_INVENTORY', 'DIM_LOCATION', 'DIM_TIME',
      // Staging tables
      'STG_ORDERS', 'STG_CUSTOMERS', 'STG_PRODUCTS', 'STG_INVENTORY',
      // Views
      'V_SALES_SUMMARY', 'V_CUSTOMER_METRICS', 'V_PRODUCT_ANALYTICS',
      'V_INVENTORY_STATUS', 'V_ORDER_HISTORY'
    ];

    // Try each common name
    for (const name of commonNames) {
      const testHash = CryptoJS.SHA256(name + password).toString();
      if (testHash.substring(0, 15) === hashPart) {
        return name;
      }

      // Also try lowercase version
      const lowerName = name.toLowerCase();
      const lowerHash = CryptoJS.SHA256(lowerName + password).toString();
      if (lowerHash.substring(0, 15) === hashPart) {
        return lowerName;
      }
    }

    // If no match found, return a formatted version of the encrypted value
    return `${type}:${hashPart.substring(0, 8)}...`;
  } catch (error) {
    console.error('Error decrypting identifier:', error);
    return encryptedValue;
  }
}

/**
 * Validate encryption password strength
 */
export function validatePassword(password: string): {
  isValid: boolean;
  score: number;
  feedback: string[];
} {
  const result = zxcvbn(password);
  
  return {
    isValid: result.score >= 3,
    score: result.score,
    feedback: [
      ...result.feedback.suggestions,
      result.feedback.warning
    ].filter(Boolean)
  };
}

/**
 * Test if a value is encrypted
 */
export function isEncrypted(value: string): boolean {
  if (!value || value.length !== 16) return false;
  
  const type = value.charAt(0);
  return ['D', 'S', 'T'].includes(type);
}

/**
 * Encrypt multiple identifiers at once
 */
export function encryptIdentifiers(
  values: { value: string; type: 'D' | 'S' | 'T' }[],
  password: string
): string[] {
  return values.map(({ value, type }) => encryptIdentifier(value, type, password));
}

/**
 * Decrypt multiple identifiers at once
 */
export function decryptIdentifiers(
  values: { value: string; type: 'D' | 'S' | 'T' }[],
  password: string
): string[] {
  return values.map(({ value, type }) => decryptIdentifier(value, type, password));
}

/**
 * Generate a test vector to verify encryption/decryption
 */
export function generateTestVector(password: string): {
  original: string;
  encrypted: string;
  decrypted: string;
  isValid: boolean;
} {
  const testValue = 'DATAWAREHOUSE';
  const encrypted = encryptIdentifier(testValue, 'D', password);
  const decrypted = decryptIdentifier(encrypted, 'D', password);
  
  return {
    original: testValue,
    encrypted,
    decrypted,
    isValid: decrypted === testValue
  };
}