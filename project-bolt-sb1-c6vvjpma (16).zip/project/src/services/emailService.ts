// This is a mock email service that would be replaced with actual email sending logic
// In a real implementation, this would be a server-side service

import { EmailVerificationTemplate, PasswordResetTemplate } from '../components/EmailTemplate';

interface SendEmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

interface VerificationEmailOptions {
  email: string;
  name?: string;
  verificationUrl: string;
}

interface PasswordResetEmailOptions {
  email: string;
  name?: string;
  resetUrl: string;
}

/**
 * Mock function to send an email
 * In a real implementation, this would use a service like SendGrid, Mailgun, etc.
 */
export async function sendEmail({ to, subject, html, text }: SendEmailOptions): Promise<boolean> {
  console.log(`[MOCK EMAIL SERVICE] Sending email to ${to}`);
  console.log(`Subject: ${subject}`);
  console.log(`HTML Content: ${html.substring(0, 100)}...`);
  
  // In a real implementation, this would call an email service API
  // For now, we'll just simulate a successful send
  return true;
}

/**
 * Send a verification email
 */
export async function sendVerificationEmail({ email, name, verificationUrl }: VerificationEmailOptions): Promise<boolean> {
  // In a real implementation, we would render the email template server-side
  // For this mock, we'll just convert the React component to a string
  const emailTemplate = EmailVerificationTemplate({ verificationUrl, recipientName: name });
  const htmlContent = JSON.stringify(emailTemplate);
  
  // Create a plain text version
  const textContent = `
    Redshift Outpost - Verify Your Email Address
    
    Hi ${name || 'there'},
    
    Thanks for signing up for Redshift Outpost! Please verify your email address by clicking the link below:
    
    ${verificationUrl}
    
    This verification link will expire in 24 hours. If you did not create an account, you can safely ignore this email.
    
    © 2025 Redshift Outpost. All rights reserved.
    Spaceship.com, Inc. • 123 Galactic Way • Universe City, Space 12345
  `;
  
  return sendEmail({
    to: email,
    subject: 'Verify Your Email Address - Redshift Outpost',
    html: htmlContent,
    text: textContent
  });
}

/**
 * Send a password reset email
 */
export async function sendPasswordResetEmail({ email, name, resetUrl }: PasswordResetEmailOptions): Promise<boolean> {
  // In a real implementation, we would render the email template server-side
  // For this mock, we'll just convert the React component to a string
  const emailTemplate = PasswordResetTemplate({ verificationUrl: resetUrl, recipientName: name });
  const htmlContent = JSON.stringify(emailTemplate);
  
  // Create a plain text version
  const textContent = `
    Redshift Outpost - Reset Your Password
    
    Hi ${name || 'there'},
    
    We received a request to reset your password for your Redshift Outpost account. Click the link below to reset your password:
    
    ${resetUrl}
    
    This password reset link will expire in 1 hour. If you did not request a password reset, you can safely ignore this email.
    
    © 2025 Redshift Outpost. All rights reserved.
    Spaceship.com, Inc. • 123 Galactic Way • Universe City, Space 12345
  `;
  
  return sendEmail({
    to: email,
    subject: 'Reset Your Password - Redshift Outpost',
    html: htmlContent,
    text: textContent
  });
}