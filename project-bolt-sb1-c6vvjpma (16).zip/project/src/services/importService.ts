import { createClient } from '@supabase/supabase-js';
import CryptoJS from 'crypto-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL || '',
  import.meta.env.VITE_SUPABASE_ANON_KEY || ''
);

interface ImportData {
  database_name: string;
  schema_name: string;
  table_name: string;
  [key: string]: any;
}

export async function validateImportData(
  data: string,
  delimiter: string,
  textQualifier: string
): Promise<{ isValid: boolean; errors: string[]; preview: any[] | null }> {
  try {
    const lines = data.trim().split('\n');
    if (lines.length < 2) {
      return {
        isValid: false,
        errors: ['Data must contain at least a header row and one data row'],
        preview: null
      };
    }

    // Parse header row
    const headers = parseRow(lines[0], delimiter, textQualifier);
    const requiredColumns = [
      'database_name',
      'schema_name',
      'table_name',
      'encoded',
      'diststyle',
      'sortkey1',
      'size',
      'pct_used',
      'unsorted',
      'stats_off'
    ];

    const missingColumns = requiredColumns.filter(
      col => !headers.map(h => h.toLowerCase()).includes(col.toLowerCase())
    );

    if (missingColumns.length > 0) {
      return {
        isValid: false,
        errors: [`Missing required columns: ${missingColumns.join(', ')}`],
        preview: null
      };
    }

    // Parse and validate data rows
    const parsedData = [];
    const errors = [];

    for (let i = 1; i < Math.min(lines.length, 4); i++) {
      const row = parseRow(lines[i], delimiter, textQualifier);
      if (row.length !== headers.length) {
        errors.push(`Row ${i + 1}: Column count mismatch`);
        continue;
      }

      const rowData: Record<string, any> = {};
      headers.forEach((header, index) => {
        rowData[header] = row[index];
      });

      parsedData.push(rowData);
    }

    return {
      isValid: errors.length === 0,
      errors,
      preview: parsedData
    };
  } catch (error) {
    return {
      isValid: false,
      errors: ['Failed to parse data: ' + (error as Error).message],
      preview: null
    };
  }
}

export async function encryptData(data: string, password: string): Promise<string> {
  try {
    // Generate a random salt
    const salt = CryptoJS.lib.WordArray.random(128 / 8);
    
    // Derive a key using PBKDF2
    const key = CryptoJS.PBKDF2(password, salt, {
      keySize: 256 / 32,
      iterations: 10000
    });
    
    // Generate a random IV
    const iv = CryptoJS.lib.WordArray.random(128 / 8);
    
    // Encrypt the data
    const encrypted = CryptoJS.AES.encrypt(data, key, {
      iv: iv,
      padding: CryptoJS.pad.Pkcs7,
      mode: CryptoJS.mode.CBC
    });
    
    // Combine the salt, IV, and encrypted data
    const result = salt.toString() + iv.toString() + encrypted.toString();
    
    return result;
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

export async function decryptData(encryptedData: string, password: string): Promise<string> {
  try {
    // Extract the salt, IV, and encrypted data
    const salt = CryptoJS.enc.Hex.parse(encryptedData.substr(0, 32));
    const iv = CryptoJS.enc.Hex.parse(encryptedData.substr(32, 32));
    const encrypted = encryptedData.substring(64);
    
    // Derive the key using PBKDF2
    const key = CryptoJS.PBKDF2(password, salt, {
      keySize: 256 / 32,
      iterations: 10000
    });
    
    // Decrypt the data
    const decrypted = CryptoJS.AES.decrypt(encrypted, key, {
      iv: iv,
      padding: CryptoJS.pad.Pkcs7,
      mode: CryptoJS.mode.CBC
    });
    
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data. Invalid password or corrupted data.');
  }
}

function parseRow(row: string, delimiter: string, textQualifier: string): string[] {
  if (!textQualifier) {
    return row.split(delimiter).map(field => field.trim());
  }

  const fields: string[] = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    
    if (char === textQualifier) {
      if (inQuotes && row[i + 1] === textQualifier) {
        field += char;
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === delimiter && !inQuotes) {
      fields.push(field.trim());
      field = '';
    } else {
      field += char;
    }
  }
  
  fields.push(field.trim());
  return fields;
}

export async function storeImportedData(data: ImportData[]): Promise<void> {
  try {
    const { error } = await supabase
      .from('imported_svv_data')
      .insert(data);

    if (error) throw error;
  } catch (error) {
    console.error('Error storing imported data:', error);
    throw new Error('Failed to store imported data');
  }
}