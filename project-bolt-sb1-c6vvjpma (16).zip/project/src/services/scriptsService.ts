import { supabase } from './supabase';
import { v4 as uuidv4 } from 'uuid';

export interface RedshiftScript {
  id: string;
  title: string;
  description: string;
  script_content: string;
  original_url: string | null;
  category: string;
  script_type: string;
  published_at: string;
  created_at: string;
  updated_at: string;
  tags: string[] | null;
  formatted_content: string | null;
  author: string | null;
  views: number;
  downloads: number;
  status: string;
  average_rating?: number;
  rating_count?: number;
  comment_count?: number;
}

export interface ScriptComment {
  id: string;
  script_id: string;
  user_id: string;
  user_email: string;
  comment: string;
  created_at: string;
}

// Function to create a new script
export async function createScript(script: Omit<RedshiftScript, 'id' | 'created_at' | 'updated_at' | 'views' | 'downloads'>): Promise<RedshiftScript | null> {
  try {
    const newScript = {
      id: uuidv4(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      views: 0,
      downloads: 0,
      ...script
    };

    const { data, error } = await supabase
      .from('redshift_scripts')
      .insert([newScript])
      .select()
      .single();

    if (error) {
      console.error('Error creating script:', error);
      return null;
    }

    return data as RedshiftScript;
  } catch (error) {
    console.error('Error creating script:', error);
    return null;
  }
}

// Function to update an existing script
export async function updateScript(id: string, updates: Partial<RedshiftScript>): Promise<RedshiftScript | null> {
  try {
    const { data, error } = await supabase
      .from('redshift_scripts')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating script:', error);
      return null;
    }

    return data as RedshiftScript;
  } catch (error) {
    console.error('Error updating script:', error);
    return null;
  }
}

// Function to fetch a single script by ID
export async function fetchScriptById(id: string): Promise<RedshiftScript | null> {
  try {
    const { data, error } = await supabase
      .from('redshift_scripts')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      console.error('Error fetching script by ID:', error);
      return null;
    }

    return data as RedshiftScript;
  } catch (error) {
    console.error('Error fetching script by ID:', error);
    return null;
  }
}

// Function to fetch categories
export async function fetchCategories() {
  try {
    const { data, error } = await supabase
      .from('script_categories')
      .select('id, name')
      .order('name');

    if (error) {
      console.error('Error fetching categories:', error);
      return getMockCategories();
    }

    return data;
  } catch (error) {
    console.error('Error fetching categories:', error);
    return getMockCategories();
  }
}

// Function to fetch script types
export async function fetchScriptTypes() {
  try {
    const { data, error } = await supabase
      .from('script_types')
      .select('id, name')
      .order('name');

    if (error) {
      console.error('Error fetching script types:', error);
      return getMockScriptTypes();
    }

    return data;
  } catch (error) {
    console.error('Error fetching script types:', error);
    return getMockScriptTypes();
  }
}

// Mock data functions
function getMockCategories() {
  return [
    { id: '1', name: 'DBA Helper Queries' },
    { id: '2', name: 'Performance Tuning' },
    { id: '3', name: 'Data Loading' },
    { id: '4', name: 'Maintenance' }
  ];
}

function getMockScriptTypes() {
  return [
    { id: '1', name: 'SQL' },
    { id: '2', name: 'Shell Script' },
    { id: '3', name: 'Python' }
  ];
}

// Function to fetch all scripts
export async function fetchScripts(
  limit: number = 20,
  status: string = 'published',
  category?: string,
  script_type?: string,
  search?: string
): Promise<RedshiftScript[]> {
  try {
    let query = supabase.from('redshift_scripts').select('*');
    
    if (status !== 'all') {
      query = query.eq('status', status);
    }
    
    if (category) {
      query = query.eq('category', category);
    }
    
    if (script_type) {
      query = query.eq('script_type', script_type);
    }
    
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%,script_content.ilike.%${search}%`);
    }
    
    if (limit > 0) {
      query = query.limit(limit);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching scripts:', error);
      return getMockScripts(limit);
    }
    
    return data as RedshiftScript[] || [];
  } catch (error) {
    console.error('Error fetching scripts:', error);
    return getMockScripts(limit);
  }
}

// Function to get mock scripts
function getMockScripts(limit: number = 5): RedshiftScript[] {
  const mockScripts = [
    {
      id: '1',
      title: 'table_info.sql',
      description: 'Comprehensive table information query',
      script_content: 'SELECT * FROM svv_table_info;',
      original_url: null,
      category: 'DBA Helper Queries',
      script_type: 'SQL',
      published_at: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      tags: ['table-info', 'performance'],
      formatted_content: null,
      author: 'System',
      views: 0,
      downloads: 0,
      status: 'published'
    }
  ];
  
  return mockScripts.slice(0, limit);
}

// Function to fetch comments for a script
export async function fetchComments(scriptId: string): Promise<ScriptComment[]> {
  try {
    const { data, error } = await supabase
      .from('script_comments')
      .select('*')
      .eq('script_id', scriptId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching comments:', error);
      return [];
    }

    return data as ScriptComment[];
  } catch (error) {
    console.error('Error fetching comments:', error);
    return [];
  }
}

// Function to add a comment to a script
export async function addComment(scriptId: string, userId: string, comment: string): Promise<ScriptComment | null> {
  try {
    const newComment = {
      id: uuidv4(),
      script_id: scriptId,
      user_id: userId,
      comment: comment,
      created_at: new Date().toISOString()
    };

    const { data, error } = await supabase
      .from('script_comments')
      .insert([newComment])
      .select()
      .single();

    if (error) {
      console.error('Error adding comment:', error);
      return null;
    }

    return data as ScriptComment;
  } catch (error) {
    console.error('Error adding comment:', error);
    return null;
  }
}

// Function to rate a script
export async function rateScript(scriptId: string, userId: string, rating: number): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('script_ratings')
      .upsert({
        script_id: scriptId,
        user_id: userId,
        rating: rating,
        updated_at: new Date().toISOString()
      });

    if (error) {
      console.error('Error rating script:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error rating script:', error);
    return false;
  }
}

// Function to get user's rating for a script
export async function getUserRating(scriptId: string, userId: string): Promise<number | null> {
  try {
    const { data, error } = await supabase
      .from('script_ratings')
      .select('rating')
      .eq('script_id', scriptId)
      .eq('user_id', userId)
      .single();

    if (error) {
      console.error('Error fetching user rating:', error);
      return null;
    }

    return data?.rating || null;
  } catch (error) {
    console.error('Error fetching user rating:', error);
    return null;
  }
}

// Function to increment download count
export async function incrementDownload(scriptId: string): Promise<void> {
  try {
    const { error } = await supabase.rpc('increment_downloads', {
      script_id: scriptId
    });

    if (error) {
      console.error('Error incrementing download count:', error);
    }
  } catch (error) {
    console.error('Error incrementing download count:', error);
  }
}

// Function to format SQL script
export function formatSqlScript(sql: string): string {
  // Simple SQL formatting implementation
  // In a real application, you might want to use a proper SQL formatter library
  return sql.trim()
    .replace(/\s+/g, ' ')
    .replace(/\s*([,;])\s*/g, '$1 ')
    .replace(/\s*(\()\s*/g, ' $1')
    .replace(/\s*(\))\s*/g, '$1 ')
    .replace(/\b(SELECT|FROM|WHERE|GROUP BY|ORDER BY|HAVING|JOIN|LEFT JOIN|RIGHT JOIN|INNER JOIN|OUTER JOIN|ON|AND|OR)\b/gi, '\n$1');
}