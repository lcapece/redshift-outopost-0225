import { supabase } from './supabase';
import { ScriptContent, ScriptVersion } from '../types/script';
import { v4 as uuidv4 } from 'uuid';

/**
 * Fetch all script contents
 */
export async function fetchScriptContents(
  limit: number = 100,
  status?: 'pending_validation' | 'validated' | 'invalid',
  language?: 'sql' | 'python' | 'shell' | 'other',
  sourceId?: string,
  searchTerm?: string
): Promise<ScriptContent[]> {
  try {
    let query = supabase
      .from('script_contents')
      .select('*')
      .order('createdAt', { ascending: false });
    
    if (status) {
      query = query.eq('status', status);
    }
    
    if (language) {
      query = query.eq('language', language);
    }
    
    if (sourceId) {
      query = query.eq('sourceId', sourceId);
    }
    
    if (searchTerm) {
      query = query.or(`title.ilike.%${searchTerm}%,content.ilike.%${searchTerm}%,description.ilike.%${searchTerm}%`);
    }
    
    if (limit > 0) {
      query = query.limit(limit);
    }

    const { data, error } = await query;

    if (error) throw error;
    
    return data as ScriptContent[];
  } catch (error) {
    console.error('Error fetching script contents:', error);
    return [];
  }
}

/**
 * Fetch a single script content by ID
 */
export async function fetchScriptContentById(id: string): Promise<ScriptContent | null> {
  try {
    const { data, error } = await supabase
      .from('script_contents')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    
    return data as ScriptContent;
  } catch (error) {
    console.error('Error fetching script content by ID:', error);
    return null;
  }
}

/**
 * Create a new script content
 */
export async function createScriptContent(content: Omit<ScriptContent, 'id' | 'createdAt' | 'updatedAt'>): Promise<ScriptContent | null> {
  try {
    const newContent = {
      ...content,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('script_contents')
      .insert(newContent)
      .select()
      .single();

    if (error) throw error;
    
    // Create initial version
    await createScriptVersion({
      scriptId: data.id,
      content: data.content,
      version: 1,
      changedBy: 'system',
      changeReason: 'Initial version'
    });
    
    return data as ScriptContent;
  } catch (error) {
    console.error('Error creating script content:', error);
    return null;
  }
}

/**
 * Update an existing script content
 */
export async function updateScriptContent(
  id: string, 
  updates: Partial<ScriptContent>, 
  changedBy: string = 'system',
  changeReason?: string
): Promise<ScriptContent | null> {
  try {
    // Get current version
    const { data: currentData, error: currentError } = await supabase
      .from('script_contents')
      .select('version, content')
      .eq('id', id)
      .single();
    
    if (currentError) throw currentError;
    
    const newVersion = (currentData.version || 0) + 1;
    
    // Only create a new version if content has changed
    if (updates.content && updates.content !== currentData.content) {
      // Create a new version
      await createScriptVersion({
        scriptId: id,
        content: updates.content,
        version: newVersion,
        changedBy,
        changeReason
      });
    }
    
    const updatedContent = {
      ...updates,
      version: updates.content !== currentData.content ? newVersion : currentData.version,
      updatedAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('script_contents')
      .update(updatedContent)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScriptContent;
  } catch (error) {
    console.error('Error updating script content:', error);
    return null;
  }
}

/**
 * Delete a script content
 */
export async function deleteScriptContent(id: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('script_contents')
      .delete()
      .eq('id', id);

    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error deleting script content:', error);
    return false;
  }
}

/**
 * Create a script version
 */
export async function createScriptVersion(version: Omit<ScriptVersion, 'id' | 'createdAt'>): Promise<ScriptVersion | null> {
  try {
    const newVersion = {
      ...version,
      id: uuidv4(),
      createdAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('script_versions')
      .insert(newVersion)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScriptVersion;
  } catch (error) {
    console.error('Error creating script version:', error);
    return null;
  }
}

/**
 * Get script versions
 */
export async function getScriptVersions(scriptId: string): Promise<ScriptVersion[]> {
  try {
    const { data, error } = await supabase
      .from('script_versions')
      .select('*')
      .eq('scriptId', scriptId)
      .order('version', { ascending: false });

    if (error) throw error;
    
    return data as ScriptVersion[];
  } catch (error) {
    console.error('Error getting script versions:', error);
    return [];
  }
}

/**
 * Get a specific script version
 */
export async function getScriptVersion(scriptId: string, version: number): Promise<ScriptVersion | null> {
  try {
    const { data, error } = await supabase
      .from('script_versions')
      .select('*')
      .eq('scriptId', scriptId)
      .eq('version', version)
      .single();

    if (error) throw error;
    
    return data as ScriptVersion;
  } catch (error) {
    console.error('Error getting script version:', error);
    return null;
  }
}

/**
 * Search scripts by content or metadata
 */
export async function searchScripts(query: string, limit: number = 20): Promise<ScriptContent[]> {
  try {
    const { data, error } = await supabase
      .from('script_contents')
      .select('*')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%,description.ilike.%${query}%`)
      .limit(limit);

    if (error) throw error;
    
    return data as ScriptContent[];
  } catch (error) {
    console.error('Error searching scripts:', error);
    return [];
  }
}

/**
 * Get scripts by tag
 */
export async function getScriptsByTag(tag: string, limit: number = 20): Promise<ScriptContent[]> {
  try {
    const { data, error } = await supabase
      .from('script_contents')
      .select('*')
      .contains('tags', [tag])
      .limit(limit);

    if (error) throw error;
    
    return data as ScriptContent[];
  } catch (error) {
    console.error('Error getting scripts by tag:', error);
    return [];
  }
}

/**
 * Get all unique tags
 */
export async function getAllTags(): Promise<string[]> {
  try {
    const { data, error } = await supabase
      .from('script_contents')
      .select('tags');

    if (error) throw error;
    
    // Extract all tags and remove duplicates
    const allTags = data.flatMap(script => script.tags || []);
    const uniqueTags = [...new Set(allTags)];
    
    return uniqueTags;
  } catch (error) {
    console.error('Error getting all tags:', error);
    return [];
  }
}

/**
 * Format SQL script content with syntax highlighting
 */
export function formatSqlScript(content: string): string {
  // This is a simple formatter that adds HTML classes for syntax highlighting
  
  // Replace SQL keywords with highlighted spans
  const keywords = [
    'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'ON',
    'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET', 'UNION', 'ALL',
    'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP', 'TABLE', 'VIEW',
    'INDEX', 'CONSTRAINT', 'PRIMARY', 'FOREIGN', 'KEY', 'REFERENCES',
    'AS', 'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE', 'IS', 'NULL',
    'TRUE', 'FALSE', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT',
    'COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'WITH'
  ];
  
  let formattedContent = content;
  
  // Replace SQL keywords with spans
  keywords.forEach(keyword => {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    formattedContent = formattedContent.replace(regex, `<span class="text-blue-600 font-bold">$&</span>`);
  });
  
  // Replace strings with spans
  formattedContent = formattedContent.replace(/'([^']*)'/g, `<span class="text-green-600">'$1'</span>`);
  
  // Replace numbers with spans
  formattedContent = formattedContent.replace(/\b(\d+)\b/g, `<span class="text-purple-600">$1</span>`);
  
  // Replace comments with spans
  formattedContent = formattedContent.replace(/--([^\n]*)/g, `<span class="text-gray-500">--$1</span>`);
  
  // Replace multi-line comments with spans
  formattedContent = formattedContent.replace(/\/\*([\s\S]*?)\*\//g, `<span class="text-gray-500">/*$1*/</span>`);
  
  // Add line numbers and wrap in pre tag
  const lines = formattedContent.split('\n');
  formattedContent = lines.map((line, index) => {
    return `<div class="flex"><span class="text-gray-400 w-10 text-right pr-4 select-none">${index + 1}</span><span>${line}</span></div>`;
  }).join('\n');
  
  return `<pre class="bg-gray-50 p-4 rounded-lg overflow-x-auto text-sm font-mono">${formattedContent}</pre>`;
}