import { User } from '@auth0/auth0-react';

export interface Auth0User extends User {
  email: string;
  email_verified: boolean;
  sub: string;
  name?: string;
  picture?: string;
  nickname?: string;
}

export interface Auth0Context {
  isAuthenticated: boolean;
  isLoading: boolean;
  user?: Auth0User;
  loginWithRedirect: (options?: any) => Promise<void>;
  logout: (options?: any) => void;
  getAccessTokenSilently: (options?: any) => Promise<string>;
}

export const mapAuth0UserToSupabase = (user: Auth0User) => {
  return {
    id: user.sub,
    email: user.email,
    user_metadata: {
      full_name: user.name,
      avatar_url: user.picture,
      nickname: user.nickname,
      email_verified: user.email_verified
    }
  };
};

export const getAuth0UserRoles = async (getToken: () => Promise<string>): Promise<string[]> => {
  try {
    const token = await getToken();
    
    // Parse the JWT token to get the roles
    const payload = JSON.parse(atob(token.split('.')[1]));
    
    // Check if roles exist in the token
    if (payload && payload['https://redshiftoutpost.com/roles']) {
      return payload['https://redshiftoutpost.com/roles'];
    }
    
    return [];
  } catch (error) {
    console.error('Error getting user roles:', error);
    return [];
  }
};

export const isUserAdmin = async (getToken: () => Promise<string>): Promise<boolean> => {
  try {
    const roles = await getAuth0UserRoles(getToken);
    return roles.includes('admin');
  } catch (error) {
    console.error('Error checking if user is admin:', error);
    return false;
  }
};