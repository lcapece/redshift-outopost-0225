import { supabase } from './supabase';
import { ScriptSource, ScrapeLog, ScriptStats } from '../types/script';
import { v4 as uuidv4 } from 'uuid';

/**
 * Fetch all script sources
 */
export async function fetchScriptSources(
  limit: number = 100,
  status?: 'pending' | 'completed' | 'failed',
  type?: 'github' | 'webpage' | 'api' | 'other',
  enabled?: boolean
): Promise<ScriptSource[]> {
  try {
    let query = supabase
      .from('script_sources')
      .select('*')
      .order('priority', { ascending: false })
      .order('createdAt', { ascending: false });
    
    if (status) {
      query = query.eq('status', status);
    }
    
    if (type) {
      query = query.eq('type', type);
    }
    
    if (enabled !== undefined) {
      query = query.eq('enabled', enabled);
    }
    
    if (limit > 0) {
      query = query.limit(limit);
    }

    const { data, error } = await query;

    if (error) throw error;
    
    return data as ScriptSource[];
  } catch (error) {
    console.error('Error fetching script sources:', error);
    return [];
  }
}

/**
 * Fetch a single script source by ID
 */
export async function fetchScriptSourceById(id: string): Promise<ScriptSource | null> {
  try {
    const { data, error } = await supabase
      .from('script_sources')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    
    return data as ScriptSource;
  } catch (error) {
    console.error('Error fetching script source by ID:', error);
    return null;
  }
}

/**
 * Create a new script source
 */
export async function createScriptSource(source: Omit<ScriptSource, 'id' | 'createdAt' | 'updatedAt'>): Promise<ScriptSource | null> {
  try {
    const newSource = {
      ...source,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('script_sources')
      .insert(newSource)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScriptSource;
  } catch (error) {
    console.error('Error creating script source:', error);
    return null;
  }
}

/**
 * Update an existing script source
 */
export async function updateScriptSource(id: string, updates: Partial<ScriptSource>): Promise<ScriptSource | null> {
  try {
    const updatedSource = {
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('script_sources')
      .update(updatedSource)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScriptSource;
  } catch (error) {
    console.error('Error updating script source:', error);
    return null;
  }
}

/**
 * Delete a script source
 */
export async function deleteScriptSource(id: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('script_sources')
      .delete()
      .eq('id', id);

    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error deleting script source:', error);
    return false;
  }
}

/**
 * Reset a script source's scrape status
 */
export async function resetScriptSourceStatus(id: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('script_sources')
      .update({
        status: 'pending',
        lastScraped: null,
        errorMessage: null,
        updatedAt: new Date().toISOString()
      })
      .eq('id', id);

    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error resetting script source status:', error);
    return false;
  }
}

/**
 * Enable or disable a script source
 */
export async function toggleScriptSourceEnabled(id: string, enabled: boolean): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('script_sources')
      .update({
        enabled,
        updatedAt: new Date().toISOString()
      })
      .eq('id', id);

    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error toggling script source enabled status:', error);
    return false;
  }
}

/**
 * Get sources that need to be scraped based on frequency
 */
export async function getSourcesDueForScraping(): Promise<ScriptSource[]> {
  try {
    const now = new Date();
    
    const { data, error } = await supabase
      .from('script_sources')
      .select('*')
      .eq('enabled', true)
      .or(`lastScraped.is.null,lastScraped.lt.${new Date(now.getTime() - 3600000).toISOString()}`);

    if (error) throw error;
    
    // Filter sources based on their scrape frequency
    const dueForScraping = (data as ScriptSource[]).filter(source => {
      if (!source.lastScraped) return true;
      
      const lastScraped = new Date(source.lastScraped);
      const hoursElapsed = (now.getTime() - lastScraped.getTime()) / (1000 * 60 * 60);
      
      return hoursElapsed >= source.scrapeFrequency;
    });
    
    return dueForScraping;
  } catch (error) {
    console.error('Error getting sources due for scraping:', error);
    return [];
  }
}

/**
 * Create a scrape log entry
 */
export async function createScrapeLog(log: Omit<ScrapeLog, 'id' | 'createdAt'>): Promise<ScrapeLog | null> {
  try {
    const newLog = {
      ...log,
      id: uuidv4(),
      createdAt: new Date().toISOString()
    };
    
    const { data, error } = await supabase
      .from('scrape_logs')
      .insert(newLog)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScrapeLog;
  } catch (error) {
    console.error('Error creating scrape log:', error);
    return null;
  }
}

/**
 * Update a scrape log entry
 */
export async function updateScrapeLog(id: string, updates: Partial<ScrapeLog>): Promise<ScrapeLog | null> {
  try {
    const { data, error } = await supabase
      .from('scrape_logs')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    
    return data as ScrapeLog;
  } catch (error) {
    console.error('Error updating scrape log:', error);
    return null;
  }
}

/**
 * Get scrape logs for a source
 */
export async function getScrapeLogsForSource(sourceId: string, limit: number = 10): Promise<ScrapeLog[]> {
  try {
    const { data, error } = await supabase
      .from('scrape_logs')
      .select('*')
      .eq('sourceId', sourceId)
      .order('startTime', { ascending: false })
      .limit(limit);

    if (error) throw error;
    
    return data as ScrapeLog[];
  } catch (error) {
    console.error('Error getting scrape logs for source:', error);
    return [];
  }
}

/**
 * Get script source statistics
 */
export async function getScriptSourceStats(): Promise<ScriptStats> {
  try {
    // Get total sources
    const { count: totalSources, error: totalError } = await supabase
      .from('script_sources')
      .select('*', { count: 'exact', head: true });
    
    if (totalError) throw totalError;
    
    // Get active sources
    const { count: activeSources, error: activeError } = await supabase
      .from('script_sources')
      .select('*', { count: 'exact', head: true })
      .eq('enabled', true);
    
    if (activeError) throw activeError;
    
    // Get total scripts
    const { count: totalScripts, error: scriptsError } = await supabase
      .from('script_contents')
      .select('*', { count: 'exact', head: true });
    
    if (scriptsError) throw scriptsError;
    
    // Get scripts by language
    const { data: languageData, error: languageError } = await supabase
      .from('script_contents')
      .select('language');
    
    if (languageError) throw languageError;
    
    const scriptsByLanguage: Record<string, number> = {};
    languageData.forEach(script => {
      scriptsByLanguage[script.language] = (scriptsByLanguage[script.language] || 0) + 1;
    });
    
    // Get scripts by status
    const { data: statusData, error: statusError } = await supabase
      .from('script_contents')
      .select('status');
    
    if (statusError) throw statusError;
    
    const scriptsByStatus: Record<string, number> = {};
    statusData.forEach(script => {
      scriptsByStatus[script.status] = (scriptsByStatus[script.status] || 0) + 1;
    });
    
    // Get last scraped date
    const { data: lastScrapedData, error: lastScrapedError } = await supabase
      .from('scrape_logs')
      .select('endTime')
      .not('endTime', 'is', null)
      .order('endTime', { ascending: false })
      .limit(1);
    
    if (lastScrapedError) throw lastScrapedError;
    
    const lastScraped = lastScrapedData.length > 0 ? lastScrapedData[0].endTime : null;
    
    // Get scrapes in last 24 hours
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    const { count: scrapesInLast24Hours, error: day24Error } = await supabase
      .from('scrape_logs')
      .select('*', { count: 'exact', head: true })
      .gte('startTime', oneDayAgo.toISOString());
    
    if (day24Error) throw day24Error;
    
    // Get scrapes in last 7 days
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const { count: scrapesInLast7Days, error: day7Error } = await supabase
      .from('scrape_logs')
      .select('*', { count: 'exact', head: true })
      .gte('startTime', sevenDaysAgo.toISOString());
    
    if (day7Error) throw day7Error;
    
    // Get failed scrapes
    const { count: failedScrapes, error: failedError } = await supabase
      .from('scrape_logs')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'failed');
    
    if (failedError) throw failedError;
    
    return {
      totalSources: totalSources || 0,
      activeSources: activeSources || 0,
      totalScripts: totalScripts || 0,
      scriptsByLanguage,
      scriptsByStatus,
      lastScraped,
      scrapesInLast24Hours: scrapesInLast24Hours || 0,
      scrapesInLast7Days: scrapesInLast7Days || 0,
      failedScrapes: failedScrapes || 0
    };
  } catch (error) {
    console.error('Error getting script source stats:', error);
    
    // Return default stats
    return {
      totalSources: 0,
      activeSources: 0,
      totalScripts: 0,
      scriptsByLanguage: {},
      scriptsByStatus: {},
      lastScraped: null,
      scrapesInLast24Hours: 0,
      scrapesInLast7Days: 0,
      failedScrapes: 0
    };
  }
}