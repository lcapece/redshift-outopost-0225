import { supabase } from './supabase';
import CryptoJS from 'crypto-js';

interface SvvTableInfo {
  database_name: string;
  schema_name: string;
  table_name: string;
  encoded: boolean;
  diststyle: string;
  sortkey1: string | null;
  sortkey1_enc: string | null;
  sortkey_num: number;
  size_gb: number;
  pct_empty: number;
  unsorted_pct: number;
  stats_off: number;
  tbl_rows: number;
  skew_sortkey1: number;
  skew_rows: number;
  estimated_visible_rows: number;
  risk_event: string | null;
}

interface ImportResult {
  success: boolean;
  error?: string;
  stats?: {
    originalCount: number;
    insertedCount: number;
    updatedCount: number;
    finalCount: number;
  };
}

function encryptIdentifier(value: string, type: 'D' | 'S' | 'T', password: string): string {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return '';
  }

  try {
    // Generate a hash of the value with the password
    const hash = CryptoJS.SHA256(value + password);
    const hashStr = hash.toString(CryptoJS.enc.Hex);
    
    // Take the first 15 characters of the hash and add the type prefix
    return `${type}${hashStr.substring(0, 15)}`;
  } catch (error) {
    console.error('Error encrypting identifier:', error);
    return value;
  }
}

export function decryptIdentifier(value: string, password: string): string {
  // Check if value starts with D, S, or T prefix and has exactly 16 chars (1 prefix + 15 hash)
  if (!value || value.length !== 16 || !/^[DST]/.test(value)) {
    return value;
  }

  try {
    // Extract type prefix and hash part
    const type = value.charAt(0);
    const hashPart = value.substring(1);
    
    // For now, just return the encrypted value since we can't decrypt a hash
    // In a real implementation, you would need to store a mapping of hashes to original values
    return `${type}:${hashPart}`;
  } catch (error) {
    console.error('Error decrypting identifier:', error);
    return value;
  }
}

function parseNumericValue(value: string | undefined, defaultValue: number = 0): number {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return defaultValue;
  }
  const cleaned = value.replace(/[^\d.-]/g, '');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? defaultValue : parsed;
}

function parseIntegerValue(value: string | undefined, defaultValue: number = 0): number {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return defaultValue;
  }
  const cleaned = value.replace(/[^\d-]/g, '');
  const parsed = parseInt(cleaned, 10);
  return isNaN(parsed) ? defaultValue : parsed;
}

function parseBooleanValue(value: string | undefined): boolean {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return false;
  }
  const normalizedValue = value.trim().toUpperCase();
  return normalizedValue === 'Y' || normalizedValue === 'YES' || 
         normalizedValue === 'TRUE' || normalizedValue === 'T' || 
         normalizedValue === '1';
}

function parseStringValue(value: string | undefined): string | null {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return null;
  }
  return value.trim();
}

function parseDistStyle(value: string | undefined): string {
  if (!value || value.trim() === '' || value.trim() === '\\N') {
    return 'AUTO';
  }
  
  const match = value.match(/KEY\((.*?)\)/i);
  if (match) {
    return `KEY(${match[1]})`;
  }
  
  return value.trim().toUpperCase();
}

export async function importSvvData(
  data: string,
  userId: string,
  password: string,
  onProgress?: (processedRows: number) => void
): Promise<ImportResult> {
  try {
    // Parse pipe-delimited data
    const lines = data.trim().split('\n');
    if (lines.length < 1) {
      return { success: false, error: 'No data to import' };
    }

    // Parse and validate each row
    const records: SvvTableInfo[] = [];
    const errors: string[] = [];
    let processedRows = 0;

    // Process each data row
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const values = line.split('|');
      
      try {
        // Ensure we have minimum required columns
        if (values.length < 3) {
          errors.push(`Row ${i + 1}: Insufficient columns. Found ${values.length}, minimum required is 3`);
          continue;
        }

        // Encrypt database, schema, and table names
        const encryptedDbName = encryptIdentifier(values[0], 'D', password);
        const encryptedSchemaName = encryptIdentifier(values[1], 'S', password);
        const encryptedTableName = encryptIdentifier(values[2], 'T', password);

        const record: SvvTableInfo = {
          database_name: encryptedDbName,
          schema_name: encryptedSchemaName,
          table_name: encryptedTableName,
          encoded: parseBooleanValue(values[3]),
          diststyle: parseDistStyle(values[4]),
          sortkey1: parseStringValue(values[5]),
          sortkey1_enc: parseStringValue(values[6]),
          sortkey_num: parseIntegerValue(values[7]),
          size_gb: parseNumericValue(values[8]),
          pct_empty: parseNumericValue(values[9]),
          unsorted_pct: parseNumericValue(values[10]),
          stats_off: parseNumericValue(values[11]),
          tbl_rows: parseIntegerValue(values[12]),
          skew_sortkey1: parseNumericValue(values[13]),
          skew_rows: parseNumericValue(values[14]),
          estimated_visible_rows: parseIntegerValue(values[15]),
          risk_event: parseStringValue(values[16])
        };

        // Validate numeric ranges
        record.pct_empty = Math.max(0, Math.min(100, record.pct_empty));
        record.unsorted_pct = Math.max(0, Math.min(100, record.unsorted_pct));
        record.stats_off = Math.max(0, Math.min(100, record.stats_off));
        record.size_gb = Math.max(0, record.size_gb);
        record.tbl_rows = Math.max(0, record.tbl_rows);
        record.estimated_visible_rows = Math.max(0, record.estimated_visible_rows);

        records.push(record);
        processedRows++;
        
        // Update progress
        if (onProgress) {
          onProgress(Math.round((processedRows / lines.length) * 100));
        }
      } catch (err) {
        errors.push(`Row ${i + 1}: Invalid data format`);
        console.error(`Error processing row ${i + 1}:`, err);
      }
    }

    if (errors.length > 0) {
      return { 
        success: false, 
        error: `Validation errors:\n${errors.join('\n')}`
      };
    }

    // Insert records into staging table
    const { error: stagingError } = await supabase
      .from('svv_data_staging')
      .insert(
        records.map(record => ({
          ...record,
          created_by_user: userId
        }))
      );

    if (stagingError) {
      throw new Error(`Failed to insert into staging table: ${stagingError.message}`);
    }

    // Perform upsert operation
    const { data: upsertResult, error: upsertError } = await supabase
      .rpc('upsert_svv_data', { user_id: userId });

    if (upsertError) {
      throw new Error(`Failed to upsert data: ${upsertError.message}`);
    }

    const [result] = upsertResult;
    return {
      success: true,
      stats: {
        originalCount: result.original_count,
        insertedCount: result.inserted_count,
        updatedCount: result.updated_count,
        finalCount: result.final_count
      }
    };
  } catch (error) {
    console.error('Error importing SVV data:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
}

export async function getExistingRecordCount(userId: string): Promise<number> {
  try {
    const { count, error } = await supabase
      .from('imported_svv_data')
      .select('*', { count: 'exact', head: true })
      .eq('created_by_user', userId);

    if (error) throw error;
    return count || 0;
  } catch (error) {
    console.error('Error getting record count:', error);
    throw error;
  }
}

export async function deleteExistingRecords(userId: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('imported_svv_data')
      .delete()
      .eq('created_by_user', userId);

    if (error) throw error;
  } catch (error) {
    console.error('Error deleting existing records:', error);
    throw error;
  }
}