import { supabase } from './supabase';
import { validateImportData } from './importService';

interface ValidationResult {
  success: boolean;
  errors: string[];
  warnings: string[];
  details?: any;
}

interface ImportValidationResult extends ValidationResult {
  details: {
    rowsProcessed: number;
    processingTime: number;
    validRows: number;
    invalidRows: number;
    errorRows: Record<number, string[]>;
  };
}

interface UrlValidationResult extends ValidationResult {
  details: {
    url: string;
    statusCode: number;
    responseTime: number;
    redirects: string[];
    permissions: string[];
  };
}

export async function validateTableImport(
  data: string,
  delimiter: string = ',',
  textQualifier: string = '"'
): Promise<ImportValidationResult> {
  const startTime = performance.now();
  const errors: string[] = [];
  const warnings: string[] = [];
  const errorRows: Record<number, string[]> = {};
  let validRows = 0;
  let invalidRows = 0;

  try {
    // Validate data format and structure
    const { isValid, errors: formatErrors, preview } = await validateImportData(
      data,
      delimiter,
      textQualifier
    );

    if (!isValid) {
      return {
        success: false,
        errors: formatErrors,
        warnings: [],
        details: {
          rowsProcessed: 0,
          processingTime: performance.now() - startTime,
          validRows: 0,
          invalidRows: 0,
          errorRows: {}
        }
      };
    }

    // Parse data into rows
    const rows = data.trim().split('\n');
    const headers = rows[0].split(delimiter).map(h => h.trim());

    // Required columns for SVV_TABLE_INFO
    const requiredColumns = [
      'database_name',
      'schema_name',
      'table_name',
      'encoded',
      'diststyle',
      'sortkey1',
      'size',
      'pct_used',
      'unsorted',
      'stats_off'
    ];

    // Validate headers
    const missingColumns = requiredColumns.filter(
      col => !headers.map(h => h.toLowerCase()).includes(col.toLowerCase())
    );

    if (missingColumns.length > 0) {
      errors.push(`Missing required columns: ${missingColumns.join(', ')}`);
    }

    // Validate each row
    for (let i = 1; i < rows.length; i++) {
      const rowErrors: string[] = [];
      const row = rows[i].split(delimiter).map(cell => cell.trim());

      // Check column count
      if (row.length !== headers.length) {
        rowErrors.push(`Column count mismatch: expected ${headers.length}, got ${row.length}`);
      }

      // Validate data types and values
      headers.forEach((header, index) => {
        const value = row[index];
        switch (header.toLowerCase()) {
          case 'size':
          case 'pct_used':
          case 'unsorted':
          case 'stats_off':
            if (isNaN(parseFloat(value))) {
              rowErrors.push(`Invalid number in column ${header}: ${value}`);
            }
            break;
          case 'encoded':
            if (!['t', 'f', 'true', 'false'].includes(value.toLowerCase())) {
              rowErrors.push(`Invalid boolean in column ${header}: ${value}`);
            }
            break;
        }
      });

      if (rowErrors.length > 0) {
        errorRows[i] = rowErrors;
        invalidRows++;
      } else {
        validRows++;
      }
    }

    // Check for potential data quality issues
    if (validRows < 10) {
      warnings.push('Very few valid rows detected. Please verify data completeness.');
    }

    const success = errors.length === 0 && invalidRows === 0;

    return {
      success,
      errors,
      warnings,
      details: {
        rowsProcessed: rows.length - 1, // Exclude header row
        processingTime: performance.now() - startTime,
        validRows,
        invalidRows,
        errorRows
      }
    };
  } catch (error) {
    console.error('Validation error:', error);
    return {
      success: false,
      errors: ['Failed to validate import data: ' + (error as Error).message],
      warnings: [],
      details: {
        rowsProcessed: 0,
        processingTime: performance.now() - startTime,
        validRows: 0,
        invalidRows: 0,
        errorRows: {}
      }
    };
  }
}

export async function validateInternalUrl(url: string): Promise<UrlValidationResult> {
  const startTime = performance.now();
  const errors: string[] = [];
  const warnings: string[] = [];
  const redirects: string[] = [];
  let statusCode = 0;

  try {
    // Check if URL is internal
    const siteUrl = new URL(window.location.origin);
    const targetUrl = new URL(url);
    
    if (targetUrl.origin !== siteUrl.origin) {
      errors.push('URL is not internal to the application');
      return {
        success: false,
        errors,
        warnings,
        details: {
          url,
          statusCode: 0,
          responseTime: performance.now() - startTime,
          redirects: [],
          permissions: []
        }
      };
    }

    // Test URL accessibility
    const response = await fetch(url, {
      redirect: 'follow',
      headers: {
        'Cache-Control': 'no-cache'
      }
    });

    statusCode = response.status;

    // Track redirects
    if (response.redirected) {
      redirects.push(response.url);
    }

    // Check response status
    if (!response.ok) {
      errors.push(`HTTP error: ${response.status} ${response.statusText}`);
    }

    // Check content type
    const contentType = response.headers.get('content-type');
    if (!contentType?.includes('text/html')) {
      warnings.push(`Unexpected content type: ${contentType}`);
    }

    // Get required permissions
    const permissions = await getRequiredPermissions(url);

    return {
      success: errors.length === 0,
      errors,
      warnings,
      details: {
        url,
        statusCode,
        responseTime: performance.now() - startTime,
        redirects,
        permissions
      }
    };
  } catch (error) {
    console.error('URL validation error:', error);
    return {
      success: false,
      errors: ['Failed to validate URL: ' + (error as Error).message],
      warnings,
      details: {
        url,
        statusCode,
        responseTime: performance.now() - startTime,
        redirects,
        permissions: []
      }
    };
  }
}

async function getRequiredPermissions(url: string): Promise<string[]> {
  // Get route permissions from Supabase
  try {
    const { data, error } = await supabase
      .from('route_permissions')
      .select('permission')
      .eq('route', new URL(url).pathname);

    if (error) throw error;
    
    return data.map(p => p.permission);
  } catch (error) {
    console.error('Error getting route permissions:', error);
    return [];
  }
}