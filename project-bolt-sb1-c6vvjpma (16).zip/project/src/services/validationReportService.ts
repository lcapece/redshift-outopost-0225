import { ValidationResult } from './validationService';

interface ValidationReport {
  timestamp: string;
  environment: {
    userAgent: string;
    screenResolution: string;
    timeZone: string;
  };
  summary: {
    totalTests: number;
    passedTests: number;
    failedTests: number;
    warningCount: number;
  };
  urlValidations: ValidationResult[];
  importValidations: ValidationResult[];
  recommendations: string[];
}

export async function generateValidationReport(
  urlResults: ValidationResult[],
  importResults: ValidationResult[]
): Promise<ValidationReport> {
  const passedTests = [...urlResults, ...importResults].filter(r => r.success).length;
  const totalTests = urlResults.length + importResults.length;
  const warningCount = [...urlResults, ...importResults].reduce(
    (count, result) => count + result.warnings.length,
    0
  );

  const recommendations = generateRecommendations(urlResults, importResults);

  return {
    timestamp: new Date().toISOString(),
    environment: {
      userAgent: navigator.userAgent,
      screenResolution: `${window.screen.width}x${window.screen.height}`,
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone
    },
    summary: {
      totalTests,
      passedTests,
      failedTests: totalTests - passedTests,
      warningCount
    },
    urlValidations: urlResults,
    importValidations: importResults,
    recommendations
  };
}

function generateRecommendations(
  urlResults: ValidationResult[],
  importResults: ValidationResult[]
): string[] {
  const recommendations: string[] = [];

  // URL-related recommendations
  const failedUrls = urlResults.filter(r => !r.success);
  if (failedUrls.length > 0) {
    recommendations.push(
      'Review and fix broken internal links',
      'Ensure all routes have proper permission configuration'
    );
  }

  // Import-related recommendations
  const failedImports = importResults.filter(r => !r.success);
  if (failedImports.length > 0) {
    recommendations.push(
      'Validate data format before import',
      'Consider implementing data validation on the client side',
      'Add clear error messages for common import issues'
    );
  }

  // Performance recommendations
  const slowResponses = urlResults.filter(
    r => r.details?.responseTime > 1000
  );
  if (slowResponses.length > 0) {
    recommendations.push(
      'Optimize slow-loading routes',
      'Consider implementing route-based code splitting'
    );
  }

  // Security recommendations
  const securityIssues = urlResults.filter(
    r => r.details?.permissions.length === 0
  );
  if (securityIssues.length > 0) {
    recommendations.push(
      'Review route security configurations',
      'Implement proper permission checks for all routes'
    );
  }

  return recommendations;
}

export function formatValidationReport(report: ValidationReport): string {
  return `
Validation Report
================
Generated: ${new Date(report.timestamp).toLocaleString()}

Environment
-----------
Browser: ${report.environment.userAgent}
Screen Resolution: ${report.environment.screenResolution}
Time Zone: ${report.environment.timeZone}

Summary
-------
Total Tests: ${report.summary.totalTests}
Passed: ${report.summary.passedTests}
Failed: ${report.summary.failedTests}
Warnings: ${report.summary.warningCount}

URL Validations
--------------
${report.urlValidations.map(validation => `
URL: ${validation.details.url}
Status: ${validation.success ? 'PASS' : 'FAIL'}
Status Code: ${validation.details.statusCode}
Response Time: ${validation.details.responseTime.toFixed(2)}ms
${validation.errors.length > 0 ? `Errors:\n${validation.errors.map(e => `  - ${e}`).join('\n')}` : ''}
${validation.warnings.length > 0 ? `Warnings:\n${validation.warnings.map(w => `  - ${w}`).join('\n')}` : ''}
`).join('\n')}

Import Validations
-----------------
${report.importValidations.map(validation => `
Status: ${validation.success ? 'PASS' : 'FAIL'}
Rows Processed: ${validation.details.rowsProcessed}
Valid Rows: ${validation.details.validRows}
Invalid Rows: ${validation.details.invalidRows}
Processing Time: ${validation.details.processingTime.toFixed(2)}ms
${validation.errors.length > 0 ? `Errors:\n${validation.errors.map(e => `  - ${e}`).join('\n')}` : ''}
${validation.warnings.length > 0 ? `Warnings:\n${validation.warnings.map(w => `  - ${w}`).join('\n')}` : ''}
`).join('\n')}

Recommendations
--------------
${report.recommendations.map(r => `- ${r}`).join('\n')}
`.trim();
}