import { Parser } from '@json2csv/plainjs';
import Papa from 'papaparse';

export interface TransformationRule {
  column: string;
  operation: 'encrypt' | 'mask' | 'hash';
  options?: Record<string, any>;
}

export interface TransformationConfig {
  rules: TransformationRule[];
  validation: {
    required: string[];
    format: Record<string, RegExp>;
  };
}

export interface DataFormat {
  type: 'csv' | 'json' | 'sql';
  options: {
    delimiter?: string;
    textQualifier?: string;
    headers?: boolean;
    skipEmptyLines?: boolean;
  };
}

export async function transformData(
  data: string,
  sourceFormat: DataFormat,
  targetFormat: DataFormat,
  config?: TransformationConfig
): Promise<string> {
  try {
    // Parse input data
    let parsedData = await parseData(data, sourceFormat);
    
    // Apply transformations if configured
    if (config) {
      parsedData = await applyTransformations(parsedData, config);
    }
    
    // Format output data
    return formatData(parsedData, targetFormat);
  } catch (error) {
    console.error('Data transformation error:', error);
    throw new Error('Failed to transform data');
  }
}

async function parseData(data: string, format: DataFormat): Promise<any[]> {
  switch (format.type) {
    case 'csv':
      return new Promise((resolve, reject) => {
        Papa.parse(data, {
          delimiter: format.options.delimiter,
          quoteChar: format.options.textQualifier,
          header: format.options.headers,
          skipEmptyLines: format.options.skipEmptyLines,
          complete: (results) => resolve(results.data),
          error: (error) => reject(error)
        });
      });
      
    case 'json':
      return JSON.parse(data);
      
    case 'sql':
      // Parse SQL query results
      const lines = data.trim().split('\n');
      const headers = lines[0].split('|').map(h => h.trim());
      return lines.slice(1).map(line => {
        const values = line.split('|').map(v => v.trim());
        return headers.reduce((obj, header, i) => {
          obj[header] = values[i];
          return obj;
        }, {} as Record<string, any>);
      });
      
    default:
      throw new Error(`Unsupported format: ${format.type}`);
  }
}

async function applyTransformations(
  data: any[],
  config: TransformationConfig
): Promise<any[]> {
  return data.map(row => {
    const transformedRow = { ...row };
    
    // Apply transformation rules
    for (const rule of config.rules) {
      if (row.hasOwnProperty(rule.column)) {
        transformedRow[rule.column] = transformValue(
          row[rule.column],
          rule.operation,
          rule.options
        );
      }
    }
    
    // Validate required fields
    for (const field of config.validation.required) {
      if (!transformedRow[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }
    
    // Validate field formats
    for (const [field, pattern] of Object.entries(config.validation.format)) {
      if (transformedRow[field] && !pattern.test(transformedRow[field])) {
        throw new Error(`Invalid format for field ${field}`);
      }
    }
    
    return transformedRow;
  });
}

function transformValue(
  value: any,
  operation: string,
  options?: Record<string, any>
): any {
  switch (operation) {
    case 'mask':
      return maskValue(value, options?.pattern || 'X');
      
    case 'hash':
      return hashValue(value);
      
    default:
      return value;
  }
}

function maskValue(value: string, pattern: string): string {
  if (typeof value !== 'string') return value;
  return value.replace(/./g, pattern);
}

function hashValue(value: string): string {
  return CryptoJS.SHA256(value).toString();
}

async function formatData(data: any[], format: DataFormat): Promise<string> {
  switch (format.type) {
    case 'csv':
      const parser = new Parser({
        delimiter: format.options.delimiter,
        quote: format.options.textQualifier
      });
      return parser.parse(data);
      
    case 'json':
      return JSON.stringify(data, null, 2);
      
    case 'sql':
      // Format as SQL INSERT statements
      const table = 'imported_data';
      const columns = Object.keys(data[0]);
      return data.map(row => {
        const values = columns.map(col => 
          typeof row[col] === 'string' ? `'${row[col]}'` : row[col]
        );
        return `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${values.join(', ')});`;
      }).join('\n');
      
    default:
      throw new Error(`Unsupported format: ${format.type}`);
  }
}