import CryptoJS from 'crypto-js';
import zxcvbn from 'zxcvbn';

export interface EncryptionConfig {
  version: number;
  algorithm: string;
  keyDerivation: {
    method: string;
    iterations: number;
    saltLength: number;
  };
}

export interface EncryptedData {
  data: string;
  metadata: {
    version: number;
    salt: string;
    iv: string;
    timestamp: string;
  };
}

const CURRENT_VERSION = 1;
const DEFAULT_CONFIG: EncryptionConfig = {
  version: CURRENT_VERSION,
  algorithm: 'AES-256-CBC',
  keyDerivation: {
    method: 'PBKDF2',
    iterations: 10000,
    saltLength: 16
  }
};

export function validatePassword(password: string): { 
  isValid: boolean; 
  score: number; 
  feedback: string[];
} {
  const result = zxcvbn(password);
  
  return {
    isValid: result.score >= 3,
    score: result.score,
    feedback: [
      ...result.feedback.suggestions,
      result.feedback.warning
    ].filter(Boolean)
  };
}

export async function encryptData(
  data: string, 
  password: string, 
  config: EncryptionConfig = DEFAULT_CONFIG
): Promise<EncryptedData> {
  // Validate password strength
  const validation = validatePassword(password);
  if (!validation.isValid) {
    throw new Error('Password is too weak: ' + validation.feedback.join('. '));
  }

  try {
    // Generate salt
    const salt = CryptoJS.lib.WordArray.random(config.keyDerivation.saltLength);
    
    // Derive key using PBKDF2
    const key = CryptoJS.PBKDF2(password, salt, {
      keySize: 256 / 32,
      iterations: config.keyDerivation.iterations
    });
    
    // Generate IV
    const iv = CryptoJS.lib.WordArray.random(16);
    
    // Encrypt data
    const encrypted = CryptoJS.AES.encrypt(data, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    
    return {
      data: encrypted.toString(),
      metadata: {
        version: config.version,
        salt: salt.toString(),
        iv: iv.toString(),
        timestamp: new Date().toISOString()
      }
    };
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
}

export async function decryptData(
  encryptedData: EncryptedData,
  password: string
): Promise<string> {
  try {
    // Parse salt and IV
    const salt = CryptoJS.enc.Hex.parse(encryptedData.metadata.salt);
    const iv = CryptoJS.enc.Hex.parse(encryptedData.metadata.iv);
    
    // Derive key
    const key = CryptoJS.PBKDF2(password, salt, {
      keySize: 256 / 32,
      iterations: DEFAULT_CONFIG.keyDerivation.iterations
    });
    
    // Decrypt data
    const decrypted = CryptoJS.AES.decrypt(encryptedData.data, key, {
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
    
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data. Invalid password or corrupted data.');
  }
}

export async function rotateKey(
  encryptedData: EncryptedData,
  oldPassword: string,
  newPassword: string
): Promise<EncryptedData> {
  // Decrypt with old password
  const decrypted = await decryptData(encryptedData, oldPassword);
  
  // Validate new password
  const validation = validatePassword(newPassword);
  if (!validation.isValid) {
    throw new Error('New password is too weak: ' + validation.feedback.join('. '));
  }
  
  // Encrypt with new password
  return encryptData(decrypted, newPassword, {
    ...DEFAULT_CONFIG,
    version: encryptedData.metadata.version + 1
  });
}