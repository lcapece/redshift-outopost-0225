import axios from 'axios';
import { supabase } from './supabase';

const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const DEFAULT_MODEL = 'meta-llama/llama-3.1-405b';

interface OpenRouterResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

interface JoinInfo {
  leftTable: string;
  rightTable: string;
  leftColumn: string;
  rightColumn: string;
  joinType: string;
}

interface OpenRouterConfig {
  headers: {
    Authorization: string;
    'HTTP-Referer': string;
    'X-Title': string;
    'Content-Type': string;
  };
}

function validateOpenRouterResponse(response: any): response is OpenRouterResponse {
  return (
    response &&
    Array.isArray(response.choices) &&
    response.choices.length > 0 &&
    response.choices[0].message &&
    typeof response.choices[0].message.content === 'string'
  );
}

function getOpenRouterConfig(): OpenRouterConfig {
  const token = import.meta.env.VITE_OPENROUTER_TOKEN;
  if (!token) {
    throw new Error('OpenRouter API token is not configured in environment variables');
  }

  return {
    headers: {
      'Authorization': `Bearer ${token}`,
      'HTTP-Referer': window.location.origin,
      'X-Title': 'Query Plan Analyzer',
      'Content-Type': 'application/json'
    }
  };
}

async function makeOpenRouterRequest<T>(
  model: string = DEFAULT_MODEL,
  messages: Array<{ role: string; content: string }>,
  options: {
    temperature?: number;
    maxTokens?: number;
    topP?: number;
    frequencyPenalty?: number;
    presencePenalty?: number;
  } = {}
): Promise<string> {
  const config = getOpenRouterConfig();
  
  try {
    const response = await axios.post<OpenRouterResponse>(
      OPENROUTER_API_URL,
      {
        model,
        messages,
        temperature: options.temperature ?? 0.7,
        max_tokens: options.maxTokens ?? 1500,
        top_p: options.topP ?? 0.9,
        frequency_penalty: options.frequencyPenalty ?? 0.0,
        presence_penalty: options.presencePenalty ?? 0.0
      },
      config
    );

    if (!validateOpenRouterResponse(response.data)) {
      throw new Error('Invalid response format from OpenRouter API');
    }

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error('OpenRouter API error:', error);
    
    // Return a fallback response for offline mode
    if (messages[0].role === 'system' && messages[0].content.includes('haiku')) {
      return "Tables join and scan,\nRedshift clusters work their plan,\nQueries fly like wind.";
    } else {
      throw error;
    }
  }
}

export async function generateQueryAndPlan(
  model: string = DEFAULT_MODEL, 
  complexity: number
): Promise<{ sql: string; plan: string; joins: JoinInfo[] }> {
  try {
    const complexityPrompts = {
      1: 'Generate a very simple SQL query using only basic SELECT, FROM, and WHERE clauses. Include at least one view with prefix "v_" (e.g., v_customer_summary, v_sales_report).',
      2: 'Generate a moderately simple SQL query using basic joins and simple aggregations. Include at least one view with prefix "v_" (e.g., v_daily_sales, v_product_inventory).',
      3: 'Generate a moderate complexity SQL query using multiple joins, subqueries, or aggregations. Include at least two views with prefix "v_" (e.g., v_order_details, v_customer_metrics).',
      4: 'Generate a complex SQL query using CTEs, window functions, or analytical functions. Include multiple views with prefix "v_" (e.g., v_sales_analytics, v_customer_segmentation).',
      5: 'Generate an extremely complex SQL query combining multiple advanced features: CTEs, window functions, subqueries, CASE statements, multiple joins, aggregations with HAVING, and analytical functions. Include several views with prefix "v_" (e.g., v_financial_metrics, v_customer_lifetime_value, v_product_performance).'
    };

    const prompt = complexityPrompts[complexity as keyof typeof complexityPrompts];

    try {
      // Generate SQL and plan
      const content = await makeOpenRouterRequest(
        model,
        [
          {
            role: 'system',
            content: `You are a PostgreSQL database running in simulation mode. You have access to a complete data warehouse with tables and materialized views. When asked to generate queries and execution plans:

1. NEVER mention that this is a simulation or that you don't have access to a real database
2. NEVER use disclaimers or qualifiers about the response
3. ALWAYS generate complete, realistic SQL queries with proper syntax
4. ALWAYS include detailed execution plans with realistic costs, row estimates, and operators
5. ALWAYS use views with "v_" prefix to represent materialized or virtual views
6. ALWAYS ensure execution plans match the complexity of the queries
7. ALWAYS include appropriate join types, index scans, sequential scans based on the query structure
8. ALWAYS use realistic table and column names that would exist in a data warehouse
9. NEVER wrap the SQL or PLAN in quotes, backticks, or code blocks
10. Output format must be exactly:
---SQL---
[SQL query without any wrapping]
---PLAN---
[Execution plan without any wrapping]`
          },
          {
            role: 'user',
            content: `${prompt}\nRespond only with the SQL and plan in the exact format specified.`
          }
        ],
        { temperature: 0.7 }
      );

      const sqlMatch = content.match(/---SQL---([\s\S]*?)(?:---PLAN---|$)/);
      const planMatch = content.match(/---PLAN---([\s\S]*?)$/);

      if (!sqlMatch || !planMatch) {
        throw new Error('Invalid response format: Missing SQL or PLAN sections');
      }

      const sql = sqlMatch[1].trim()
        .replace(/^['"`]{3}/, '')
        .replace(/['"`]{3}$/, '')
        .trim();
      
      const plan = planMatch[1].trim()
        .replace(/^['"`]{3}/, '')
        .replace(/['"`]{3}$/, '')
        .trim();

      if (!sql || !plan) {
        throw new Error('Empty SQL or plan in response');
      }

      // Analyze joins
      const joinContent = await makeOpenRouterRequest(
        model,
        [
          {
            role: 'system',
            content: `You are a SQL join analyzer. Extract and separate all joins in SQL queries. For each join, identify:
1. The table name and column name on both sides of the join
2. The type of join (INNER, LEFT, RIGHT, FULL, CROSS)
3. If a join involves a subquery, use "{Subquery}" as the table name

Format your response as a JSON array of objects with these properties:
- leftTable: string (table name or "{Subquery}")
- rightTable: string (table name or "{Subquery}")
- leftColumn: string (column name)
- rightColumn: string (column name)
- joinType: string (INNER, LEFT, RIGHT, FULL, CROSS)

Example output:
[
  {
    "leftTable": "orders",
    "rightTable": "customers",
    "leftColumn": "customer_id",
    "rightColumn": "id",
    "joinType": "INNER"
  }
]`
          },
          {
            role: 'user',
            content: sql
          }
        ],
        { temperature: 0.1 }
      );

      let joins: JoinInfo[] = [];
      try {
        joins = JSON.parse(joinContent);
        if (!Array.isArray(joins)) {
          throw new Error('Invalid joins format');
        }
      } catch (error) {
        console.error('Error parsing joins:', error);
        joins = [];
      }

      // Try to store the simulation in Supabase
      try {
        const { error } = await supabase
          .from('redshift_simulations')
          .insert({
            llm_model: model,
            sql_query: sql,
            query_plan: plan,
            complexity: complexity
          });

        if (error) {
          console.error('Error storing simulation:', error);
        }
      } catch (err) {
        console.error('Failed to store simulation in Supabase:', err);
      }

      return { sql, plan, joins };
    } catch (error) {
      console.error('Error in API request:', error);
      
      // Fallback to local examples for offline mode
      const exampleSQL = `SELECT 
  c.customer_id, 
  c.name, 
  SUM(o.total_amount) as total_spent
FROM 
  customers c
JOIN 
  orders o ON c.customer_id = o.customer_id
JOIN 
  v_customer_status cs ON c.customer_id = cs.customer_id
WHERE 
  o.order_date > '2023-01-01'
  AND cs.status = 'active'
GROUP BY 
  c.customer_id, c.name
HAVING 
  SUM(o.total_amount) > 1000
ORDER BY 
  total_spent DESC
LIMIT 100;`;

      const examplePlan = `XN Limit  (cost=1000000034.67..1000000034.92 rows=100 width=68)
  ->  XN Sort  (cost=1000000034.67..1000000035.92 rows=500 width=68)
        Sort Key: sum(o.total_amount)
        ->  XN HashAggregate  (cost=34.17..39.17 rows=500 width=68)
              Filter: (sum(o.total_amount) > 1000.00)
              ->  XN Hash Join DS_BCAST_INNER  (cost=8.50..29.75 rows=1000 width=68)
                    Hash Cond: ("outer".customer_id = "inner".customer_id)
                    ->  XN Hash Join DS_DIST_OUTER  (cost=4.25..21.75 rows=1000 width=68)
                          Hash Cond: ("outer".customer_id = "inner".customer_id)
                          ->  XN Seq Scan on orders o  (cost=0.00..15.00 rows=1000 width=36)
                                Filter: (order_date > '2023-01-01'::date)
                          ->  XN Hash  (cost=3.00..3.00 rows=500 width=36)
                                ->  XN Seq Scan on customers c  (cost=0.00..3.00 rows=500 width=36)
                    ->  XN Hash  (cost=3.00..3.00 rows=500 width=4)
                          ->  XN Seq Scan on v_customer_status cs  (cost=0.00..3.00 rows=500 width=4)
                                Filter: ((status)::text = 'active'::text)`;
      
      const exampleJoins = [
        {
          leftTable: "customers",
          rightTable: "orders",
          leftColumn: "customer_id",
          rightColumn: "customer_id",
          joinType: "INNER"
        },
        {
          leftTable: "customers",
          rightTable: "v_customer_status",
          leftColumn: "customer_id",
          rightColumn: "customer_id",
          joinType: "INNER"
        }
      ];
      
      return { sql: exampleSQL, plan: examplePlan, joins: exampleJoins };
    }
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('OpenRouter API error:', {
        status: error.response?.status,
        data: error.response?.data
      });
      if (error.response?.status === 401) {
        throw new Error('OpenRouter API authentication failed. Please check your API token in the environment variables.');
      }
      throw new Error(`API request failed: ${error.response?.data?.error || error.message}`);
    }
    throw error;
  }
}

export async function generateBatchSimulations(
  count: number = 20, 
  model: string = DEFAULT_MODEL,
  onProgress?: (current: number) => void
): Promise<void> {
  const complexities = Array.from({ length: count }, (_, i) => Math.floor(i / 4) + 1);
  
  for (let i = complexities.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [complexities[i], complexities[j]] = [complexities[j], complexities[i]];
  }

  for (let i = 0; i < count; i++) {
    try {
      await generateQueryAndPlan(model, complexities[i]);
      onProgress?.(i + 1);
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.error(`Error generating simulation ${i + 1}:`, error);
    }
  }
}

export async function generateHaiku(model: string = DEFAULT_MODEL): Promise<string> {
  try {
    return await makeOpenRouterRequest(
      model,
      [
        {
          role: 'system',
          content: 'You are a creative poet who specializes in haikus. Create a funny haiku about Amazon Redshift database.'
        },
        {
          role: 'user',
          content: 'Write a funny haiku about Amazon Redshift database. Make it technical but humorous.'
        }
      ],
      { temperature: 0.8, maxTokens: 100 }
    );
  } catch (error) {
    console.error('Error generating haiku:', error);
    // Return a fallback haiku for offline mode
    return "Tables join and scan,\nRedshift clusters work their plan,\nQueries fly like wind.";
  }
}