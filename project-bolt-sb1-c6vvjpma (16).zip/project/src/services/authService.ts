import { supabase } from './supabase';

/**
 * Authentication service for handling user registration, login, and verification
 */

interface SignUpCredentials {
  email: string;
  password: string;
  metadata?: {
    full_name?: string;
    company?: string;
    role?: string;
  };
}

interface SignInCredentials {
  email: string;
  password: string;
}

/**
 * Sign up a new user with email and password
 * This will trigger the email verification flow
 */
export async function signUpWithEmail({ email, password, metadata }: SignUpCredentials) {
  try {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
        data: metadata || {}
      }
    });

    if (error) throw error;
    
    return {
      success: true,
      user: data.user,
      message: 'Registration successful! Please check your email for verification instructions.'
    };
  } catch (error) {
    console.error('Error during sign up:', error);
    return {
      success: false,
      message: error.message || 'Failed to register. Please try again.'
    };
  }
}

/**
 * Sign in an existing user with email and password
 */
export async function signInWithEmail({ email, password }: SignInCredentials) {
  try {
    // First check if the email exists
    const { data: { users }, error: userError } = await supabase.auth.admin.listUsers({
      filters: {
        email: email
      }
    });

    if (userError) throw userError;

    // If no user found with this email
    if (!users || users.length === 0) {
      return {
        success: false,
        message: 'No account found with this email address. Please check your email or sign up for a new account.'
      };
    }

    // Attempt to sign in
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) {
      // Handle specific error cases
      if (error.message.includes('Invalid login credentials')) {
        return {
          success: false,
          message: 'Incorrect password. Please try again or use the "Forgot Password" link to reset it.'
        };
      }
      throw error;
    }
    
    // Check if email is verified
    if (!data.user.email_confirmed_at) {
      return {
        success: false,
        needsVerification: true,
        message: 'Please verify your email address before signing in. Check your inbox for the verification link.'
      };
    }
    
    return {
      success: true,
      user: data.user,
      session: data.session,
      message: 'Sign in successful!'
    };
  } catch (error) {
    console.error('Error during sign in:', error);
    return {
      success: false,
      message: error.message || 'Failed to sign in. Please check your credentials and try again.'
    };
  }
}

/**
 * Sign out the current user
 */
export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut();
    
    if (error) throw error;
    
    return {
      success: true,
      message: 'Sign out successful!'
    };
  } catch (error) {
    console.error('Error during sign out:', error);
    return {
      success: false,
      message: error.message || 'Failed to sign out. Please try again.'
    };
  }
}

/**
 * Send a password reset email
 */
export async function resetPassword(email: string) {
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    });
    
    if (error) throw error;
    
    return {
      success: true,
      message: 'Password reset instructions sent to your email!'
    };
  } catch (error) {
    console.error('Error sending password reset:', error);
    return {
      success: false,
      message: error.message || 'Failed to send password reset. Please try again.'
    };
  }
}

/**
 * Update user password
 */
export async function updatePassword(password: string) {
  try {
    const { error } = await supabase.auth.updateUser({
      password
    });
    
    if (error) throw error;
    
    return {
      success: true,
      message: 'Password updated successfully!'
    };
  } catch (error) {
    console.error('Error updating password:', error);
    return {
      success: false,
      message: error.message || 'Failed to update password. Please try again.'
    };
  }
}

/**
 * Get the current user
 */
export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser();
    
    if (error) throw error;
    
    return {
      success: true,
      user: data.user
    };
  } catch (error) {
    console.error('Error getting current user:', error);
    return {
      success: false,
      message: error.message || 'Failed to get current user.'
    };
  }
}

/**
 * Check if the user's email is verified
 */
export async function isEmailVerified() {
  try {
    const { data, error } = await supabase.auth.getUser();
    
    if (error) throw error;
    
    return {
      success: true,
      isVerified: data.user?.email_confirmed_at ? true : false
    };
  } catch (error) {
    console.error('Error checking email verification:', error);
    return {
      success: false,
      isVerified: false,
      message: error.message || 'Failed to check email verification status.'
    };
  }
}

/**
 * Resend verification email
 */
export async function resendVerificationEmail(email: string) {
  try {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      }
    });
    
    if (error) throw error;
    
    return {
      success: true,
      message: 'Verification email resent successfully!'
    };
  } catch (error) {
    console.error('Error resending verification email:', error);
    return {
      success: false,
      message: error.message || 'Failed to resend verification email. Please try again.'
    };
  }
}