import { supabase } from './supabase';
import { 
  ScrapeUrl, 
  ScrapeUrlWithStats, 
  ScrapeAuditLog, 
  ScrapeHistory,
  ScrapeUrlFilters,
  ScrapeUrlSort,
  ScrapeUrlPagination
} from '../types/scraping';

export async function analyzePage(url: string, modelId: string): Promise<{
  scripts: Array<{
    type: 'sql' | 'procedure' | 'view' | 'utility';
    name: string;
    content: string;
    description: string;
    tags: string[];
    performance_impact?: string;
    gotchas?: string[];
  }>;
  summary: string;
  recommendations: string[];
}> {
  try {
    // Make API call to the selected LLM
    const response = await fetch('/api/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url,
        modelId,
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to analyze page');
    }

    return await response.json();
  } catch (error) {
    console.error('Error analyzing page:', error);
    throw error;
  }
}

export async function fetchScrapeUrls(
  filters: ScrapeUrlFilters,
  sort: ScrapeUrlSort,
  pagination: ScrapeUrlPagination
): Promise<{ data: ScrapeUrlWithStats[]; pagination: ScrapeUrlPagination }> {
  try {
    let query = supabase
      .from('v_scrape_urls_with_stats')
      .select('*', { count: 'exact' });
    
    // Apply filters
    if (filters.status) {
      query = query.eq('status', filters.status);
    }
    if (filters.active !== undefined) {
      query = query.eq('active', filters.active);
    }
    if (filters.dateRange) {
      query = query
        .gte('date_added', filters.dateRange.start.toISOString())
        .lte('date_added', filters.dateRange.end.toISOString());
    }
    if (filters.search) {
      query = query.or(`url.ilike.%${filters.search}%,comments.ilike.%${filters.search}%`);
    }
    
    // Apply sorting
    query = query.order(sort.field, { ascending: sort.direction === 'asc' });
    
    // Apply pagination
    const from = pagination.page * pagination.pageSize;
    query = query.range(from, from + pagination.pageSize - 1);
    
    const { data, error, count } = await query;
    
    if (error) throw error;
    
    return {
      data: (data || []) as ScrapeUrlWithStats[],
      pagination: {
        ...pagination,
        total: count || 0
      }
    };
  } catch (error) {
    console.error('Error fetching scrape URLs:', error);
    return {
      data: [],
      pagination: {
        ...pagination,
        total: 0
      }
    };
  }
}

export async function createScrapeUrl(url: Omit<ScrapeUrl, 'dateAdded' | 'createdAt' | 'updatedAt'>): Promise<ScrapeUrl | null> {
  try {
    const { data, error } = await supabase
      .from('scrape_urls')
      .insert(url)
      .select()
      .single();
    
    if (error) throw error;
    
    return data as ScrapeUrl;
  } catch (error) {
    console.error('Error creating scrape URL:', error);
    return null;
  }
}

export async function updateScrapeUrl(url: string, updates: Partial<ScrapeUrl>): Promise<ScrapeUrl | null> {
  try {
    const { data, error } = await supabase
      .from('scrape_urls')
      .update(updates)
      .eq('url', url)
      .select()
      .single();
    
    if (error) throw error;
    
    return data as ScrapeUrl;
  } catch (error) {
    console.error('Error updating scrape URL:', error);
    return null;
  }
}

export async function deleteScrapeUrl(url: string, userId: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .rpc('soft_delete_scrape_url', { url_param: url, user_id: userId });
    
    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error deleting scrape URL:', error);
    return false;
  }
}

export async function bulkUpdateStatus(
  urls: string[], 
  status: 'pending' | 'success' | 'failed',
  userId: string
): Promise<boolean> {
  try {
    const { error } = await supabase
      .rpc('bulk_update_scrape_urls_status', { 
        urls, 
        new_status: status, 
        user_id: userId 
      });
    
    if (error) throw error;
    
    return true;
  } catch (error) {
    console.error('Error bulk updating status:', error);
    return false;
  }
}

export async function fetchAuditLogs(url: string): Promise<ScrapeAuditLog[]> {
  try {
    const { data, error } = await supabase
      .from('scrape_audit_logs')
      .select('*')
      .eq('url', url)
      .order('performed_at', { ascending: false });
    
    if (error) throw error;
    
    return data as ScrapeAuditLog[];
  } catch (error) {
    console.error('Error fetching audit logs:', error);
    return [];
  }
}

export async function fetchScrapeHistory(url: string): Promise<ScrapeHistory[]> {
  try {
    const { data, error } = await supabase
      .from('scrape_history')
      .select('*')
      .eq('url', url)
      .order('start_time', { ascending: false });
    
    if (error) throw error;
    
    return data as ScrapeHistory[];
  } catch (error) {
    console.error('Error fetching scrape history:', error);
    return [];
  }
}

export async function exportScrapeUrls(): Promise<ScrapeUrlWithStats[]> {
  try {
    const { data, error } = await supabase
      .from('v_scrape_urls_with_stats')
      .select('*')
      .order('date_added', { ascending: false });
    
    if (error) throw error;
    
    return data as ScrapeUrlWithStats[];
  } catch (error) {
    console.error('Error exporting scrape URLs:', error);
    return [];
  }
}