import { createClient, User } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Create a mock client for when Supabase is unavailable
const createMockClient = () => {
  console.warn('Using mock Supabase client due to connection issues');
  
  // Sample data for simulations
  const mockSimulations = Array.from({ length: 20 }, (_, i) => ({
    id: `mock-${i}`,
    created_at: new Date().toISOString(),
    llm_model: i % 2 === 0 ? 'anthropic/claude-2' : 'openai/chatgpt-4o-latest',
    sql_query: `SELECT * FROM mock_table_${i} WHERE id > 100;`,
    query_plan: `XN Seq Scan on mock_table_${i} (cost=0.00..${i * 10}.60 rows=${i * 1000} width=16)\n  Filter: (id > 100)`,
    complexity: (i % 5) + 1
  }));

  return {
    auth: {
      getUser: async () => ({ data: { user: null }, error: null }),
      getSession: async () => ({ data: { session: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
      signOut: async () => ({ error: null }),
      signInWithPassword: async () => ({ data: { user: null }, error: { message: 'Mock auth error' } }),
      signUp: async () => ({ data: { user: null }, error: { message: 'Mock auth error' } }),
      signInWithOAuth: async () => ({ data: null, error: { message: 'Mock auth error' } }),
      resetPasswordForEmail: async () => ({ error: null }),
      updateUser: async () => ({ error: null }),
      resend: async () => ({ error: null })
    },
    from: (table: string) => ({
      select: (columns: string = '*', options: any = {}) => ({
        eq: (column: string, value: any) => ({
          eq: (column2: string, value2: any) => ({
            limit: (n: number) => ({
              single: async () => {
                if (table === 'redshift_simulations') {
                  const filtered = mockSimulations.filter(
                    s => s.llm_model === value && s.complexity === value2
                  );
                  return {
                    data: filtered.length > 0 ? filtered[0] : null,
                    error: null
                  };
                }
                return { data: null, error: null };
              }
            })
          }),
          limit: (n: number) => ({
            single: async () => {
              if (table === 'redshift_simulations') {
                const filtered = mockSimulations.filter(s => s.llm_model === value);
                return {
                  data: filtered.length > 0 ? filtered[0] : null,
                  error: null
                };
              }
              return { data: null, error: null };
            },
            maybeSingle: async () => {
              return { data: null, error: null };
            }
          }),
          maybeSingle: async () => {
            return { data: null, error: null };
          }
        }),
        neq: (column: string, value: any) => ({
          limit: (n: number) => ({
            single: async () => ({ data: null, error: null })
          })
        }),
        limit: (n: number) => ({
          single: async () => ({ data: null, error: null }),
          order: (column: string, options: any = {}) => ({
            single: async () => ({ data: null, error: null })
          })
        }),
        order: (column: string, options: any = {}) => ({
          limit: (n: number) => ({
            single: async () => ({ data: null, error: null })
          })
        }),
        count: (options: any = {}) => ({ count: 0, error: null }),
        in: (column: string, values: any[]) => ({
          select: (columns: string = '*') => ({ data: [], error: null })
        }),
        or: (query: string) => ({
          limit: (n: number) => ({ data: [], error: null })
        }),
        single: async () => ({ data: null, error: null }),
        maybeSingle: async () => ({ data: null, error: null })
      }),
      insert: (data: any) => ({
        select: (columns: string = '*') => ({
          single: async () => ({ data: { ...data, id: 'mock-id' }, error: null })
        })
      }),
      update: (data: any) => ({
        eq: (column: string, value: any) => ({
          select: (columns: string = '*') => ({
            single: async () => ({ data: { ...data, id: value }, error: null })
          })
        })
      }),
      delete: () => ({
        eq: (column: string, value: any) => ({
          then: async (callback: Function) => {
            if (callback) callback();
            return { error: null };
          }
        }),
        neq: (column: string, value: any) => ({
          then: async (callback: Function) => {
            if (callback) callback();
            return { error: null };
          }
        })
      })
    }),
    rpc: (functionName: string, params: any = {}) => ({
      then: async (callback: Function) => {
        if (callback) callback({ data: null, error: null });
        return { data: null, error: null };
      }
    }),
    functions: {
      invoke: async () => ({ data: null, error: null })
    }
  };
};

let supabase;

try {
  if (!supabaseUrl || !supabaseKey) {
    throw new Error('Missing Supabase environment variables');
  }

  supabase = createClient(supabaseUrl, supabaseKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
      flowType: 'pkce'
    }
  });

  // Test the connection
  supabase.from('redshift_simulations').select('count', { count: 'exact', head: true })
    .then(({ error }) => {
      if (error) {
        console.warn('Supabase connection test failed:', error.message);
        supabase = createMockClient();
      }
    })
    .catch(err => {
      console.warn('Supabase connection error:', err.message);
      supabase = createMockClient();
    });
} catch (error) {
  console.warn('Error initializing Supabase client:', error);
  supabase = createMockClient();
}

export { supabase };

export interface RedshiftSimulation {
  id: string;
  created_at: string;
  llm_model: string;
  sql_query: string;
  query_plan: string;
  complexity: number;
}