import axios from 'axios';

interface GeminiResponse {
  candidates: Array<{
    content: {
      parts: Array<{
        text: string;
      }>;
    };
  }>;
}

export async function generateMermaidWithGemini(queryPlan: string): Promise<string> {
  try {
    const apiKey = import.meta.env.VITE_GOOGLE_GEMINI_TOKEN;
    
    if (!apiKey) {
      throw new Error('Gemini API token is not configured. Please check your environment variables.');
    }

    const response = await axios.post<GeminiResponse>(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${apiKey}`,
      {
        contents: [
          {
            parts: [
              {
                text: `Generate a Mermaid diagram to represent this SQL execution plan. Ensure the diagram follows these guidelines:

Flow: The diagram should be read from bottom to top, reflecting the execution order of the plan.
Shapes: Use different shapes for different node types:
Hash Join: Parallelogram (e.g., [/Hash Join/])
Hash Aggregate: Double-braced shape (e.g., {{Hash Aggregate}})
Sort: Diamond (e.g., {Sort})
Other nodes: Standard rectangle ([Seq Scan])

Cost and Colors:
Categorize the relative cost of each step as LOW, MEDIUM, HIGH, or HIGHEST.
Use corresponding colors for the nodes:
LOW: Green (#90EE90)
MEDIUM: Yellow (#FFFFE0)
HIGH: Amber (#FFBF00)
HIGHEST: Red (#FF6347)

Details:
For Seq Scan nodes, include the table name, alias (if any), and the filter predicate.
For Hash Join nodes, show the join condition and the tables being joined.
For Hash nodes, indicate the field being hashed.
For Aggregate nodes, show the grouping and aggregate functions.
For Sort nodes, show the For Sort nodes, show the sort order.
For Filter nodes, show the filter condition.

Join Visualization:
Clearly illustrate the left and right sides of the joins.
Add explicit Hash nodes before each Hash Join to show the hash operations.
Use arrows to show the flow of data from the scans to the hashes and then to the joins.

IMPORTANT: 
1. Express costs as LOW, MEDIUM, HIGH, HIGHEST in relative terms
2. Express row counts as K, M, B (e.g., 1.7K, 2.7M, 23B)
3. Return ONLY the Mermaid script, nothing else. No explanations, no markdown formatting, no code blocks.
4. CRITICAL: Use ONLY flowchart TD syntax, not graph BT or any other syntax
5. CRITICAL: Do not use subgraph syntax unless you're 100% sure it's correct
6. CRITICAL: Ensure all node IDs are simple alphanumeric strings without hyphens
7. CRITICAL: Avoid any syntax that might cause parsing errors
8. CRITICAL: For node labels with multiple lines, use <br> for line breaks, not newlines
9. CRITICAL: For Sort Key, Hash Cond, and other details, escape any special characters and use proper syntax
10. CRITICAL: Do not include colons or other special characters in node text that might break the syntax
11. CRITICAL: Use simple quotes for text with special characters, e.g., ["Text with special chars"]
12. CRITICAL: Avoid using parentheses in node text unless properly escaped

Here is the SQL execution plan:

${queryPlan}`
              }
            ]
          }
        ],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 8192
        }
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    if (!response.data?.candidates?.[0]?.content?.parts?.[0]?.text) {
      throw new Error('Invalid response format from Gemini API');
    }

    const content = response.data.candidates[0].content.parts[0].text.trim();
    
    // Clean up the response to ensure it's just the Mermaid script
    let mermaidScript = content;
    
    // Remove markdown code block markers if present
    mermaidScript = mermaidScript.replace(/```mermaid\s*/g, '');
    mermaidScript = mermaidScript.replace(/```\s*$/g, '');
    
    // Ensure the script starts with flowchart TD
    if (!mermaidScript.trim().startsWith('flowchart TD') && !mermaidScript.trim().startsWith('graph TD')) {
      mermaidScript = 'flowchart TD\n' + mermaidScript;
    }
    
    // Fix common syntax issues
    mermaidScript = mermaidScript
      // Ensure flowchart TD is used, not graph BT
      .replace(/graph\s+BT/g, 'flowchart TD')
      .replace(/graph\s+TD/g, 'flowchart TD')
      // Fix node IDs with hyphens
      .replace(/([A-Za-z0-9_]+)-([A-Za-z0-9_]+)/g, '$1_$2')
      // Fix subgraph syntax if needed
      .replace(/subgraph\s+([^"\n]+)$/gm, (match, title) => {
        if (title.includes('"')) return match;
        return `subgraph "${title}"`;
      })
      // Fix class definitions
      .replace(/classDef\s+([A-Za-z0-9_-]+)\s+([^"\n]+)$/gm, (match, className, style) => {
        if (style.includes('"')) return match;
        return `classDef ${className} "${style}"`;
      })
      // Fix Sort Key syntax issues
      .replace(/Sort Key: ([^\n<]+)/g, 'Sort Key $1')
      // Fix Hash Cond syntax issues
      .replace(/Hash Cond: ([^\n<]+)/g, 'Hash Cond $1')
      // Fix Filter syntax issues
      .replace(/Filter: ([^\n<]+)/g, 'Filter $1')
      // Replace any remaining colons in node text with spaces or dashes
      .replace(/([\w\s]+):([\w\s]+)/g, '$1 - $2')
      // Ensure proper line breaks in node labels
      .replace(/\n\s+/g, '<br>')
      // Remove any remaining graph BT or other invalid directives
      .replace(/graph\s+[A-Z]{2}\s+/g, '')
      // Fix arrow syntax
      .replace(/-->/g, ' --> ')
      // Fix node labels with problematic characters
      .replace(/\[(.*?):(.*?)\]/g, '["$1 - $2"]')
      .replace(/\{(.*?):(.*?)\}/g, '{"$1 - $2"}')
      .replace(/\{\{(.*?):(.*?)\}\}/g, '{{"$1 - $2"}}')
      // Fix parentheses in node text
      .replace(/\(([^)]*)\)/g, (match, content) => {
        // Don't replace if it's part of a node shape definition
        if (match.startsWith('((') || match.endsWith('))')) return match;
        return content.replace(/[()]/g, '');
      });
    
    return mermaidScript;
  } catch (error) {
    console.error('Error generating Mermaid script with Gemini:', error);
    
    if (axios.isAxiosError(error)) {
      const errorMessage = error.response?.data?.error?.message || error.message;
      throw new Error(`Gemini API Error: ${errorMessage}`);
    }
    
    throw error;
  }
}