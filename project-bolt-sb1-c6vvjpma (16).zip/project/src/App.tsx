import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { QueryAnalytics } from './pages/QueryAnalytics';
import { QueryVisualizer } from './pages/QueryVisualizer';
import { ScriptsPage } from './pages/ScriptsPage';
import { ScriptFormPage } from './pages/ScriptFormPage';
import { AuthCallbackPage } from './pages/AuthCallbackPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { ProfilePage } from './pages/ProfilePage';
import { DataImportPage } from './pages/DataImportPage';
import { ForumLayout } from './components/Forum/ForumLayout';
import { ForumHome } from './components/Forum/ForumHome';
import { AppLayout } from './components/Layout/AppLayout';
import { ContentDashboard } from './pages/ContentDashboard';
import { AdminDashboard } from './pages/AdminDashboard';

function App() {
  return (
    <Router>
      <Routes>
        {/* Protected Admin Routes */}
        <Route path="/admin" element={<AppLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="content" element={<ContentDashboard />} />
        </Route>

        {/* Main App Routes */}
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/analytics" element={<QueryAnalytics />} />
          <Route path="/visualizer" element={<QueryVisualizer />} />
          <Route path="/scripts" element={<ScriptsPage />} />
          <Route path="/scripts/new" element={<ScriptFormPage />} />
          <Route path="/scripts/:scriptId" element={<ScriptFormPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/data-explorer" element={<DataImportPage />} />
          <Route path="/forum" element={<ForumLayout />}>
            <Route index element={<ForumHome />} />
          </Route>
        </Route>

        {/* Auth Routes */}
        <Route path="/auth/callback" element={<AuthCallbackPage />} />
        <Route path="/auth/reset-password" element={<ResetPasswordPage />} />
      </Routes>
    </Router>
  );
}

export default App;