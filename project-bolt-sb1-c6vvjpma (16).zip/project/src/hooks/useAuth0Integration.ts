import { useEffect, useState } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { supabase } from '../services/supabase';
import { mapAuth0UserToSupabase, getAuth0UserRoles, isUserAdmin } from '../services/auth0';

export function useAuth0Integration() {
  const { isAuthenticated, isLoading, user, loginWithRedirect, logout, getAccessTokenSilently } = useAuth0();
  const [roles, setRoles] = useState<string[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [supabaseUser, setSupabaseUser] = useState(null);
  const [isSupabaseLoading, setIsSupabaseLoading] = useState(true);

  useEffect(() => {
    if (isAuthenticated && user) {
      // Sync Auth0 user with Supabase
      const syncUserWithSupabase = async () => {
        try {
          setIsSupabaseLoading(true);
          
          // Get Auth0 token
          const token = await getAccessTokenSilently();
          
          // Sign in to Supabase with custom JWT
          const { data, error } = await supabase.auth.signInWithIdToken({
            provider: 'auth0',
            token,
            nonce: 'auth0-nonce', // This should be properly generated and verified in production
          });
          
          if (error) {
            console.error('Error signing in to Supabase:', error);
            
            // Fallback: Update Supabase user metadata directly
            const mappedUser = mapAuth0UserToSupabase(user);
            await supabase.auth.updateUser({
              data: mappedUser.user_metadata
            });
          } else {
            setSupabaseUser(data.user);
          }
          
          // Get user roles
          const userRoles = await getAuth0UserRoles(getAccessTokenSilently);
          setRoles(userRoles);
          
          // Check if user is admin
          const userIsAdmin = await isUserAdmin(getAccessTokenSilently);
          setIsAdmin(userIsAdmin);
        } catch (error) {
          console.error('Error syncing user with Supabase:', error);
        } finally {
          setIsSupabaseLoading(false);
        }
      };
      
      syncUserWithSupabase();
    } else {
      setRoles([]);
      setIsAdmin(false);
      setSupabaseUser(null);
      setIsSupabaseLoading(false);
    }
  }, [isAuthenticated, user, getAccessTokenSilently]);

  return {
    isAuthenticated,
    isLoading: isLoading || isSupabaseLoading,
    user,
    supabaseUser,
    roles,
    isAdmin,
    loginWithRedirect,
    logout: () => {
      // Sign out from Supabase first
      supabase.auth.signOut().then(() => {
        // Then sign out from Auth0
        logout({ returnTo: window.location.origin });
      });
    },
    getAccessTokenSilently
  };
}