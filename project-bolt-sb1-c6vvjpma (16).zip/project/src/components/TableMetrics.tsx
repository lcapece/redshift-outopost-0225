import React from 'react';
import { Clipboard } from 'lucide-react';

interface TableMetrics {
  dbname: string;
  schemaname: string;
  tablename: string;
  encoded: boolean;
  diststyle: string;
  dist_key?: string;
  sortkey1: string;
  sortkey1_enc: string;
  sortkey_num: number;
  size_gb: number;
  pct_empty: number;
  unsorted_pct: number;
  stats_off: number;
  tbl_rows: number;
  skew_sortkey1: number;
  skew_rows: number;
  estimated_visible_rows: number;
  risk_event: string;
}

interface Props {
  metrics: TableMetrics[];
  onIngestClipboard: () => void;
}

function truncateText(text: string, maxLength: number = 12): string {
  if (!text || text.length <= maxLength) return text || '';
  return text.substring(0, maxLength - 3) + '...';
}

function formatDistStyle(style: string, key?: string): JSX.Element {
  if (style === 'ALL') {
    return (
      <span className="bg-green-600 text-white px-1 rounded">ALL</span>
    );
  }
  if (style === 'KEY' && key) {
    return (
      <span>
        KEY({truncateText(key)})
      </span>
    );
  }
  return <span>{style}</span>;
}

function formatSortKey(key: string): JSX.Element {
  if (!key) {
    return (
      <span className="bg-red-600 text-white px-1 rounded">None</span>
    );
  }
  return <span>{key}</span>;
}

function getMetricColor(value: number, type: 'stats' | 'sorted' | 'skew'): string {
  if (type === 'stats') {
    if (value < 50) return 'text-red-600';
    if (value < 80) return 'text-amber-600';
    return 'text-green-600';
  }
  if (type === 'sorted') {
    if (value < 65) return 'text-red-600';
    if (value < 85) return 'text-amber-600';
    return 'text-green-600';
  }
  if (type === 'skew') {
    if (value > 5) return 'text-red-600';
    if (value > 2) return 'text-amber-600';
    return 'text-green-600';
  }
  return '';
}

export function TableMetrics({ metrics, onIngestClipboard }: Props) {
  return (
    <div className="bg-white rounded shadow">
      <div className="flex justify-between items-center p-3 border-b">
        <h2 className="text-lg font-semibold text-gray-900">Table Metrics</h2>
        <button
          onClick={onIngestClipboard}
          className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          <Clipboard className="h-4 w-4 mr-1.5" />
          Ingest Clipboard
        </button>
      </div>
      <div className="p-3 overflow-x-auto">
        <div className="inline-block min-w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {metrics.map((metric) => (
              <div
                key={`${metric.schemaname}.${metric.tablename}`}
                className="bg-gray-50 rounded p-3 border border-gray-100"
              >
                <div className="mb-2">
                  <h3 className="font-medium text-sm text-gray-900">
                    {metric.schemaname}.{metric.tablename}
                  </h3>
                </div>
                <dl className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <dt className="text-gray-500">Rows</dt>
                    <dd className="font-mono">{metric.tbl_rows.toLocaleString()}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Size</dt>
                    <dd className="font-mono">{metric.size_gb} GB</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Distribution</dt>
                    <dd className="font-mono">{formatDistStyle(metric.diststyle, metric.dist_key)}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Sort Key</dt>
                    <dd className="font-mono">{formatSortKey(metric.sortkey1)}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Stats Fresh</dt>
                    <dd className={`font-mono ${getMetricColor(100 - metric.stats_off, 'stats')}`}>
                      {(100 - metric.stats_off).toFixed(1)}%
                    </dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Pct Sorted</dt>
                    <dd className={`font-mono ${getMetricColor(100 - metric.unsorted_pct, 'sorted')}`}>
                      {(100 - metric.unsorted_pct).toFixed(1)}%
                    </dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Dist Skew</dt>
                    <dd className={`font-mono ${getMetricColor(metric.skew_rows, 'skew')}`}>
                      {metric.skew_rows.toFixed(2)}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-gray-500">Sort Skew</dt>
                    <dd className={`font-mono ${getMetricColor(metric.skew_sortkey1, 'skew')}`}>
                      {metric.skew_sortkey1.toFixed(2)}
                    </dd>
                  </div>
                </dl>
              </div>
            ))}
            {metrics.length === 0 && (
              <p className="text-sm text-gray-500">
                No table metrics available. Generate an example or ingest from clipboard.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}