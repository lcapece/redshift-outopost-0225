import React, { useState, useEffect, useRef } from 'react';
import { Search, Send, Brain, Loader, RefreshCw, AlertCircle } from 'lucide-react';
import { LlmModelSelector } from './LlmModelSelector';
import { supabase } from '../services/supabase';

interface SearchResult {
  id: string;
  title: string;
  description: string;
  category: string;
  script_type: string;
  relevance: number;
  snippet?: string;
  tags: string[];
}

interface SearchSuggestion {
  text: string;
  type: 'refinement' | 'category' | 'feature';
  description: string;
}

export function ScriptSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState('anthropic/claude-3-sonnet');
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);

  useEffect(() => {
    // Load search history from local storage
    const history = localStorage.getItem('scriptSearchHistory');
    if (history) {
      setSearchHistory(JSON.parse(history));
    }
  }, []);

  const handleSearch = async () => {
    if (!query.trim()) return;
    
    setIsSearching(true);
    setError(null);
    
    try {
      // First, get embeddings for the query using Claude
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': import.meta.env.VITE_CLAUDE_API_KEY,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: "claude-3-sonnet-20240229",
          max_tokens: 4000,
          temperature: 0.2,
          system: "You are an expert at understanding SQL scripts and database concepts. Your task is to analyze the user's query and extract key concepts, technical terms, and implied requirements to help find relevant scripts.",
          messages: [
            {
              role: "user",
              content: `Analyze this search query and return a JSON object with:
1. Key technical terms and concepts
2. Implied requirements or use cases
3. Relevant script categories
4. SQL-specific features mentioned
5. Suggested refinements

Query: ${query}

Format the response as a JSON object with these exact fields:
{
  "terms": ["array of technical terms"],
  "requirements": ["array of implied needs"],
  "categories": ["array of relevant categories"],
  "features": ["array of SQL features"],
  "refinements": ["array of suggested query refinements"]
}`
            }
          ]
        })
      });

      if (!response.ok) {
        throw new Error('Failed to analyze query');
      }

      const analysis = await response.json();
      
      // Search Supabase using the extracted concepts
      const { data: scripts, error: searchError } = await supabase
        .from('redshift_scripts')
        .select('*')
        .or(
          analysis.terms.map(term => `
            title.ilike.%${term}%,
            description.ilike.%${term}%,
            script_content.ilike.%${term}%,
            tags.cs.{${term}}
          `).join(',')
        )
        .eq('status', 'published')
        .order('views', { ascending: false });

      if (searchError) throw searchError;

      // Process and rank results
      const processedResults = scripts.map(script => {
        // Calculate relevance score
        let relevance = 0;
        
        // Title matches
        analysis.terms.forEach(term => {
          if (script.title.toLowerCase().includes(term.toLowerCase())) {
            relevance += 3;
          }
        });
        
        // Description matches
        analysis.terms.forEach(term => {
          if (script.description.toLowerCase().includes(term.toLowerCase())) {
            relevance += 2;
          }
        });
        
        // Content matches
        analysis.terms.forEach(term => {
          if (script.script_content.toLowerCase().includes(term.toLowerCase())) {
            relevance += 1;
          }
        });
        
        // Tag matches
        if (script.tags) {
          analysis.terms.forEach(term => {
            if (script.tags.includes(term.toLowerCase())) {
              relevance += 2;
            }
          });
        }
        
        // Category matches
        if (analysis.categories.includes(script.category)) {
          relevance += 2;
        }

        return {
          ...script,
          relevance,
          snippet: extractRelevantSnippet(script.script_content, analysis.terms)
        };
      });

      // Sort by relevance
      const sortedResults = processedResults
        .filter(r => r.relevance > 0)
        .sort((a, b) => b.relevance - a.relevance);

      setResults(sortedResults);
      
      // Generate search suggestions
      const newSuggestions: SearchSuggestion[] = [
        ...analysis.refinements.map(r => ({
          text: r,
          type: 'refinement' as const,
          description: 'Try this refined search query'
        })),
        ...analysis.categories.map(c => ({
          text: c,
          type: 'category' as const,
          description: 'Filter by this category'
        })),
        ...analysis.features.map(f => ({
          text: f,
          type: 'feature' as const,
          description: 'Search for scripts using this feature'
        }))
      ];
      
      setSuggestions(newSuggestions);
      
      // Update search history
      const updatedHistory = [query, ...searchHistory.filter(h => h !== query)].slice(0, 10);
      setSearchHistory(updatedHistory);
      localStorage.setItem('scriptSearchHistory', JSON.stringify(updatedHistory));
      
    } catch (err) {
      console.error('Search error:', err);
      setError('Failed to perform search. Please try again.');
    } finally {
      setIsSearching(false);
    }
  };

  const extractRelevantSnippet = (content: string, terms: string[]): string => {
    const maxLength = 200;
    const snippets: string[] = [];
    
    terms.forEach(term => {
      const index = content.toLowerCase().indexOf(term.toLowerCase());
      if (index >= 0) {
        const start = Math.max(0, index - 50);
        const end = Math.min(content.length, index + term.length + 50);
        snippets.push(content.substring(start, end));
      }
    });
    
    if (snippets.length === 0) {
      return content.substring(0, maxLength) + '...';
    }
    
    return snippets[0].length > maxLength ? 
      snippets[0].substring(0, maxLength) + '...' : 
      snippets[0];
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    setQuery(suggestion.text);
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  const handleHistoryClick = (historicQuery: string) => {
    setQuery(historicQuery);
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex items-start space-x-4">
          <div className="flex-1">
            <div className="relative">
              <input
                ref={searchInputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="How can I help you find what you need today?"
                className="block w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-lg"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                <button
                  onClick={handleSearch}
                  disabled={isSearching || !query.trim()}
                  className="inline-flex items-center p-1.5 border border-transparent rounded-full text-indigo-600 hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  {isSearching ? (
                    <Loader className="h-5 w-5 animate-spin" />
                  ) : (
                    <Send className="h-5 w-5" />
                  )}
                </button>
              </div>
            </div>
            
            {searchHistory.length > 0 && !query && (
              <div className="mt-2">
                <h3 className="text-sm font-medium text-gray-500 mb-2">Recent Searches</h3>
                <div className="flex flex-wrap gap-2">
                  {searchHistory.map((historicQuery, index) => (
                    <button
                      key={index}
                      onClick={() => handleHistoryClick(historicQuery)}
                      className="inline-flex items-center px-2.5 py-1.5 border border-gray-300 text-xs font-medium rounded text-gray-700 bg-white hover:bg-gray-50"
                    >
                      <RefreshCw className="h-3 w-3 mr-1" />
                      {historicQuery}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          <div>
            <LlmModelSelector
              selectedModel={selectedModel}
              onModelChange={setSelectedModel}
              disabled={isSearching}
              showInfo={false}
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <span className="text-red-700">{error}</span>
          </div>
        </div>
      )}

      {suggestions.length > 0 && (
        <div className="mb-8">
          <h3 className="text-sm font-medium text-gray-500 mb-2">Suggestions</h3>
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleSuggestionClick(suggestion)}
                className={`inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium ${
                  suggestion.type === 'refinement' ? 'bg-blue-100 text-blue-800' :
                  suggestion.type === 'category' ? 'bg-green-100 text-green-800' :
                  'bg-purple-100 text-purple-800'
                }`}
                title={suggestion.description}
              >
                {suggestion.type === 'refinement' && <RefreshCw className="h-3 w-3 mr-1" />}
                {suggestion.type === 'category' && <Search className="h-3 w-3 mr-1" />}
                {suggestion.type === 'feature' && <Brain className="h-3 w-3 mr-1" />}
                {suggestion.text}
              </button>
            ))}
          </div>
        </div>
      )}

      {results.length > 0 ? (
        <div className="space-y-6">
          {results.map((result) => (
            <div key={result.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-1">
                    {result.title}
                  </h3>
                  <p className="text-sm text-gray-500 mb-2">
                    {result.description}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    result.relevance > 7 ? 'bg-green-100 text-green-800' :
                    result.relevance > 4 ? 'bg-yellow-100 text-yellow-800' :
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {result.relevance > 7 ? 'Best Match' :
                     result.relevance > 4 ? 'Good Match' :
                     'Relevant'}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                    {result.category}
                  </span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                    {result.script_type}
                  </span>
                </div>
              </div>
              
              {result.snippet && (
                <div className="mt-3 bg-gray-50 rounded p-3 font-mono text-sm text-gray-700 overflow-x-auto">
                  {result.snippet}
                </div>
              )}
              
              {result.tags && result.tags.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-1">
                  {result.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      ) : query && !isSearching ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No scripts found matching your search.</p>
        </div>
      ) : null}
    </div>
  );
}