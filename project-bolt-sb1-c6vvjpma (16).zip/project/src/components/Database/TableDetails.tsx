import React, { useState } from 'react';
import { Table, Key, Eye, EyeOff, Download, Copy, CheckCircle } from 'lucide-react';

interface TableInfo {
  schema: string;
  name: string;
  attributes: Array<{
    name: string;
    type: string;
    nullable: boolean;
  }>;
}

interface TableDetailsProps {
  table: TableInfo;
}

export function TableDetails({ table }: TableDetailsProps) {
  const [showSensitiveData, setShowSensitiveData] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyDDL = async () => {
    const ddl = generateTableDDL(table);
    try {
      await navigator.clipboard.writeText(ddl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy DDL:', err);
    }
  };

  const generateTableDDL = (table: TableInfo): string => {
    const lines = [
      `CREATE TABLE ${table.schema}.${table.name} (`,
      ...table.attributes.map(attr => 
        `  ${attr.name} ${attr.type}${attr.nullable ? '' : ' NOT NULL'}`
      ),
      ');'
    ];
    return lines.join('\n');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Table className="h-6 w-6 text-indigo-600 mr-2" />
            <div>
              <h2 className="text-lg font-medium text-gray-900">{table.name}</h2>
              <p className="text-sm text-gray-500">{table.schema}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowSensitiveData(!showSensitiveData)}
              className="p-2 text-gray-400 hover:text-gray-500"
              title={showSensitiveData ? 'Hide sensitive data' : 'Show sensitive data'}
            >
              {showSensitiveData ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
            <button
              onClick={handleCopyDDL}
              className="p-2 text-gray-400 hover:text-gray-500"
              title="Copy DDL"
            >
              {copied ? <CheckCircle className="h-5 w-5 text-green-500" /> : <Copy className="h-5 w-5" />}
            </button>
            <button
              onClick={() => {/* Handle export */}}
              className="p-2 text-gray-400 hover:text-gray-500"
              title="Export table data"
            >
              <Download className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-6">
          {/* Table Attributes */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Columns</h3>
            <div className="bg-gray-50 rounded-lg overflow-hidden border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nullable</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Key</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {table.attributes.map((attr, index) => (
                    <tr key={attr.name} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {attr.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {attr.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {attr.nullable ? 'Yes' : 'No'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {attr.name.toLowerCase().includes('key') && (
                          <Key className="h-4 w-4 text-indigo-500" />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table Statistics */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-3">Statistics</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="text-sm font-medium text-gray-500">Row Count</div>
                <div className="mt-1 text-2xl font-semibold text-gray-900">
                  {showSensitiveData ? '1,234,567' : '****'}
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="text-sm font-medium text-gray-500">Size</div>
                <div className="mt-1 text-2xl font-semibold text-gray-900">
                  {showSensitiveData ? '2.5 GB' : '****'}
                </div>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <div className="text-sm font-medium text-gray-500">Last Updated</div>
                <div className="mt-1 text-2xl font-semibold text-gray-900">
                  {new Date().toLocaleDateString()}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}