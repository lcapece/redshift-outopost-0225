import React from 'react';
import { ChevronDown, ChevronRight, Database, Table, Key } from 'lucide-react';

interface TableInfo {
  schema: string;
  name: string;
  attributes: Array<{
    name: string;
    type: string;
    nullable: boolean;
  }>;
}

interface DatabaseNavigatorProps {
  schemas: string[];
  tables: Record<string, TableInfo[]>;
  selectedSchema: string | null;
  selectedTable: TableInfo | null;
  onSchemaSelect: (schema: string) => void;
  onTableSelect: (table: TableInfo) => void;
  searchTerm: string;
}

export function DatabaseNavigator({
  schemas,
  tables,
  selectedSchema,
  selectedTable,
  onSchemaSelect,
  onTableSelect,
  searchTerm
}: DatabaseNavigatorProps) {
  const filteredSchemas = searchTerm
    ? schemas.filter(schema => 
        schema.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tables[schema]?.some(table => 
          table.name.toLowerCase().includes(searchTerm.toLowerCase())
        )
      )
    : schemas;

  return (
    <div className="overflow-y-auto h-[calc(100vh-16rem)]">
      <div className="px-4 py-5 sm:p-6">
        <div className="space-y-1">
          {filteredSchemas.map(schema => (
            <div key={schema}>
              <button
                onClick={() => onSchemaSelect(schema)}
                className={`w-full flex items-center px-2 py-2 text-sm font-medium rounded-md ${
                  selectedSchema === schema
                    ? 'bg-gray-100 text-gray-900'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                {selectedSchema === schema ? (
                  <ChevronDown className="h-4 w-4 mr-2" />
                ) : (
                  <ChevronRight className="h-4 w-4 mr-2" />
                )}
                <Database className="h-4 w-4 mr-2" />
                {schema}
              </button>

              {selectedSchema === schema && tables[schema] && (
                <div className="ml-6 mt-1 space-y-1">
                  {tables[schema]
                    .filter(table => 
                      !searchTerm || 
                      table.name.toLowerCase().includes(searchTerm.toLowerCase())
                    )
                    .map(table => (
                      <button
                        key={table.name}
                        onClick={() => onTableSelect(table)}
                        className={`w-full flex items-center px-2 py-2 text-sm rounded-md ${
                          selectedTable?.name === table.name
                            ? 'bg-indigo-50 text-indigo-600'
                            : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                        }`}
                      >
                        <Table className="h-4 w-4 mr-2" />
                        {table.name}
                      </button>
                    ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}