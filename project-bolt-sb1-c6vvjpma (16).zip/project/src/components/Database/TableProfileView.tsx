import React, { useState } from 'react';
import { 
  Database, Table, Key, Lock, Calendar, User, BarChart2, 
  HardDrive, GitBranch, Eye, EyeOff, AlertTriangle, CheckCircle,
  Info, ChevronRight, ChevronDown
} from 'lucide-react';

interface TableProfile {
  // Basic Info
  name: string;
  schema: string;
  owner: string;
  created_at: string;
  updated_at: string;
  comment?: string;

  // Storage Metrics
  size_gb: number;
  pct_empty: number;
  unsorted_pct: number;
  stats_off: number;
  encoded: boolean;

  // Row Statistics
  tbl_rows: number;
  estimated_visible_rows: number;
  deleted_rows?: number;

  // Distribution Info
  diststyle: string;
  dist_key?: string;
  skew_rows: number;

  // Sort Key Info
  sortkey1?: string;
  sortkey1_enc?: string;
  sortkey_num: number;
  skew_sortkey1: number;

  // Columns
  columns: Array<{
    name: string;
    type: string;
    nullable: boolean;
    default_value?: string;
    encoding?: string;
    is_primary_key: boolean;
    is_foreign_key: boolean;
    references?: {
      table: string;
      column: string;
    };
  }>;

  // Constraints
  constraints: Array<{
    name: string;
    type: 'p' | 'f' | 'u' | 'c';
    definition: string;
  }>;

  // Indexes
  indexes: Array<{
    name: string;
    columns: string[];
    unique: boolean;
    definition: string;
  }>;

  // Partitioning
  partition_key?: string;
  partition_type?: string;
  partition_count?: number;

  // Permissions
  permissions: Array<{
    grantee: string;
    privilege_type: string;
    is_grantable: boolean;
  }>;
}

interface TableProfileViewProps {
  profile: TableProfile;
  onRefresh?: () => void;
}

export function TableProfileView({ profile, onRefresh }: TableProfileViewProps) {
  const [showSensitiveData, setShowSensitiveData] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['basic', 'metrics']));

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const formatMetric = (value: number, type: 'percentage' | 'size' | 'number'): string => {
    if (type === 'percentage') {
      return `${value.toFixed(1)}%`;
    } else if (type === 'size') {
      if (value >= 1024) {
        return `${(value / 1024).toFixed(1)} TB`;
      }
      return `${value.toFixed(1)} GB`;
    }
    return value.toLocaleString();
  };

  const getMetricStatus = (
    value: number, 
    thresholds: { warning: number; critical: number },
    isHigherBetter: boolean
  ): { color: string; icon: JSX.Element } => {
    if (isHigherBetter) {
      if (value >= thresholds.warning) {
        return { color: 'text-green-600', icon: <CheckCircle className="h-4 w-4" /> };
      } else if (value >= thresholds.critical) {
        return { color: 'text-amber-600', icon: <AlertTriangle className="h-4 w-4" /> };
      }
      return { color: 'text-red-600', icon: <AlertTriangle className="h-4 w-4" /> };
    } else {
      if (value <= thresholds.warning) {
        return { color: 'text-green-600', icon: <CheckCircle className="h-4 w-4" /> };
      } else if (value <= thresholds.critical) {
        return { color: 'text-amber-600', icon: <AlertTriangle className="h-4 w-4" /> };
      }
      return { color: 'text-red-600', icon: <AlertTriangle className="h-4 w-4" /> };
    }
  };

  const Section = ({ 
    id, 
    title, 
    icon: Icon, 
    children 
  }: { 
    id: string; 
    title: string; 
    icon: React.ElementType; 
    children: React.ReactNode;
  }) => (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div 
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50"
        onClick={() => toggleSection(id)}
      >
        <div className="flex items-center space-x-2">
          <Icon className="h-5 w-5 text-gray-500" />
          <h3 className="font-medium text-gray-900">{title}</h3>
        </div>
        {expandedSections.has(id) ? (
          <ChevronDown className="h-5 w-5 text-gray-400" />
        ) : (
          <ChevronRight className="h-5 w-5 text-gray-400" />
        )}
      </div>
      {expandedSections.has(id) && (
        <div className="border-t border-gray-200 p-4">{children}</div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold text-gray-900">
            {profile.schema}.{profile.name}
          </h2>
          <button
            onClick={() => setShowSensitiveData(!showSensitiveData)}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            {showSensitiveData ? (
              <>
                <EyeOff className="h-4 w-4 mr-1.5" />
                Hide Sensitive Data
              </>
            ) : (
              <>
                <Eye className="h-4 w-4 mr-1.5" />
                Show Sensitive Data
              </>
            )}
          </button>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <BarChart2 className="h-4 w-4 mr-1.5" />
            Refresh Metrics
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Information */}
        <Section id="basic" title="Basic Information" icon={Database}>
          <dl className="grid grid-cols-2 gap-4">
            <div>
              <dt className="text-sm font-medium text-gray-500">Schema</dt>
              <dd className="mt-1 text-sm text-gray-900">{profile.schema}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Owner</dt>
              <dd className="mt-1 text-sm text-gray-900">{profile.owner}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Created</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {new Date(profile.created_at).toLocaleString()}
              </dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Last Modified</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {new Date(profile.updated_at).toLocaleString()}
              </dd>
            </div>
            {profile.comment && (
              <div className="col-span-2">
                <dt className="text-sm font-medium text-gray-500">Comment</dt>
                <dd className="mt-1 text-sm text-gray-900">{profile.comment}</dd>
              </div>
            )}
          </dl>
        </Section>

        {/* Storage Metrics */}
        <Section id="metrics" title="Storage Metrics" icon={HardDrive}>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium text-gray-500">Size</h4>
                <span className="text-sm font-medium text-gray-900">
                  {formatMetric(profile.size_gb, 'size')}
                </span>
              </div>
              <div className="mt-1 text-xs text-gray-500">
                {showSensitiveData ? (
                  <>Empty: {formatMetric(profile.pct_empty, 'percentage')}</>
                ) : (
                  '****'
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium text-gray-500">Rows</h4>
                <span className="text-sm font-medium text-gray-900">
                  {showSensitiveData ? formatMetric(profile.tbl_rows, 'number') : '****'}
                </span>
              </div>
              <div className="mt-1 text-xs text-gray-500">
                Estimated Visible: {formatMetric(profile.estimated_visible_rows, 'number')}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium text-gray-500">Stats Freshness</h4>
                {showSensitiveData && (
                  <span className={getMetricStatus(100 - profile.stats_off, { warning: 80, critical: 50 }, true).color}>
                    {formatMetric(100 - profile.stats_off, 'percentage')}
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-gray-500">
                {showSensitiveData ? (
                  <>Stats Off: {formatMetric(profile.stats_off, 'percentage')}</>
                ) : (
                  '****'
                )}
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium text-gray-500">Sort Status</h4>
                {showSensitiveData && (
                  <span className={getMetricStatus(100 - profile.unsorted_pct, { warning: 85, critical: 65 }, true).color}>
                    {formatMetric(100 - profile.unsorted_pct, 'percentage')}
                  </span>
                )}
              </div>
              <div className="mt-1 text-xs text-gray-500">
                {showSensitiveData ? (
                  <>Unsorted: {formatMetric(profile.unsorted_pct, 'percentage')}</>
                ) : (
                  '****'
                )}
              </div>
            </div>
          </div>
        </Section>

        {/* Distribution Info */}
        <Section id="distribution" title="Distribution Information" icon={GitBranch}>
          <dl className="grid grid-cols-2 gap-4">
            <div>
              <dt className="text-sm font-medium text-gray-500">Distribution Style</dt>
              <dd className="mt-1 text-sm text-gray-900">{profile.diststyle}</dd>
            </div>
            {profile.dist_key && (
              <div>
                <dt className="text-sm font-medium text-gray-500">Distribution Key</dt>
                <dd className="mt-1 text-sm text-gray-900">{profile.dist_key}</dd>
              </div>
            )}
            <div>
              <dt className="text-sm font-medium text-gray-500">Row Skew</dt>
              <dd className="mt-1 text-sm text-gray-900 flex items-center">
                {showSensitiveData ? (
                  <>
                    {formatMetric(profile.skew_rows, 'number')}
                    <span className={`ml-2 ${getMetricStatus(profile.skew_rows, { warning: 2, critical: 5 }, false).color}`}>
                      {getMetricStatus(profile.skew_rows, { warning: 2, critical: 5 }, false).icon}
                    </span>
                  </>
                ) : (
                  '****'
                )}
              </dd>
            </div>
          </dl>
        </Section>

        {/* Sort Key Info */}
        <Section id="sortkey" title="Sort Key Information" icon={GitBranch}>
          <dl className="grid grid-cols-2 gap-4">
            {profile.sortkey1 && (
              <>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Primary Sort Key</dt>
                  <dd className="mt-1 text-sm text-gray-900">{profile.sortkey1}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Sort Key Encoding</dt>
                  <dd className="mt-1 text-sm text-gray-900">{profile.sortkey1_enc || 'None'}</dd>
                </div>
              </>
            )}
            <div>
              <dt className="text-sm font-medium text-gray-500">Sort Keys</dt>
              <dd className="mt-1 text-sm text-gray-900">{profile.sortkey_num}</dd>
            </div>
            <div>
              <dt className="text-sm font-medium text-gray-500">Sort Key Skew</dt>
              <dd className="mt-1 text-sm text-gray-900 flex items-center">
                {showSensitiveData ? (
                  <>
                    {formatMetric(profile.skew_sortkey1, 'number')}
                    <span className={`ml-2 ${getMetricStatus(profile.skew_sortkey1, { warning: 2, critical: 5 }, false).color}`}>
                      {getMetricStatus(profile.skew_sortkey1, { warning: 2, critical: 5 }, false).icon}
                    </span>
                  </>
                ) : (
                  '****'
                )}
              </dd>
            </div>
          </dl>
        </Section>

        {/* Columns */}
        <Section id="columns" title="Column Definitions" icon={Table}>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nullable</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Default</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Keys</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {profile.columns.map((column, index) => (
                  <tr key={column.name} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-4 py-2 text-sm text-gray-900">{column.name}</td>
                    <td className="px-4 py-2 text-sm text-gray-500">{column.type}</td>
                    <td className="px-4 py-2 text-sm text-gray-500">{column.nullable ? 'Yes' : 'No'}</td>
                    <td className="px-4 py-2 text-sm text-gray-500">{column.default_value || '-'}</td>
                    <td className="px-4 py-2">
                      <div className="flex space-x-1">
                        {column.is_primary_key && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                            PK
                          </span>
                        )}
                        {column.is_foreign_key && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                            FK
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        {/* Constraints */}
        <Section id="constraints" title="Constraints" icon={Lock}>
          <div className="space-y-4">
            {profile.constraints.map((constraint) => (
              <div key={constraint.name} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                      {constraint.type === 'p' ? 'PRIMARY KEY' :
                       constraint.type === 'f' ? 'FOREIGN KEY' :
                       constraint.type === 'u' ? 'UNIQUE' : 'CHECK'}
                    </span>
                    <span className="text-sm font-medium text-gray-900">{constraint.name}</span>
                  </div>
                </div>
                <div className="mt-2">
                  <pre className="text-xs font-mono bg-white p-2 rounded border border-gray-200 overflow-x-auto">
                    {constraint.definition}
                  </pre>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Indexes */}
        <Section id="indexes" title="Indexes" icon={GitBranch}>
          <div className="space-y-4">
            {profile.indexes.map((index) => (
              <div key={index.name} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {index.unique && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                        UNIQUE
                      </span>
                    )}
                    <span className="text-sm font-medium text-gray-900">{index.name}</span>
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  Columns: {index.columns.join(', ')}
                </div>
                <div className="mt-2">
                  <pre className="text-xs font-mono bg-white p-2 rounded border border-gray-200 overflow-x-auto">
                    {index.definition}
                  </pre>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Permissions */}
        <Section id="permissions" title="Permissions" icon={User}>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Grantee</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Privilege</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Grantable</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {profile.permissions.map((permission, index) => (
                  <tr key={`${permission.grantee}-${permission.privilege_type}`} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-4 py-2 text-sm text-gray-900">{permission.grantee}</td>
                    <td className="px-4 py-2 text-sm text-gray-500">{permission.privilege_type}</td>
                    <td className="px-4 py-2 text-sm text-gray-500">{permission.is_grantable ? 'Yes' : 'No'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>
      </div>
    </div>
  );
}