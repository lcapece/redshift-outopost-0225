import React, { useState } from 'react';
import { AlertCircle, CheckCircle, Mail, RefreshCw } from 'lucide-react';
import { resendVerificationEmail } from '../services/authService';

interface EmailVerificationDialogProps {
  isOpen: boolean;
  onClose: () => void;
  email: string;
}

export function EmailVerificationDialog({ isOpen, onClose, email }: EmailVerificationDialogProps) {
  const [isResending, setIsResending] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);
  const [resendError, setResendError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleResendVerification = async () => {
    setIsResending(true);
    setResendSuccess(false);
    setResendError(null);
    
    try {
      const result = await resendVerificationEmail(email);
      
      if (result.success) {
        setResendSuccess(true);
      } else {
        setResendError(result.message || 'Failed to resend verification email');
      }
    } catch (error) {
      setResendError('An unexpected error occurred. Please try again.');
      console.error('Error resending verification email:', error);
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex flex-col items-center mb-6">
          <div className="bg-indigo-100 p-3 rounded-full mb-4">
            <Mail className="h-8 w-8 text-indigo-600" />
          </div>
          <h2 className="text-xl font-semibold text-center">Verify Your Email</h2>
        </div>
        
        <div className="mb-6">
          <p className="text-gray-700 mb-4">
            We've sent a verification email to <strong>{email}</strong>. Please check your inbox and click the verification link to complete your registration.
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-4">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0" />
              <div>
                <p className="text-sm text-blue-700">
                  If you don't see the email in your inbox, please check your spam or junk folder.
                </p>
              </div>
            </div>
          </div>
          
          {resendSuccess && (
            <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
              <div className="flex">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                <div>
                  <p className="text-sm text-green-700">
                    Verification email resent successfully! Please check your inbox.
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {resendError && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-4">
              <div className="flex">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                <div>
                  <p className="text-sm text-red-700">{resendError}</p>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex flex-col space-y-3">
          <button
            onClick={handleResendVerification}
            disabled={isResending}
            className="inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
          >
            {isResending ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Resending...
              </>
            ) : (
              'Resend Verification Email'
            )}
          </button>
          
          <button
            onClick={onClose}
            className="inline-flex justify-center items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}