import React from 'react';
import { MessageSquare, Users, Bookmark, Settings, PlusCircle } from 'lucide-react';
import { Link, Outlet } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

export function ForumLayout() {
  const { user, loading: isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <MessageSquare className="h-8 w-8 text-indigo-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Redshift Community</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="space-y-1">
              <Link
                to="/forum"
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-900 rounded-md hover:bg-gray-50"
              >
                <MessageSquare className="h-5 w-5 mr-2 text-gray-400" />
                All Discussions
              </Link>
              
              <Link
                to="/forum/categories"
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-900 rounded-md hover:bg-gray-50"
              >
                <Settings className="h-5 w-5 mr-2 text-gray-400" />
                Categories
              </Link>
              
              <Link
                to="/forum/members"
                className="flex items-center px-3 py-2 text-sm font-medium text-gray-900 rounded-md hover:bg-gray-50"
              >
                <Users className="h-5 w-5 mr-2 text-gray-400" />
                Members
              </Link>
              
              {user && (
                <>
                  <Link
                    to="/forum/bookmarks"
                    className="flex items-center px-3 py-2 text-sm font-medium text-gray-900 rounded-md hover:bg-gray-50"
                  >
                    <Bookmark className="h-5 w-5 mr-2 text-gray-400" />
                    My Bookmarks
                  </Link>
                  
                  <Link
                    to="/forum/new"
                    className="flex items-center px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700"
                  >
                    <PlusCircle className="h-5 w-5 mr-2" />
                    New Discussion
                  </Link>
                </>
              )}
            </nav>
            
            <div className="mt-8">
              <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                Popular Categories
              </h3>
              <div className="mt-2 space-y-1">
                <Link
                  to="/forum/category/general"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50"
                >
                  General Discussion
                </Link>
                <Link
                  to="/forum/category/performance"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50"
                >
                  Performance Tuning
                </Link>
                <Link
                  to="/forum/category/scripts"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50"
                >
                  Script Sharing
                </Link>
                <Link
                  to="/forum/category/help"
                  className="flex items-center px-3 py-2 text-sm font-medium text-gray-600 rounded-md hover:bg-gray-50"
                >
                  Help & Support
                </Link>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}