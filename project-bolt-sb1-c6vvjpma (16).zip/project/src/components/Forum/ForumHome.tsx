import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, ThumbsUp, Eye, Clock, Tag } from 'lucide-react';
import { supabase } from '../../services/supabase';
import { useAuth } from '../../hooks/useAuth';
import { formatDistanceToNow } from 'date-fns';

interface ForumThread {
  id: string;
  title: string;
  content: string;
  author: {
    id: string;
    name: string;
    avatar_url: string;
  };
  category: string;
  tags: string[];
  created_at: string;
  last_reply_at: string;
  reply_count: number;
  view_count: number;
  like_count: number;
}

export function ForumHome() {
  const [threads, setThreads] = useState<ForumThread[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    loadThreads();
  }, []);

  const loadThreads = async () => {
    try {
      const { data, error } = await supabase
        .from('forum_threads')
        .select(`
          *,
          author:user_id (
            id,
            name,
            avatar_url
          )
        `)
        .order('last_reply_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      
      setThreads(data as ForumThread[]);
    } catch (err) {
      console.error('Error loading threads:', err);
      setError('Failed to load discussions');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <p className="text-red-700">{error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Recent Discussions</h2>
        
        {user && (
          <Link
            to="/forum/new"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <MessageSquare className="h-4 w-4 mr-2" />
            New Discussion
          </Link>
        )}
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {threads.map((thread) => (
            <li key={thread.id}>
              <Link to={`/forum/thread/${thread.id}`} className="block hover:bg-gray-50">
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-lg font-medium text-indigo-600 truncate">
                        {thread.title}
                      </p>
                      <div className="mt-2 flex items-center text-sm text-gray-500">
                        <div className="flex items-center">
                          <img
                            src={thread.author.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(thread.author.name)}`}
                            alt={thread.author.name}
                            className="h-6 w-6 rounded-full mr-2"
                          />
                          <span>{thread.author.name}</span>
                        </div>
                        <span className="mx-2">•</span>
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{formatDistanceToNow(new Date(thread.created_at), { addSuffix: true })}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center text-sm text-gray-500">
                        <MessageSquare className="h-4 w-4 mr-1" />
                        {thread.reply_count}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Eye className="h-4 w-4 mr-1" />
                        {thread.view_count}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        {thread.like_count}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-2 flex items-center">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                      {thread.category}
                    </span>
                    {thread.tags && thread.tags.length > 0 && (
                      <div className="ml-2 flex items-center space-x-1">
                        <Tag className="h-3 w-3 text-gray-400" />
                        {thread.tags.map((tag, index) => (
                          <span
                            key={index}
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}