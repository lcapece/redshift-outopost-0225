import React, { useState, useEffect } from 'react';
import { X, Globe, Calendar, MessageSquare, AlertCircle } from 'lucide-react';
import { ScrapeUrlWithStats } from '../types/scraping';

interface EditUrlModalProps {
  isOpen: boolean;
  onClose: () => void;
  url: ScrapeUrlWithStats | null;
  onSubmit: (url: string, updates: { nextScheduledScrape: Date | null; comments: string; active: boolean }) => Promise<void>;
}

export function EditUrlModal({ isOpen, onClose, url, onSubmit }: EditUrlModalProps) {
  const [nextScrape, setNextScrape] = useState('');
  const [comments, setComments] = useState('');
  const [active, setActive] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (url) {
      setNextScrape(url.nextScheduledScrape ? new Date(url.nextScheduledScrape).toISOString().slice(0, 16) : '');
      setComments(url.comments || '');
      setActive(url.active);
    }
  }, [url]);

  if (!isOpen || !url) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    
    try {
      await onSubmit(url.url, {
        nextScheduledScrape: nextScrape ? new Date(nextScrape) : null,
        comments,
        active
      });
      
      onClose();
    } catch (err) {
      setError('Failed to update URL. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4">
        <div className="flex justify-between items-center px-6 py-4 border-b">
          <h2 className="text-lg font-medium text-gray-900">Edit URL</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
              <div className="flex">
                <AlertCircle className="h-5 w-5 mr-2" />
                {error}
              </div>
            </div>
          )}
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                URL
              </label>
              <div className="mt-1 flex items-center">
                <Globe className="h-5 w-5 text-gray-400 mr-2" />
                <span className="text-gray-900">{url.url}</span>
              </div>
            </div>
            
            <div>
              <label htmlFor="nextScrape" className="block text-sm font-medium text-gray-700">
                Next Scheduled Scrape
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="datetime-local"
                  id="nextScrape"
                  value={nextScrape}
                  onChange={(e) => setNextScrape(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="comments" className="block text-sm font-medium text-gray-700">
                Comments
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MessageSquare className="h-5 w-5 text-gray-400" />
                </div>
                <textarea
                  id="comments"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  rows={3}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Add any notes or comments..."
                />
              </div>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="active"
                checked={active}
                onChange={(e) => setActive(e.target.checked)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <label htmlFor="active" className="ml-2 block text-sm text-gray-900">
                Active
              </label>
            </div>
          </div>
          
          <div className="mt-6 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {isSubmitting ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}