import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, Download, Star, MessageSquare, Calendar, User, Tag, ExternalLink } from 'lucide-react';
import { RedshiftScript } from '../services/scriptsService';

interface ScriptsListProps {
  scripts: RedshiftScript[];
  isLoading: boolean;
  error: string | null;
}

export function ScriptsList({ scripts, isLoading, error }: ScriptsListProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
        <strong className="font-bold">Error: </strong>
        <span className="block sm:inline">{error}</span>
      </div>
    );
  }

  if (scripts.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">No scripts found. Try adjusting your filters or search criteria.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {scripts.map((script) => (
        <div 
          key={script.id} 
          className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg"
        >
          <div className="p-6">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs font-medium rounded">
                    {script.category}
                  </span>
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs font-medium rounded">
                    {script.script_type}
                  </span>
                </div>
                
                <Link to={`/scripts/${script.id}`} className="block">
                  <h2 className="text-xl font-bold text-gray-900 mb-2 hover:text-indigo-600">{script.title}</h2>
                </Link>
                
                <p className="text-gray-600 mb-4">{script.description}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {script.tags && script.tags.map((tag) => (
                    <span key={tag} className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
                      <Tag className="h-3 w-3 mr-1" />
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="flex flex-col items-end space-y-2 ml-4">
                <div className="flex items-center text-amber-500">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < Math.round(script.average_rating || 0) ? 'fill-amber-500' : ''}`} 
                    />
                  ))}
                  <span className="ml-1 text-xs text-gray-500">({script.rating_count || 0})</span>
                </div>
                
                <div className="flex items-center text-gray-500 text-sm">
                  <Download className="h-4 w-4 mr-1" />
                  {script.downloads}
                </div>
                
                <div className="flex items-center text-gray-500 text-sm">
                  <MessageSquare className="h-4 w-4 mr-1" />
                  {script.comment_count || 0}
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-100 text-sm text-gray-500">
              <div className="flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {new Date(script.published_at).toLocaleDateString()}
              </div>
              
              {script.author && (
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  {script.author}
                </div>
              )}
              
              {script.original_url && (
                <a 
                  href={script.original_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-indigo-600 hover:text-indigo-800"
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  Source
                </a>
              )}
            </div>
            
            <div className="flex justify-between mt-4">
              <button
                onClick={() => toggleExpand(script.id)}
                className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
              >
                {expandedId === script.id ? 'Show Less' : 'Preview Script'}
              </button>
              
              <Link
                to={`/scripts/${script.id}`}
                className="inline-flex items-center px-3 py-1.5 border border-indigo-600 text-sm font-medium rounded-md text-indigo-600 hover:bg-indigo-50"
              >
                <FileText className="h-4 w-4 mr-1.5" />
                View Details
              </Link>
            </div>
            
            {expandedId === script.id && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="bg-gray-50 p-4 rounded-lg overflow-x-auto max-h-60">
                  <pre className="text-xs font-mono">
                    {script.script_content.slice(0, 500)}
                    {script.script_content.length > 500 && '...'}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}