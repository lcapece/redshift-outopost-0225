import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  FileText, Download, Star, MessageSquare, Calendar, User, Tag, 
  ExternalLink, ArrowLeft, Copy, CheckCircle, ThumbsUp 
} from 'lucide-react';
import { 
  RedshiftScript, 
  ScriptComment, 
  incrementDownload, 
  fetchComments, 
  addComment, 
  rateScript, 
  getUserRating 
} from '../services/scriptsService';
import { useAuth } from '../hooks/useAuth';

interface ScriptDetailProps {
  script: RedshiftScript;
  onBack: () => void;
  isAdmin?: boolean;
}

export function ScriptDetail({ script, onBack, isAdmin = false }: ScriptDetailProps) {
  const { user } = useAuth();
  const [comments, setComments] = useState<ScriptComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [userRating, setUserRating] = useState<number | null>(null);
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  const [showCopySuccess, setShowCopySuccess] = useState(false);
  const [showDownloadSuccess, setShowDownloadSuccess] = useState(false);

  useEffect(() => {
    // Load comments
    const loadComments = async () => {
      const fetchedComments = await fetchComments(script.id);
      setComments(fetchedComments);
    };
    
    loadComments();
    
    // Load user rating if logged in
    if (user) {
      const loadUserRating = async () => {
        const rating = await getUserRating(script.id, user.id);
        setUserRating(rating);
      };
      
      loadUserRating();
    }
  }, [script.id, user]);

  const handleDownload = async () => {
    // Create a blob from the script content
    const blob = new Blob([script.script_content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    // Create a temporary link and click it
    const a = document.createElement('a');
    a.href = url;
    a.download = `${script.title.replace(/\s+/g, '_')}.sql`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Increment download count
    await incrementDownload(script.id);
    
    // Show success message
    setShowDownloadSuccess(true);
    setTimeout(() => setShowDownloadSuccess(false), 3000);
  };

  const handleCopyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(script.script_content);
      setShowCopySuccess(true);
      setTimeout(() => setShowCopySuccess(false), 3000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const handleSubmitComment = async () => {
    if (!user || !newComment.trim()) return;
    
    setIsSubmittingComment(true);
    
    try {
      const comment = await addComment(script.id, user.id, newComment);
      if (comment) {
        setComments([comment, ...comments]);
        setNewComment('');
      }
    } catch (error) {
      console.error('Error submitting comment:', error);
    } finally {
      setIsSubmittingComment(false);
    }
  };

  const handleRateScript = async (rating: number) => {
    if (!user) return;
    
    setIsSubmittingRating(true);
    
    try {
      const success = await rateScript(script.id, user.id, rating);
      if (success) {
        setUserRating(rating);
      }
    } catch (error) {
      console.error('Error rating script:', error);
    } finally {
      setIsSubmittingRating(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={onBack}
            className="inline-flex items-center text-indigo-600 hover:text-indigo-800"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to scripts
          </button>

          {isAdmin && (
            <div className="flex space-x-2">
              <Link
                to={`/admin/scripts/edit/${script.id}`}
                className="inline-flex items-center px-3 py-1.5 border border-indigo-600 text-sm font-medium rounded-md text-indigo-600 hover:bg-indigo-50"
              >
                Edit
              </Link>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2 mb-4">
          <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs font-medium rounded">
            {script.category}
          </span>
          <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs font-medium rounded">
            {script.script_type}
          </span>
          <div className="flex-1"></div>
          <div className="flex items-center text-gray-500 text-sm">
            <Calendar className="h-4 w-4 mr-1" />
            {new Date(script.published_at).toLocaleDateString()}
          </div>
        </div>
        
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{script.title}</h1>
        
        {script.tags && script.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {script.tags.map(tag => (
              <span key={tag} className="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
                <Tag className="h-3 w-3 mr-1" />
                {tag}
              </span>
            ))}
          </div>
        )}
        
        <div className="prose prose-lg max-w-none mb-8">
          <p className="text-gray-700">{script.description}</p>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-4 mb-8">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Script Content</h3>
            <div className="flex space-x-2">
              <button
                onClick={handleCopyToClipboard}
                className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                {showCopySuccess ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-1.5 text-green-500" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1.5" />
                    Copy
                  </>
                )}
              </button>
              <button
                onClick={handleDownload}
                className="inline-flex items-center px-3 py-1.5 border border-indigo-600 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                {showDownloadSuccess ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-1.5" />
                    Downloaded!
                  </>
                ) : (
                  <>
                    <Download className="h-4 w-4 mr-1.5" />
                    Download
                  </>
                )}
              </button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            {script.formatted_content ? (
              <div dangerouslySetInnerHTML={{ __html: script.formatted_content }} />
            ) : (
              <pre className="text-sm font-mono p-4 bg-gray-800 text-gray-100 rounded-md overflow-x-auto">
                {script.script_content}
              </pre>
            )}
          </div>
        </div>
        
        <div className="flex justify-between items-center border-t border-gray-200 pt-6 mb-8">
          <div className="flex items-center space-x-8">
            <div className="flex items-center">
              <Download className="h-5 w-5 mr-2 text-gray-500" />
              <span className="text-gray-700">{script.downloads} downloads</span>
            </div>
            
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-gray-500" />
              <span className="text-gray-700">{comments.length} comments</span>
            </div>
          </div>
          
          {script.original_url && (
            <a 
              href={script.original_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium"
            >
              <ExternalLink className="h-5 w-5 mr-2" />
              View Original Source
            </a>
          )}
        </div>
        
        {/* Rating Section */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Rate this Script</h3>
          
          <div className="flex items-center space-x-2">
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => handleRateScript(rating)}
                disabled={isSubmittingRating || !user}
                className="focus:outline-none"
              >
                <Star 
                  className={`h-8 w-8 ${
                    rating <= (userRating || 0) 
                      ? 'text-amber-500 fill-amber-500' 
                      : 'text-gray-300'
                  } hover:text-amber-500 transition-colors`} 
                />
              </button>
            ))}
            
            <span className="ml-2 text-sm text-gray-500">
              {user 
                ? userRating 
                  ? `Your rating: ${userRating}/5` 
                  : 'Click to rate' 
                : 'Sign in to rate'}
            </span>
          </div>
          
          <div className="mt-2 flex items-center">
            <div className="flex items-center">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star 
                  key={i} 
                  className={`h-5 w-5 ${
                    i < Math.round(script.average_rating || 0) 
                      ? 'text-amber-500 fill-amber-500' 
                      : 'text-gray-300'
                  }`} 
                />
              ))}
            </div>
            <span className="ml-2 text-sm text-gray-700">
              {script.average_rating ? script.average_rating.toFixed(1) : '0'}/5 ({script.rating_count || 0} ratings)
            </span>
          </div>
        </div>
        
        {/* Comments Section */}
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Comments</h3>
          
          {user ? (
            <div className="mb-6">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                rows={3}
              />
              <div className="mt-2 flex justify-end">
                <button
                  onClick={handleSubmitComment}
                  disabled={isSubmittingComment || !newComment.trim()}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
                >
                  {isSubmittingComment ? 'Submitting...' : 'Submit Comment'}
                </button>
              </div>
            </div>
          ) : (
            <div className="mb-6 p-4 bg-gray-50 rounded-md text-center">
              <p className="text-gray-700">Please sign in to leave a comment.</p>
            </div>
          )}
          
          {comments.length > 0 ? (
            <div className="space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="p-4 bg-gray-50 rounded-md">
                  <div className="flex justify-between items-center mb-2">
                    <div className="font-medium text-gray-900">{comment.user_email || 'Anonymous'}</div>
                    <div className="text-sm text-gray-500">
                      {new Date(comment.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <p className="text-gray-700">{comment.comment}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No comments yet. Be the first to comment!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}