import React, { useState } from 'react';
import { Copy, CheckCircle, Eye, X } from 'lucide-react';

interface TableInfo {
  name: string;
  schema: string;
  isView: boolean;
}

interface Props {
  tables: TableInfo[];
  onToggleView: (tableName: string, schema: string) => void;
}

export function TableList({ tables, onToggleView }: Props) {
  const [showCopySuccess, setShowCopySuccess] = React.useState(false);
  const [showQueryModal, setShowQueryModal] = useState(false);

  const getSvvQuery = () => {
    const viewRefs = tables
      .filter(t => t.isView)
      .map(t => `'${t.schema}.${t.name}'`)
      .join(',');
    
    return `SELECT 
  "database" as dbname,
  "schema" as schemaname,
  "table" as tablename,
  encoded,
  "diststyle",
  sortkey1,
  sortkey1_enc,
  sortkey_num,
  "size" as size_gb,
  "empty" as pct_empty,
  unsorted as unsorted_pct,
  stats_off,
  tbl_rows,
  skew_sortkey1,
  skew_rows,
  estimated_visible_rows,
  risk_event 
FROM 
  svv_table_info l 
WHERE 
  "schema" || '.' || "table" in (${viewRefs || "''"})`;
  };

  const handleCopyQuery = async () => {
    try {
      await navigator.clipboard.writeText(getSvvQuery());
      setShowCopySuccess(true);
      setTimeout(() => setShowCopySuccess(false), 3000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  if (tables.length === 0) {
    return (
      <p className="text-sm text-gray-500">
        No tables or views detected in the query.
      </p>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-sm font-medium text-gray-700">Selected Tables</h3>
        <div className="flex space-x-2">
          <button
            onClick={() => setShowQueryModal(true)}
            className="inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            title="Show SVV_TABLE_INFO query"
          >
            <Eye className="h-4 w-4 mr-1.5" />
            Show SVV Query
          </button>
          <button
            onClick={handleCopyQuery}
            className="inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            title="Copy SVV_TABLE_INFO query to clipboard"
          >
            {showCopySuccess ? (
              <>
                <CheckCircle className="h-4 w-4 mr-1.5" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-1.5" />
                Copy Query
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-2">
        {tables.map((table) => (
          <div
            key={`${table.schema}.${table.name}`}
            className="flex items-center space-x-1.5 px-2 py-1 bg-gray-50 rounded border border-gray-100"
          >
            <input
              type="checkbox"
              id={`view-${table.schema}.${table.name}`}
              checked={table.isView}
              onChange={() => onToggleView(table.name, table.schema)}
              className="h-3.5 w-3.5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label
              htmlFor={`view-${table.schema}.${table.name}`}
              className="flex-1 text-xs font-medium text-gray-700 cursor-pointer truncate"
            >
              <span className="text-gray-500">{table.schema}.</span>{table.name}
              {table.isView && (
                <span className="ml-1 inline-flex items-center px-1 rounded text-[10px] font-medium bg-indigo-50 text-indigo-700">
                  View
                </span>
              )}
            </label>
          </div>
        ))}
      </div>

      {/* Query Modal */}
      {showQueryModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4">
            <div className="flex justify-between items-center px-6 py-4 border-b">
              <h2 className="text-lg font-semibold text-gray-900">SVV_TABLE_INFO Query</h2>
              <button
                onClick={() => setShowQueryModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex justify-between items-center px-4 py-2 bg-gray-100 border-b">
                  <span className="text-sm font-medium text-gray-700">Query</span>
                  <button
                    onClick={handleCopyQuery}
                    className="inline-flex items-center px-2 py-1 text-sm font-medium rounded text-gray-700 hover:bg-gray-200"
                  >
                    {showCopySuccess ? (
                      <>
                        <CheckCircle className="h-4 w-4 mr-1.5 text-green-500" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-1.5" />
                        Copy
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-4 overflow-x-auto text-sm font-mono text-gray-800 whitespace-pre-wrap">
                  {getSvvQuery()}
                </pre>
              </div>
              <div className="mt-4 bg-blue-50 rounded-lg p-4">
                <p className="text-sm text-blue-700">
                  This query retrieves detailed information about the selected views from the SVV_TABLE_INFO system view in Amazon Redshift. It includes metrics like size, distribution style, sort keys, and data skew.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}