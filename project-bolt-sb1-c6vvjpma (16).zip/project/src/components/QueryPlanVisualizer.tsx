import React, { useState, useEffect } from 'react';
import { Play, AlertCircle, Info } from 'lucide-react';
import { LlmModelSelector } from './LlmModelSelector';
import { QueryPlanWalkthru } from './QueryPlanWalkthru';
import { QueryPlanToMermaid } from './QueryPlanToMermaid';
import { supabase } from '../services/supabase';

export function QueryPlanVisualizer() {
  const [queryPlan, setQueryPlan] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState('anthropic/claude-3-sonnet');
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  const handleAnalyze = async () => {
    if (!queryPlan.trim()) {
      setError('Please enter a query plan');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      // Store the simulation
      const { error: dbError } = await supabase
        .from('redshift_simulations')
        .insert({
          llm_model: selectedModel,
          sql_query: '',  // We don't have the original query
          query_plan: queryPlan,
          complexity: 1
        });

      if (dbError) throw dbError;

    } catch (error) {
      console.error('Error storing simulation:', error);
      setError('Failed to store simulation');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-2xl font-bold text-gray-900">Query Plan Visualizer</h1>
          <LlmModelSelector
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
            disabled={isAnalyzing}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="mb-4">
                <label 
                  htmlFor="queryPlan" 
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Paste Query Execution Plan
                </label>
                <textarea
                  id="queryPlan"
                  value={queryPlan}
                  onChange={(e) => setQueryPlan(e.target.value)}
                  className="w-full h-64 p-4 text-sm font-mono bg-gray-50 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Paste your query execution plan here..."
                  spellCheck="false"
                />
              </div>

              <div className="flex items-center space-x-4">
                <button
                  onClick={handleAnalyze}
                  disabled={!queryPlan.trim() || isAnalyzing}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  <Play className={`h-4 w-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                </button>

                {error && (
                  <div className="flex-1 flex items-center p-3 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}
              </div>
            </div>

            {queryPlan && <QueryPlanToMermaid queryPlan={queryPlan} />}
          </div>

          <div className="space-y-6">
            {queryPlan && <QueryPlanWalkthru queryPlan={queryPlan} />}
          </div>
        </div>
      </div>
    </div>
  );
}