import React, { useState } from 'react';
import { Send, Copy, CheckCircle, AlertCircle } from 'lucide-react';
import { generateMermaidWithGemini } from '../services/gemini';
import { generateMermaidWithClaude } from '../services/anthropic';
import { MermaidDiagram } from './MermaidDiagram';

const DEFAULT_MODEL = 'meta-llama/llama-3.1-405b';

interface QueryPlanToMermaidProps {
  queryPlan: string;
}

export function QueryPlanToMermaid({ queryPlan }: QueryPlanToMermaidProps) {
  const [mermaidScript, setMermaidScript] = useState<string | null>(null);
  const [svgContent, setSvgContent] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showCopySuccess, setShowCopySuccess] = useState(false);
  const [showPreview, setShowPreview] = useState(true);
  const [renderEngine, setRenderEngine] = useState<'gemini' | 'claude'>('claude');

  const generateMermaidScript = async () => {
    if (!queryPlan.trim()) {
      setError('Please enter a query plan first');
      return;
    }

    setIsLoading(true);
    setError(null);
    setMermaidScript(null);
    setSvgContent(null);

    try {
      if (renderEngine === 'claude') {
        // Use Claude 3.7 to generate both Mermaid script and SVG
        const { mermaidScript: script, svg } = await generateMermaidWithClaude(queryPlan);
        setMermaidScript(script);
        setSvgContent(svg);
      } else {
        // Use Gemini to generate just the Mermaid script
        const script = await generateMermaidWithGemini(queryPlan);
        
        // Sanitize and fix the Mermaid script to ensure it's valid
        let sanitizedScript = script
          // Ensure we're using flowchart TD
          .replace(/^graph\s+TD/m, 'flowchart TD')
          .replace(/^graph\s+BT/m, 'flowchart TD')
          // Remove any subgraph that might cause issues
          .replace(/subgraph\s+[^\n]+\n[\s\S]*?\nend\n/gm, '')
          // Fix node IDs with special characters
          .replace(/([A-Za-z0-9_]+)-([A-Za-z0-9_]+)/g, '$1_$2')
          // Fix arrow syntax
          .replace(/-->/g, ' --> ')
          // Fix node labels with problematic characters
          .replace(/\[(.*?):(.*?)\]/g, '["$1 - $2"]')
          .replace(/\{(.*?):(.*?)\}/g, '{"$1 - $2"}')
          .replace(/\{\{(.*?):(.*?)\}\}/g, '{{"$1 - $2"}}')
          // Fix Sort Key syntax issues
          .replace(/Sort Key: ([^\n<]+)/g, 'Sort Key $1')
          // Fix Hash Cond syntax issues
          .replace(/Hash Cond: ([^\n<]+)/g, 'Hash Cond $1')
          // Fix Filter syntax issues
          .replace(/Filter: ([^\n<]+)/g, 'Filter $1')
          // Replace any remaining colons in node text with spaces or dashes
          .replace(/([\w\s]+):([\w\s]+)/g, '$1 - $2')
          // Ensure proper line breaks in node labels
          .replace(/\n\s+/g, '<br>');
        
        // Ensure the script starts with flowchart TD
        if (!sanitizedScript.trim().startsWith('flowchart TD')) {
          sanitizedScript = 'flowchart TD\n' + sanitizedScript;
        }
        
        setMermaidScript(sanitizedScript);
        setSvgContent(null);
      }
    } catch (error) {
      console.error('Error generating Mermaid script:', error);
      let errorMessage = 'Failed to generate Mermaid script';
      
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      setError(errorMessage);
      
      // Generate a basic Mermaid script from the query plan as fallback
      try {
        const lines = queryPlan.split('\n').filter(line => line.trim());
        if (lines.length === 0) throw new Error('Empty query plan');

        // Find all costs to determine relative levels
        const allCosts: number[] = [];
        lines.forEach(line => {
          const costMatch = line.trim().match(/cost=([^.]+)\.\.([^)]+)/);
          if (costMatch) {
            const endCost = parseFloat(costMatch[2]);
            if (!isNaN(endCost)) {
              allCosts.push(endCost);
            }
          }
        });
        
        // Sort costs to determine quartiles
        allCosts.sort((a, b) => a - b);
        const costThresholds = {
          low: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.25)] : 0,
          medium: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.5)] : 0,
          high: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.75)] : 0
        };

        let mermaidScript = 'flowchart TD\n';
        const nodeMap = new Map();
        const connections = [];
        let nodeCounter = 0;

        // Process each line of the query plan
        lines.forEach((line, index) => {
          const trimmedLine = line.trim();
          const indentation = line.search(/\S|$/);
          const depth = Math.floor(indentation / 2);
          
          // Skip empty lines
          if (!trimmedLine) return;
          
          // Extract operation type and details
          const match = trimmedLine.match(/([A-Za-z\s]+)(?:\s+on\s+(\w+))?(?:\s+\((.+)\))?/);
          if (!match) return;
          
          const [, operation, table, details] = match;
          const operationType = operation.trim();
          
          // Determine node shape and color based on operation type
          let nodeShape = '["$1"]';
          let nodeClass = 'Scan';
          
          if (operationType.includes('Hash Join')) {
            nodeShape = '[/"$1"/]';
            nodeClass = 'HashJoin';
          } else if (operationType.includes('Hash')) {
            nodeShape = '{{"$1"}}';
            nodeClass = 'Hash';
          } else if (operationType.includes('Aggregate')) {
            nodeShape = '(("$1"))';
            nodeClass = 'Aggregate';
          } else if (operationType.includes('Sort')) {
            nodeShape = '{{"$1"}}';
            nodeClass = 'Sort';
          } else if (operationType.includes('Scan')) {
            nodeShape = '[("$1")]';
            nodeClass = 'Scan';
          }
          
          // Create node label
          let label = operationType;
          if (table) label += ` on ${table}`;
          if (details) {
            const costMatch = details.match(/cost=([^.]+)\.\.([^)]+)/);
            const rowsMatch = details.match(/rows=(\d+)/);
            
            // Determine cost level
            let costLevel = 'MEDIUM';
            if (costMatch) {
              const endCost = parseFloat(costMatch[2]);
              if (!isNaN(endCost)) {
                if (endCost <= costThresholds.low) {
                  costLevel = 'LOW';
                } else if (endCost <= costThresholds.medium) {
                  costLevel = 'MEDIUM';
                } else if (endCost <= costThresholds.high) {
                  costLevel = 'HIGH';
                } else {
                  costLevel = 'HIGHEST';
                }
              }
            }
            
            if (costMatch) label += `<br>Cost ${costMatch[1]}..${costMatch[2]} (${costLevel})`;
            
            if (rowsMatch) {
              const rows = parseInt(rowsMatch[1]);
              let formattedRows: string;
              if (rows >= 1000000000) {
                formattedRows = (rows / 1000000000).toFixed(1) + 'B';
              } else if (rows >= 1000000) {
                formattedRows = (rows / 1000000).toFixed(1) + 'M';
              } else if (rows >= 1000) {
                formattedRows = (rows / 1000).toFixed(1) + 'K';
              } else {
                formattedRows = rows.toString();
              }
              label += `<br>Rows ${formattedRows}`;
            }
          }
          
          // Generate unique node ID using letters to avoid numeric IDs
          const nodeId = `node${nodeCounter++}`;
          nodeMap.set(depth, nodeId);
          
          // Add node to diagram
          mermaidScript += `  ${nodeId}${nodeShape.replace('$1', label)} `;
          mermaidScript += `:::${nodeClass} `;
          mermaidScript += `\n`;
          
          // Add connection to parent node
          if (depth > 0 && nodeMap.has(depth - 1)) {
            const parentNodeId = nodeMap.get(depth - 1);
            connections.push(`  ${nodeId} --> ${parentNodeId}\n`);
          }
        });
        
        // Add connections
        connections.forEach(connection => {
          mermaidScript += connection;
        });
        
        // Add class definitions for styling
        mermaidScript += `\n  classDef HashJoin fill:#ffe0d0,stroke:#c05030\n`;
        mermaidScript += `  classDef Hash fill:#d0ffe0,stroke:#30a050\n`;
        mermaidScript += `  classDef Aggregate fill:#e0d0ff,stroke:#5030c0\n`;
        mermaidScript += `  classDef Sort fill:#fff0d0,stroke:#c0a030\n`;
        mermaidScript += `  classDef Scan fill:#d0e0ff,stroke:#3050c0\n`;
        
        setMermaidScript(mermaidScript);
        setError('Using locally generated Mermaid script (fallback mode)');
      } catch (fallbackError) {
        console.error('Error generating fallback Mermaid script:', fallbackError);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async () => {
    if (!mermaidScript) return;
    
    try {
      await navigator.clipboard.writeText(mermaidScript);
      setShowCopySuccess(true);
      setTimeout(() => setShowCopySuccess(false), 3000);
    } catch (err) {
      setError('Failed to copy to clipboard');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 mb-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Query Plan Visualization</h2>
        <div className="flex items-center space-x-2">
          <label className="text-sm text-gray-600">Render Engine:</label>
          <select
            value={renderEngine}
            onChange={(e) => setRenderEngine(e.target.value as 'gemini' | 'claude')}
            className="text-sm border border-gray-300 rounded px-2 py-1"
            disabled={isLoading}
          >
            <option value="claude">Claude 3.7</option>
            <option value="gemini">Gemini</option>
          </select>
        </div>
      </div>
      
      <div className="mb-4">
        <button
          onClick={generateMermaidScript}
          disabled={isLoading || !queryPlan.trim()}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          <Send className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          {isLoading ? 'Generating...' : 'Generate Visualization'}
        </button>
      </div>
      
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <div className="flex items-center">
            <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        </div>
      )}
      
      {mermaidScript && (
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-md font-medium text-gray-800">Generated Visualization</h3>
            <div className="flex space-x-2">
              <button
                onClick={() => setShowPreview(!showPreview)}
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                {showPreview ? 'Hide Preview' : 'Show Preview'}
              </button>
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center px-3 py-1.5 text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
              >
                {showCopySuccess ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-1.5" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1.5" />
                    Copy
                  </>
                )}
              </button>
            </div>
          </div>
          
          {showPreview && (
            <MermaidDiagram chart={mermaidScript} svg={svgContent || undefined} className="mb-4" />
          )}
          
          <div>
            <h3 className="text-sm font-medium text-gray-700 mb-2">Mermaid Script</h3>
            <pre className="text-xs bg-gray-50 p-4 rounded-lg overflow-x-auto whitespace-pre font-mono max-h-[300px] overflow-y-auto border border-gray-200">
              {mermaidScript}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}