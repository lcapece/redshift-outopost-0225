import React from 'react';
import { Brain } from 'lucide-react';

interface AIModel {
  id: string;
  name: string;
}

interface Props {
  models: AIModel[];
  selectedModel: string;
  onModelChange: (modelId: string) => void;
  disabled?: boolean;
}

export function ModelSelector({ models, selectedModel, onModelChange, disabled }: Props) {
  return (
    <div className="flex items-center space-x-2">
      <Brain className="h-5 w-5 text-purple-600" />
      <select
        value={selectedModel}
        onChange={(e) => onModelChange(e.target.value)}
        className="block w-56 rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 text-sm"
        disabled={disabled}
      >
        {models.map((model) => (
          <option key={model.id} value={model.id}>
            {model.name}
          </option>
        ))}
      </select>
    </div>
  );
}