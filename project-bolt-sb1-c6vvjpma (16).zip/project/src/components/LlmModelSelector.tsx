import React from 'react';
import { Brain, Info } from 'lucide-react';

export interface LlmModel {
  id: string;
  name: string;
  description: string;
  capabilities: string[];
  costPerToken: number;
}

interface LlmModelSelectorProps {
  selectedModel: string;
  onModelChange: (modelId: string) => void;
  disabled?: boolean;
  showInfo?: boolean;
}

const LLM_MODELS: LlmModel[] = [
  {
    id: 'anthropic/claude-3-sonnet',
    name: 'Claude 3 Sonnet',
    description: 'Latest Claude model with enhanced code understanding',
    capabilities: [
      'Advanced code analysis',
      'Detailed technical documentation',
      'Nuanced SQL understanding',
      'Context-aware summaries'
    ],
    costPerToken: 0.0003
  },
  {
    id: 'anthropic/claude-2',
    name: 'Claude 2',
    description: 'Reliable model for code analysis and documentation',
    capabilities: [
      'Code extraction',
      'Technical documentation',
      'SQL analysis',
      'Performance insights'
    ],
    costPerToken: 0.0002
  },
  {
    id: 'openai/gpt-4-turbo',
    name: 'GPT-4 Turbo',
    description: 'Latest GPT-4 model with enhanced capabilities',
    capabilities: [
      'Advanced pattern recognition',
      'Complex code analysis',
      'Detailed explanations',
      'Best practices insights'
    ],
    costPerToken: 0.00025
  },
  {
    id: 'meta-llama/llama-3.1-405b',
    name: 'Llama 3.1 405B',
    description: 'Large open-source model with strong code understanding',
    capabilities: [
      'Code extraction',
      'Documentation generation',
      'SQL analysis',
      'Performance recommendations'
    ],
    costPerToken: 0.0001
  },
  {
    id: 'google/palm-2-chat-bison',
    name: 'PaLM 2 Chat',
    description: 'Google\'s advanced language model',
    capabilities: [
      'Code understanding',
      'Technical analysis',
      'Documentation generation',
      'Context awareness'
    ],
    costPerToken: 0.00015
  }
];

export function LlmModelSelector({ selectedModel, onModelChange, disabled = false, showInfo = true }: LlmModelSelectorProps) {
  const selectedModelInfo = LLM_MODELS.find(model => model.id === selectedModel);

  return (
    <div className="flex flex-col space-y-2">
      <div className="flex items-center space-x-2">
        <Brain className="h-5 w-5 text-purple-600" />
        <select
          value={selectedModel}
          onChange={(e) => onModelChange(e.target.value)}
          disabled={disabled}
          className="block w-64 rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 text-sm"
        >
          {LLM_MODELS.map((model) => (
            <option key={model.id} value={model.id}>
              {model.name}
            </option>
          ))}
        </select>
      </div>

      {showInfo && selectedModelInfo && (
        <div className="bg-purple-50 rounded-md p-3 text-sm">
          <div className="flex items-start">
            <Info className="h-4 w-4 text-purple-600 mt-0.5 mr-2 flex-shrink-0" />
            <div>
              <p className="text-purple-900 font-medium mb-1">{selectedModelInfo.description}</p>
              <ul className="text-purple-700 space-y-1 ml-4 list-disc text-xs">
                {selectedModelInfo.capabilities.map((capability, index) => (
                  <li key={index}>{capability}</li>
                ))}
              </ul>
              <p className="text-purple-600 text-xs mt-2">
                Cost: ${selectedModelInfo.costPerToken.toFixed(4)} per token
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}