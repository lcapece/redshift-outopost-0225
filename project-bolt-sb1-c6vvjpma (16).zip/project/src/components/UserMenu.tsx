import React from 'react';
import { User, LogOut, LogIn } from 'lucide-react';
import { supabase } from '../services/supabase';

interface Props {
  user: any | null;
  onSignInClick: () => void;
}

export function UserMenu({ user, onSignInClick }: Props) {
  const handleSignOut = async () => {
    await supabase.auth.signOut();
  };

  const getUserDisplayName = () => {
    if (!user) return '';
    
    // Try to get user's name from metadata or email
    if (user.user_metadata && user.user_metadata.full_name) {
      return user.user_metadata.full_name;
    }
    
    if (user.user_metadata && user.user_metadata.name) {
      return user.user_metadata.name;
    }
    
    // If no name is available, use email
    return user.email ? user.email.split('@')[0] : 'User';
  };

  if (!user) {
    return (
      <button
        onClick={onSignInClick}
        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
      >
        <LogIn className="h-4 w-4 mr-2" />
        Sign In
      </button>
    );
  }

  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2">
        {user.user_metadata?.avatar_url ? (
          <img 
            src={user.user_metadata.avatar_url} 
            alt="User avatar" 
            className="h-8 w-8 rounded-full"
          />
        ) : (
          <User className="h-5 w-5 text-gray-400" />
        )}
        <span className="text-sm text-gray-700">{getUserDisplayName()}</span>
      </div>
      <button
        onClick={handleSignOut}
        className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
      >
        <LogOut className="h-4 w-4 mr-1.5" />
        Sign Out
      </button>
    </div>
  );
}