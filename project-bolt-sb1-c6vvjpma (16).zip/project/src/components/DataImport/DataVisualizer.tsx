import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, Download, Copy, CheckCircle } from 'lucide-react';
import { decryptData } from '../../services/encryptionManager';

interface VisualizerProps {
  data: {
    encrypted: string;
    metadata: {
      version: number;
      timestamp: string;
    };
  };
  decryptionKey?: string;
  showSensitive: boolean;
  onExport: (format: string) => void;
}

export function DataVisualizer({ 
  data, 
  decryptionKey,
  showSensitive,
  onExport 
}: VisualizerProps) {
  const [decryptedData, setDecryptedData] = useState<any[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (decryptionKey && data.encrypted) {
      decryptData(data, decryptionKey)
        .then(decrypted => {
          setDecryptedData(JSON.parse(decrypted));
          setError(null);
        })
        .catch(err => {
          setError('Failed to decrypt data. Please check your password.');
          setDecryptedData(null);
        });
    }
  }, [data, decryptionKey]);

  const handleCopyToClipboard = async () => {
    if (!decryptedData) return;
    
    try {
      await navigator.clipboard.writeText(JSON.stringify(decryptedData, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      setError('Failed to copy data to clipboard');
    }
  };

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <p className="text-red-700">{error}</p>
      </div>
    );
  }

  if (!decryptedData) {
    return (
      <div className="bg-gray-50 border border-gray-200 rounded-md p-4">
        <p className="text-gray-700">Enter decryption password to view data</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-medium text-gray-900">Data Preview</h2>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => onExport('csv')}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              <Download className="h-4 w-4 mr-1.5" />
              Export CSV
            </button>
            <button
              onClick={handleCopyToClipboard}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              {copied ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-1.5 text-green-500" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-1.5" />
                  Copy
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {Object.keys(decryptedData[0]).map((header) => (
                <th
                  key={header}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {decryptedData.map((row, rowIndex) => (
              <tr key={rowIndex}>
                {Object.entries(row).map(([key, value], colIndex) => (
                  <td
                    key={colIndex}
                    className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                  >
                    {showSensitive ? value : maskSensitiveData(key, value)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="p-4 bg-gray-50 border-t border-gray-200">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <div>
            Last updated: {new Date(data.metadata.timestamp).toLocaleString()}
          </div>
          <div>
            Version: {data.metadata.version}
          </div>
        </div>
      </div>
    </div>
  );
}

function maskSensitiveData(key: string, value: any): string {
  const sensitiveFields = ['size', 'pct_used', 'stats_off'];
  if (sensitiveFields.includes(key)) {
    return '****';
  }
  return value;
}