import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { X, Upload, Eye, EyeOff, Database, AlertCircle, RefreshCw, CheckCircle, Lock, Copy } from 'lucide-react';
import { PasswordInput } from './PasswordInput';
import { SqlPreviewModal } from './SqlPreviewModal';
import { validateImportData } from '../../services/importService';
import { importSvvData, deleteExistingRecords } from '../../services/svvImportService';
import { useAuth } from '../../hooks/useAuth';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (data: any) => Promise<void>;
}

export function ImportModal({ isOpen, onClose, onImport }: ImportModalProps) {
  const { user } = useAuth();
  const [pastedData, setPastedData] = useState('');
  const [decryptionPassword, setDecryptionPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isPasswordValid, setIsPasswordValid] = useState(false);
  const [showSqlPreview, setShowSqlPreview] = useState(false);
  const [generatedSql, setGeneratedSql] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStats, setImportStats] = useState<{
    originalCount: number;
    insertedCount: number;
    updatedCount: number;
    finalCount: number;
  } | null>(null);
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [showCopySuccess, setShowCopySuccess] = useState(false);

  const handleDataPaste = async (data: string) => {
    setPastedData(data);
    setError(null);
    setImportProgress(0);
    setImportStats(null);
    setShowSuccessPopup(false);

    if (!user) {
      setError('You must be logged in to import data');
      return;
    }
  };

  const handleImport = async () => {
    if (!user || !pastedData) return;

    if (!decryptionPassword) {
      setError('Please enter the decryption password');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    setImportStats(null);

    try {
      // Delete existing records first
      await deleteExistingRecords(user.id);

      // Import new data with progress tracking
      const result = await importSvvData(pastedData, user.id, decryptionPassword, (progress) => {
        setImportProgress(progress);
      });
      
      if (!result.success) {
        setError(result.error);
        return;
      }

      // Show success stats
      if (result.stats) {
        setImportStats(result.stats);
        setShowSuccessPopup(true);
      }

      // Show completion for a moment before closing
      setImportProgress(100);
      setTimeout(() => {
        onClose();
        setImportProgress(0);
        setPastedData('');
        setDecryptionPassword('');
        setImportStats(null);
        setShowSuccessPopup(false);
      }, 3000);
    } catch (err) {
      setError('Failed to import data');
      console.error('Import error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyQuery = async () => {
    const query = `SELECT 
  "database" as dbname,
  "schema" as schemaname,
  "table" as tablename,
  encoded,
  "diststyle",
  sortkey1,
  sortkey1_enc,
  sortkey_num,
  "size" as size_gb,
  "empty" as pct_empty,
  unsorted as unsorted_pct,
  stats_off,
  tbl_rows,
  skew_sortkey1,
  skew_rows,
  estimated_visible_rows,
  risk_event 
FROM 
  svv_table_info`;

    try {
      await navigator.clipboard.writeText(query);
      setShowCopySuccess(true);
      setTimeout(() => setShowCopySuccess(false), 3000);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4">
        <div className="flex justify-between items-center px-6 py-4 border-b">
          <div className="flex items-center">
            <Database className="h-6 w-6 text-indigo-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Import Table Attributes</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
              <div className="flex">
                <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
                <span className="text-red-700 whitespace-pre-wrap">{error}</span>
              </div>
            </div>
          )}

          {showSuccessPopup && importStats && (
            <div className="mb-6 bg-green-50 border border-green-200 rounded-md p-4">
              <div className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="text-sm font-medium text-green-800">Import Successful</h3>
                  <ul className="mt-2 text-sm text-green-700">
                    <li>Original records: {importStats.originalCount}</li>
                    <li>New records added: {importStats.insertedCount}</li>
                    <li>Records updated: {importStats.updatedCount}</li>
                    <li>Total records: {importStats.finalCount}</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {importProgress > 0 && (
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">
                  {isSubmitting ? 'Importing data...' : 'Import complete'}
                </span>
                <span className="text-sm text-gray-500">{Math.round(importProgress)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${importProgress}%` }}
                />
              </div>
            </div>
          )}

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Paste Redshift Data</h3>
              <p className="text-sm text-gray-600 mb-4">
                Paste your Redshift query results here (pipe-delimited format)
              </p>
              <textarea
                value={pastedData}
                onChange={(e) => handleDataPaste(e.target.value)}
                className="w-full h-64 font-mono text-sm p-4 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Paste your pipe-delimited data here..."
                spellCheck="false"
              />
            </div>

            <div>
              <label htmlFor="decryptionPassword" className="block text-sm font-medium text-gray-700 mb-2">
                Decryption Password <span className="text-red-500">*</span>
              </label>
              <div className="relative w-1/4">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  id="decryptionPassword"
                  value={decryptionPassword}
                  onChange={(e) => setDecryptionPassword(e.target.value)}
                  className="block w-full pl-10 pr-12 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter decryption password"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-500" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400 hover:text-gray-500" />
                  )}
                </button>
              </div>
              <p className="mt-1 text-xs text-gray-500">
                Required to decrypt table names in the imported data
              </p>
            </div>

            <button
              onClick={handleCopyQuery}
              className="text-indigo-600 hover:text-indigo-800 text-sm font-medium flex items-center"
            >
              {showCopySuccess ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Query Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy Table Metrics Query to Clipboard
                </>
              )}
            </button>

            <div className="flex justify-end space-x-3">
              <button
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleImport}
                disabled={!pastedData || !decryptionPassword || isSubmitting}
                className={`inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                  !pastedData || !decryptionPassword
                    ? 'bg-indigo-400 cursor-not-allowed'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
                title={!decryptionPassword ? 'Enter Decryption Password First...' : ''}
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  'Import Data'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      <SqlPreviewModal
        isOpen={showSqlPreview}
        onClose={() => setShowSqlPreview(false)}
        sql={generatedSql}
      />
    </div>
  );
}