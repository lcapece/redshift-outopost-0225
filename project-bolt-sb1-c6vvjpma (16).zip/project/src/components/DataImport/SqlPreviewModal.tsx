import React, { useState } from 'react';
import { X, Copy, CheckCircle, AlertCircle } from 'lucide-react';

interface SqlPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  sql: string;
}

export function SqlPreviewModal({ isOpen, onClose, sql }: SqlPreviewModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(sql);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy SQL:', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4">
        <div className="flex justify-between items-center px-6 py-4 border-b">
          <h2 className="text-lg font-semibold text-gray-900">Generated SQL Query</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-500">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="bg-gray-50 rounded-lg border border-gray-200 overflow-hidden">
            <div className="flex justify-between items-center px-4 py-2 bg-gray-100 border-b">
              <div className="text-sm text-gray-600">SELECT Statement</div>
              <button
                onClick={handleCopy}
                className="inline-flex items-center px-3 py-1 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 border border-gray-200"
              >
                {copied ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-1.5 text-green-500" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-1.5" />
                    Copy SQL
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-sm font-mono text-gray-800 whitespace-pre-wrap">
              {sql}
            </pre>
          </div>

          <div className="mt-4 bg-blue-50 rounded-lg p-4">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-blue-400 mr-2" />
              <div className="text-sm text-blue-700">
                <p className="font-medium">Query Information</p>
                <ul className="mt-2 list-disc list-inside">
                  <li>Uses fully qualified schema.table references</li>
                  <li>Includes all selected columns and applied filters</li>
                  <li>Follows Redshift best practices for performance</li>
                  <li>Properly formatted for readability</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}