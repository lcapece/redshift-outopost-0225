import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Search, Download, Lock, Eye, EyeOff, Info, Trash2, AlertTriangle } from 'lucide-react';
import CryptoJS from 'crypto-js';

interface TableData {
  id?: string;
  database_name: string;
  schema_name: string;
  table_name: string;
  encoded: boolean;
  diststyle: string;
  dist_key?: string;
  sortkey1: string | null;
  sortkey1_enc: string | null;
  sortkey_num: number;
  size_gb: number;
  pct_empty: number;
  unsorted_pct: number;
  stats_off: number;
  tbl_rows: number;
  skew_sortkey1: number;
  skew_rows: number;
  estimated_visible_rows: number;
  risk_event: string | null;
}

interface DataGridProps {
  data: TableData[];
  onExport?: () => void;
  onDeleteAll?: () => void;
}

export function DataGrid({ data, onExport, onDeleteAll }: DataGridProps) {
  const [sortField, setSortField] = useState<keyof TableData>('database_name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const [decryptionPassword, setDecryptionPassword] = useState('');
  const [showDecrypted, setShowDecrypted] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [decryptError, setDecryptError] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const rowsPerPage = 10;

  const formatNumber = (value: number): string => {
    if (value >= 1_000_000_000) {
      return `${(value / 1_000_000_000).toFixed(2)}B`;
    } else if (value >= 1_000_000) {
      return `${(value / 1_000_000).toFixed(2)}M`;
    } else if (value >= 1_000) {
      return `${(value / 1_000).toFixed(1)}K`;
    }
    return value.toLocaleString();
  };

  const handleToggleDecryption = () => {
    if (!decryptionPassword) {
      setDecryptError('Please enter a decryption password');
      return;
    }
    setDecryptError(null);
    setShowDecrypted(!showDecrypted);
  };

  const handleDeleteConfirm = () => {
    if (onDeleteAll) {
      onDeleteAll();
    }
    setShowDeleteConfirm(false);
  };

  const decryptValue = (value: string, type: 'D' | 'S' | 'T'): string => {
    if (!value || value.length !== 16 || value[0] !== type) {
      return value;
    }

    try {
      // Extract the hash part (15 characters after the prefix)
      const hashPart = value.substring(1);
      
      // Generate hashes for common database/schema/table names until we find a match
      const commonNames = [
        'DATAWAREHOUSE', 'ANALYTICS', 'STAGING', 'PRODUCTION', 'DEVELOPMENT',  // Databases
        'PUBLIC', 'ADMIN', 'STAGE', 'TEMP', 'DBO', 'REPORTING',               // Schemas
        'USERS', 'CUSTOMERS', 'ORDERS', 'PRODUCTS', 'SALES',                  // Tables
        'EMPLOYEES', 'TRANSACTIONS', 'INVENTORY', 'METRICS', 'EVENTS',        // More tables
        'FACT_SALES', 'DIM_CUSTOMER', 'DIM_PRODUCT', 'DIM_DATE',             // Data warehouse tables
        'STG_ORDERS', 'STG_CUSTOMERS', 'STG_PRODUCTS',                        // Staging tables
        'V_SALES_SUMMARY', 'V_CUSTOMER_METRICS', 'V_PRODUCT_ANALYTICS'        // Views
      ];

      for (const name of commonNames) {
        const testHash = CryptoJS.SHA256(name + decryptionPassword).toString();
        if (testHash.substring(0, 15) === hashPart) {
          return name;
        }
      }

      // If no match found, show a formatted version of the encrypted value
      return `${type}:${hashPart.substring(0, 8)}...`;
    } catch (error) {
      console.error('Error decrypting value:', error);
      return value;
    }
  };

  const getDisplayValue = (value: string, type: 'D' | 'S' | 'T'): string => {
    if (!showDecrypted || !decryptionPassword || !value) return value;
    return decryptValue(value, type);
  };

  const filteredData = data.filter(row => {
    if (!showDecrypted) return true; // Only filter when viewing decrypted names
    const searchLower = searchTerm.toLowerCase();
    return (
      decryptValue(row.database_name, 'D').toLowerCase().includes(searchLower) ||
      decryptValue(row.schema_name, 'S').toLowerCase().includes(searchLower) ||
      decryptValue(row.table_name, 'T').toLowerCase().includes(searchLower)
    );
  });

  const sortedData = [...filteredData].sort((a, b) => {
    let comparison = 0;
    
    if (sortField === 'size_gb' || sortField === 'unsorted_pct' || sortField === 'stats_off' || 
        sortField === 'tbl_rows' || sortField === 'skew_sortkey1' || sortField === 'skew_rows' ||
        sortField === 'pct_empty' || sortField === 'sortkey_num' || sortField === 'estimated_visible_rows') {
      comparison = (a[sortField] || 0) - (b[sortField] || 0);
    } else if (sortField === 'database_name' || sortField === 'schema_name' || sortField === 'table_name') {
      // For encrypted fields, compare decrypted values when decryption is enabled
      const aValue = showDecrypted ? 
        decryptValue(a[sortField], sortField === 'database_name' ? 'D' : sortField === 'schema_name' ? 'S' : 'T') : 
        a[sortField];
      const bValue = showDecrypted ? 
        decryptValue(b[sortField], sortField === 'database_name' ? 'D' : sortField === 'schema_name' ? 'S' : 'T') : 
        b[sortField];
      comparison = String(aValue).localeCompare(String(bValue));
    } else {
      comparison = String(a[sortField]).localeCompare(String(b[sortField]));
    }
    
    return sortDirection === 'asc' ? comparison : -comparison;
  });

  const totalPages = Math.ceil(sortedData.length / rowsPerPage);
  const startIndex = (page - 1) * rowsPerPage;
  const paginatedData = sortedData.slice(startIndex, startIndex + rowsPerPage);

  const getMetricColor = (column: any, value: number): string => {
    switch (column.key) {
      case 'unsorted_pct':
        const sortedPct = 100 - value;
        return sortedPct < 65 ? 'text-red-600' : 
               sortedPct < 85 ? 'text-amber-600' : 
               'text-green-600';
      case 'stats_off':
        const statsFresh = 100 - value;
        return statsFresh < 50 ? 'text-red-600' : 
               statsFresh < 80 ? 'text-amber-600' : 
               'text-green-600';
      case 'skew_sortkey1':
      case 'skew_rows':
        return value > 5 ? 'text-red-600' : 
               value > 2 ? 'text-amber-600' : 
               'text-green-600';
      default:
        return '';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="p-3 border-b border-gray-200">
        <div className="flex flex-col space-y-3">
          {/* Decryption Controls */}
          <div className="flex items-center space-x-4">
            <div className="flex-1 max-w-sm">
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={decryptionPassword}
                  onChange={(e) => setDecryptionPassword(e.target.value)}
                  placeholder="Enter decryption password"
                  className="w-full pl-10 pr-12 py-1.5 border border-gray-300 rounded-md text-sm"
                />
                <Lock className="absolute left-3 top-2 h-4 w-4 text-gray-400" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400 hover:text-gray-500" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400 hover:text-gray-500" />
                  )}
                </button>
              </div>
              {decryptError && (
                <p className="mt-1 text-xs text-red-600">{decryptError}</p>
              )}
            </div>
            <button
              onClick={handleToggleDecryption}
              disabled={!decryptionPassword}
              className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:bg-gray-100 disabled:text-gray-400"
            >
              {showDecrypted ? (
                <>
                  <EyeOff className="h-4 w-4 mr-2" />
                  Hide Decrypted Names
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4 mr-2" />
                  Show Decrypted Names
                </>
              )}
            </button>
          </div>

          {/* Search and Actions */}
          <div className="flex justify-between items-center">
            <div className="flex-1 max-w-sm relative group">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search encrypted fields..."
                  disabled={!showDecrypted}
                  className={`w-full pl-10 pr-4 py-1.5 border border-gray-300 rounded-md text-sm ${
                    !showDecrypted ? 'bg-gray-100 cursor-not-allowed' : ''
                  }`}
                />
                <Search className="absolute left-3 top-2 h-4 w-4 text-gray-400" />
                {!showDecrypted && (
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <Info className="h-4 w-4 text-gray-400" />
                  </div>
                )}
              </div>
              {!showDecrypted && (
                <div className="absolute left-0 -bottom-12 w-64 bg-gray-800 text-white text-xs rounded p-2 invisible group-hover:visible z-10">
                  Search is only available when viewing decrypted field names
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-2">
              {onDeleteAll && data.length > 0 && (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="inline-flex items-center px-3 py-1.5 border border-red-300 text-sm font-medium rounded-md text-red-700 bg-white hover:bg-red-50"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete All Data
                </button>
              )}
              
              {onExport && (
                <button
                  onClick={onExport}
                  className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="overflow-auto max-h-[calc(100vh-24rem)]">
        <div className="min-w-max">
          <table className="w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                {[
                  { key: 'database_name', label: 'Database Name' },
                  { key: 'schema_name', label: 'Schema Name' },
                  { key: 'table_name', label: 'Table Name' },
                  { key: 'encoded', label: 'Encoded' },
                  { key: 'diststyle', label: 'Distribution Style' },
                  { key: 'dist_key', label: 'Distribution Key' },
                  { key: 'sortkey1', label: 'Sort Key' },
                  { key: 'sortkey1_enc', label: 'Sort Key Encoding' },
                  { key: 'sortkey_num', label: 'Sort Key Count' },
                  { key: 'size_gb', label: 'Size (GB)' },
                  { key: 'pct_empty', label: 'Empty Space %' },
                  { key: 'unsorted_pct', label: 'Sorted %', transform: (value: number) => `${(100 - value).toFixed(1)}%` },
                  { key: 'stats_off', label: 'Stats Freshness %', transform: (value: number) => `${(100 - value).toFixed(1)}%` },
                  { key: 'tbl_rows', label: 'Total Rows' },
                  { key: 'skew_sortkey1', label: 'Sort Key Skew' },
                  { key: 'skew_rows', label: 'Distribution Skew' },
                  { key: 'estimated_visible_rows', label: 'Estimated Visible Rows' },
                  { key: 'risk_event', label: 'Risk Event' }
                ].map((column) => (
                  <th
                    key={column.key}
                    scope="col"
                    className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                    onClick={() => {
                      if (sortField === column.key) {
                        setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                      } else {
                        setSortField(column.key as keyof TableData);
                        setSortDirection('asc');
                      }
                    }}
                  >
                    <div className="flex items-center space-x-1">
                      <span>{column.label}</span>
                      {sortField === column.key && (
                        sortDirection === 'asc' ? 
                          <ChevronUp className="h-4 w-4" /> : 
                          <ChevronDown className="h-4 w-4" />
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {paginatedData.map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-gray-50">
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {getDisplayValue(row.database_name, 'D')}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {getDisplayValue(row.schema_name, 'S')}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {getDisplayValue(row.table_name, 'T')}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.encoded ? 'Yes' : 'No'}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.diststyle}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.dist_key || '-'}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.sortkey1 || '-'}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.sortkey1_enc || '-'}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.sortkey_num}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.size_gb.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 1 })}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.pct_empty.toFixed(1)}%
                  </td>
                  <td className={`px-4 py-1.5 whitespace-nowrap text-xs ${getMetricColor({ key: 'unsorted_pct' }, row.unsorted_pct)}`}>
                    {(100 - row.unsorted_pct).toFixed(1)}%
                  </td>
                  <td className={`px-4 py-1.5 whitespace-nowrap text-xs ${getMetricColor({ key: 'stats_off' }, row.stats_off)}`}>
                    {(100 - row.stats_off).toFixed(1)}%
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {formatNumber(row.tbl_rows)}
                  </td>
                  <td className={`px-4 py-1.5 whitespace-nowrap text-xs ${getMetricColor({ key: 'skew_sortkey1' }, row.skew_sortkey1)}`}>
                    {row.skew_sortkey1.toFixed(2)}
                  </td>
                  <td className={`px-4 py-1.5 whitespace-nowrap text-xs ${getMetricColor({ key: 'skew_rows' }, row.skew_rows)}`}>
                    {row.skew_rows.toFixed(2)}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {formatNumber(row.estimated_visible_rows)}
                  </td>
                  <td className="px-4 py-1.5 whitespace-nowrap text-xs">
                    {row.risk_event || '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {totalPages > 1 && (
        <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => setPage(page - 1)}
              disabled={page === 1}
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Previous
            </button>
            <button
              onClick={() => setPage(page + 1)}
              disabled={page === totalPages}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
            >
              Next
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing{' '}
                <span className="font-medium">{startIndex + 1}</span>
                {' '}to{' '}
                <span className="font-medium">
                  {Math.min(startIndex + rowsPerPage, sortedData.length)}
                </span>
                {' '}of{' '}
                <span className="font-medium">{sortedData.length}</span>
                {' '}results
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                <button
                  onClick={() => setPage(1)}
                  disabled={page === 1}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  First
                </button>
                <button
                  onClick={() => setPage(page - 1)}
                  disabled={page === 1}
                  className="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  Previous
                </button>
                <span className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
                  Page {page} of {totalPages}
                </span>
                <button
                  onClick={() => setPage(page + 1)}
                  disabled={page === totalPages}
                  className="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  Next
                </button>
                <button
                  onClick={() => setPage(totalPages)}
                  disabled={page === totalPages}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                >
                  Last
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900">Delete All Data</h3>
            </div>
            <p className="text-sm text-gray-500 mb-6">
              Are you sure you want to delete all data? This action cannot be undone and will permanently remove all records from the table.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteConfirm}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
              >
                Delete All Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}