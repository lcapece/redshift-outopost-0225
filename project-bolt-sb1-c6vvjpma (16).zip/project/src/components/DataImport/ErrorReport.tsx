import React, { useState } from 'react';
import { AlertTriangle, Camera, Copy, CheckCircle } from 'lucide-react';

interface ErrorReportProps {
  onSubmit: (report: ErrorReportData) => void;
}

export interface ErrorReportData {
  steps: string[];
  fileType: string;
  fileFormat: string;
  errorMessages: string[];
  pageUrl: string;
  browserInfo: string;
  timestamp: string;
  screenshots: File[];
}

export function ErrorReport({ onSubmit }: ErrorReportProps) {
  const [report, setReport] = useState<ErrorReportData>({
    steps: [''],
    fileType: '',
    fileFormat: '',
    errorMessages: [''],
    pageUrl: window.location.href,
    browserInfo: `${navigator.userAgent}`,
    timestamp: new Date().toISOString(),
    screenshots: []
  });
  const [copied, setCopied] = useState(false);

  const handleAddStep = () => {
    setReport(prev => ({
      ...prev,
      steps: [...prev.steps, '']
    }));
  };

  const handleStepChange = (index: number, value: string) => {
    setReport(prev => ({
      ...prev,
      steps: prev.steps.map((step, i) => i === index ? value : step)
    }));
  };

  const handleAddError = () => {
    setReport(prev => ({
      ...prev,
      errorMessages: [...prev.errorMessages, '']
    }));
  };

  const handleErrorChange = (index: number, value: string) => {
    setReport(prev => ({
      ...prev,
      errorMessages: prev.errorMessages.map((error, i) => i === index ? value : error)
    }));
  };

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setReport(prev => ({
      ...prev,
      screenshots: [...prev.screenshots, ...files]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(report);
  };

  const copyToClipboard = async () => {
    const reportText = `
SVV_TABLE_INFO Import Error Report
================================

Timestamp: ${report.timestamp}
Page URL: ${report.pageUrl}
Browser: ${report.browserInfo}

Steps to Reproduce:
${report.steps.map((step, i) => `${i + 1}. ${step}`).join('\n')}

File Information:
- Type: ${report.fileType}
- Format: ${report.fileFormat}

Error Messages:
${report.errorMessages.map(error => `- ${error}`).join('\n')}
    `.trim();

    try {
      await navigator.clipboard.writeText(reportText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy report:', err);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
        <h2 className="text-xl font-semibold text-gray-900">Error Report</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Steps to Reproduce */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Steps to Reproduce
          </label>
          {report.steps.map((step, index) => (
            <div key={index} className="flex mb-2">
              <span className="flex-shrink-0 w-8 text-gray-500">{index + 1}.</span>
              <input
                type="text"
                value={step}
                onChange={(e) => handleStepChange(index, e.target.value)}
                className="flex-1 border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Describe what you did..."
              />
            </div>
          ))}
          <button
            type="button"
            onClick={handleAddStep}
            className="mt-2 text-sm text-indigo-600 hover:text-indigo-500"
          >
            + Add another step
          </button>
        </div>

        {/* File Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="fileType" className="block text-sm font-medium text-gray-700 mb-2">
              File Type
            </label>
            <input
              type="text"
              id="fileType"
              value={report.fileType}
              onChange={(e) => setReport(prev => ({ ...prev, fileType: e.target.value }))}
              className="w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., CSV, Text"
            />
          </div>
          <div>
            <label htmlFor="fileFormat" className="block text-sm font-medium text-gray-700 mb-2">
              File Format
            </label>
            <input
              type="text"
              id="fileFormat"
              value={report.fileFormat}
              onChange={(e) => setReport(prev => ({ ...prev, fileFormat: e.target.value }))}
              className="w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="e.g., Comma-separated, Tab-delimited"
            />
          </div>
        </div>

        {/* Error Messages */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Error Messages
          </label>
          {report.errorMessages.map((error, index) => (
            <div key={index} className="mb-2">
              <input
                type="text"
                value={error}
                onChange={(e) => handleErrorChange(index, e.target.value)}
                className="w-full border border-gray-300 rounded-md shadow-sm px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Copy and paste the error message..."
              />
            </div>
          ))}
          <button
            type="button"
            onClick={handleAddError}
            className="mt-2 text-sm text-indigo-600 hover:text-indigo-500"
          >
            + Add another error message
          </button>
        </div>

        {/* Screenshots */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Screenshots
          </label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <Camera className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label
                  htmlFor="screenshots"
                  className="relative cursor-pointer bg-white rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500"
                >
                  <span>Upload screenshots</span>
                  <input
                    id="screenshots"
                    type="file"
                    multiple
                    accept="image/*"
                    className="sr-only"
                    onChange={handleScreenshotUpload}
                  />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">
                PNG, JPG, GIF up to 10MB each
              </p>
            </div>
          </div>
          {report.screenshots.length > 0 && (
            <div className="mt-2 grid grid-cols-2 gap-2">
              {report.screenshots.map((file, index) => (
                <div key={index} className="text-sm text-gray-500">
                  {file.name}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* System Information */}
        <div className="bg-gray-50 rounded-md p-4">
          <h3 className="text-sm font-medium text-gray-700 mb-2">System Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-500">
            <div>
              <span className="font-medium">Page URL:</span> {report.pageUrl}
            </div>
            <div>
              <span className="font-medium">Browser:</span> {report.browserInfo}
            </div>
            <div>
              <span className="font-medium">Timestamp:</span> {new Date(report.timestamp).toLocaleString()}
            </div>
          </div>
        </div>

        <div className="flex justify-between">
          <button
            type="button"
            onClick={copyToClipboard}
            className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {copied ? (
              <>
                <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-2" />
                Copy Report
              </>
            )}
          </button>

          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Submit Report
          </button>
        </div>
      </form>
    </div>
  );
}