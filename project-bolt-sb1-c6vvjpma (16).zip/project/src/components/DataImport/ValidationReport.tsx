import React from 'react';
import { AlertTriangle, CheckCircle, Clock, Download } from 'lucide-react';
import { ValidationResult } from '../../services/validationService';
import { formatValidationReport } from '../../services/validationReportService';

interface ValidationReportProps {
  urlResults: ValidationResult[];
  importResults: ValidationResult[];
  onExport: () => void;
}

export function ValidationReport({ urlResults, importResults, onExport }: ValidationReportProps) {
  const totalTests = urlResults.length + importResults.length;
  const passedTests = [...urlResults, ...importResults].filter(r => r.success).length;
  const warningCount = [...urlResults, ...importResults].reduce(
    (count, result) => count + result.warnings.length,
    0
  );

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-semibold text-gray-900">Validation Report</h2>
          <button
            onClick={onExport}
            className="inline-flex items-center px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            <Download className="h-4 w-4 mr-1.5" />
            Export Report
          </button>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center">
              <CheckCircle className={`h-5 w-5 mr-2 ${
                passedTests === totalTests ? 'text-green-500' : 'text-yellow-500'
              }`} />
              <span className="text-sm font-medium text-gray-900">Pass Rate</span>
            </div>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {((passedTests / totalTests) * 100).toFixed(1)}%
            </p>
            <p className="text-sm text-gray-500">
              {passedTests} of {totalTests} tests passed
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2 text-yellow-500" />
              <span className="text-sm font-medium text-gray-900">Warnings</span>
            </div>
            <p className="mt-2 text-2xl font-semibold text-gray-900">
              {warningCount}
            </p>
            <p className="text-sm text-gray-500">
              Non-critical issues found
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center">
              <Clock className="h-5 w-5 mr-2 text-blue-500" />
              <span className="text-sm font-medium text-gray-900">Generated</span>
            </div>
            <p className="mt-2 text-sm font-medium text-gray-900">
              {new Date().toLocaleString()}
            </p>
            <p className="text-sm text-gray-500">
              Latest validation run
            </p>
          </div>
        </div>

        {/* URL Validations */}
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-900 mb-3">URL Validations</h3>
          <div className="space-y-4">
            {urlResults.map((result, index) => (
              <div 
                key={index}
                className={`border rounded-lg p-4 ${
                  result.success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    {result.success ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                    )}
                    <span className={`font-medium ${
                      result.success ? 'text-green-900' : 'text-red-900'
                    }`}>
                      {result.details.url}
                    </span>
                  </div>
                  <span className="text-sm">
                    {result.details.responseTime.toFixed(0)}ms
                  </span>
                </div>

                {result.errors.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {result.errors.map((error, i) => (
                      <li key={i} className="text-sm text-red-700">
                        • {error}
                      </li>
                    ))}
                  </ul>
                )}

                {result.warnings.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {result.warnings.map((warning, i) => (
                      <li key={i} className="text-sm text-yellow-700">
                        • {warning}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Import Validations */}
        <div>
          <h3 className="text-sm font-medium text-gray-900 mb-3">Import Validations</h3>
          <div className="space-y-4">
            {importResults.map((result, index) => (
              <div 
                key={index}
                className={`border rounded-lg p-4 ${
                  result.success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    {result.success ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    ) : (
                      <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
                    )}
                    <span className={`font-medium ${
                      result.success ? 'text-green-900' : 'text-red-900'
                    }`}>
                      Import Validation
                    </span>
                  </div>
                  <div className="text-sm space-x-4">
                    <span>Rows: {result.details.rowsProcessed}</span>
                    <span>Valid: {result.details.validRows}</span>
                    <span>Invalid: {result.details.invalidRows}</span>
                  </div>
                </div>

                {result.errors.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {result.errors.map((error, i) => (
                      <li key={i} className="text-sm text-red-700">
                        • {error}
                      </li>
                    ))}
                  </ul>
                )}

                {result.warnings.length > 0 && (
                  <ul className="mt-2 space-y-1">
                    {result.warnings.map((warning, i) => (
                      <li key={i} className="text-sm text-yellow-700">
                        • {warning}
                      </li>
                    ))}
                  </ul>
                )}

                {Object.entries(result.details.errorRows).length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Row-level Errors</h4>
                    <div className="bg-white rounded border border-gray-200 overflow-hidden">
                      {Object.entries(result.details.errorRows).map(([row, errors]) => (
                        <div key={row} className="p-3 border-b last:border-b-0">
                          <div className="font-medium text-sm text-gray-900 mb-1">
                            Row {row}
                          </div>
                          <ul className="space-y-1">
                            {errors.map((error, i) => (
                              <li key={i} className="text-sm text-red-600">
                                • {error}
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}