import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, AlertTriangle, Shield } from 'lucide-react';
import zxcvbn from 'zxcvbn';

interface PasswordInputProps {
  value: string;
  onChange: (value: string) => void;
  onValidation: (isValid: boolean) => void;
}

export function PasswordInput({ value, onChange, onValidation }: PasswordInputProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [confirmation, setConfirmation] = useState('');
  const [strength, setStrength] = useState(0);
  const [feedback, setFeedback] = useState<string[]>([]);

  useEffect(() => {
    if (value) {
      const result = zxcvbn(value);
      setStrength(result.score);
      setFeedback([
        ...result.feedback.suggestions,
        result.feedback.warning
      ].filter(Boolean));
    } else {
      setStrength(0);
      setFeedback([]);
    }
  }, [value]);

  useEffect(() => {
    const isValid = value.length >= 12 && value === confirmation && strength >= 3;
    onValidation(isValid);
  }, [value, confirmation, strength, onValidation]);

  const getStrengthColor = (score: number) => {
    switch (score) {
      case 0: return 'bg-red-500';
      case 1: return 'bg-orange-500';
      case 2: return 'bg-yellow-500';
      case 3: return 'bg-green-500';
      case 4: return 'bg-emerald-500';
      default: return 'bg-gray-200';
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-bold text-red-600 mb-2">
          Decrypt Password
        </label>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="block w-full pr-10 border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
            placeholder="Enter encryption password"
            minLength={12}
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 px-3 flex items-center"
          >
            {showPassword ? (
              <EyeOff className="h-5 w-5 text-gray-400" />
            ) : (
              <Eye className="h-5 w-5 text-gray-400" />
            )}
          </button>
        </div>

        {/* Password Strength Indicator */}
        <div className="mt-2">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-gray-500">Password Strength</span>
            <span className="text-xs font-medium">
              {strength === 0 ? 'Very Weak' :
               strength === 1 ? 'Weak' :
               strength === 2 ? 'Fair' :
               strength === 3 ? 'Good' :
               'Strong'}
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${getStrengthColor(strength)}`}
              style={{ width: `${(strength + 1) * 20}%` }}
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Confirm Password
        </label>
        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={confirmation}
            onChange={(e) => setConfirmation(e.target.value)}
            className="block w-full pr-10 border-gray-300 rounded-md focus:ring-red-500 focus:border-red-500"
            placeholder="Confirm encryption password"
            required
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute inset-y-0 right-0 px-3 flex items-center"
          >
            {showPassword ? (
              <EyeOff className="h-5 w-5 text-gray-400" />
            ) : (
              <Eye className="h-5 w-5 text-gray-400" />
            )}
          </button>
        </div>
        {value && confirmation && value !== confirmation && (
          <p className="mt-1 text-sm text-red-600">Passwords do not match</p>
        )}
      </div>

      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <div className="flex">
          <AlertTriangle className="h-5 w-5 text-red-400 mr-2" />
          <div>
            <p className="text-sm font-medium text-red-800">
              ⚠️ DATA WILL BE ENCRYPTED USING THIS PASSWORD. IF LOST, DATA CANNOT BE RECOVERED.
            </p>
            {feedback.length > 0 && (
              <ul className="mt-2 text-sm text-red-700 list-disc list-inside">
                {feedback.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="bg-gray-50 rounded-md p-4">
        <div className="flex">
          <Shield className="h-5 w-5 text-gray-400 mr-2" />
          <div className="text-sm text-gray-600">
            <p className="font-medium">Password Requirements:</p>
            <ul className="mt-1 list-disc list-inside">
              <li>Minimum 12 characters</li>
              <li>Mix of uppercase and lowercase letters</li>
              <li>At least one number</li>
              <li>At least one special character</li>
              <li>No common words or patterns</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}