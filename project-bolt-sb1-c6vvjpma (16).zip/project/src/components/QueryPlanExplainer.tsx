import React from 'react';
import { Info } from 'lucide-react';
import { getDistributionStyleExplanation } from '../utils/distributionStylesGuide';

interface QueryPlanExplainerProps {
  queryPlan: string;
}

interface OperationInfo {
  type: string;
  count: number;
  rowsTotal: number;
  costTotal: number;
  costLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'HIGHEST';
}

export function QueryPlanExplainer({ queryPlan }: QueryPlanExplainerProps) {
  // This component has been intentionally left empty as requested
  return null;
}