import React from 'react';
import { LogIn } from 'lucide-react';
import { useAuth0 } from '@auth0/auth0-react';

interface Auth0LoginButtonProps {
  className?: string;
}

export const Auth0LoginButton: React.FC<Auth0LoginButtonProps> = ({ className }) => {
  const { loginWithRedirect, isLoading } = useAuth0();

  return (
    <button
      onClick={() => loginWithRedirect()}
      disabled={isLoading}
      className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${className || ''}`}
    >
      <LogIn className="h-4 w-4 mr-2" />
      {isLoading ? 'Loading...' : 'Sign In with Auth0'}
    </button>
  );
};