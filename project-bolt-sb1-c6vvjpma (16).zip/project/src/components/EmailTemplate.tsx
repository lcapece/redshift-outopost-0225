import React from 'react';

interface EmailTemplateProps {
  verificationUrl: string;
  recipientName?: string;
}

export function EmailVerificationTemplate({ verificationUrl, recipientName = 'there' }: EmailTemplateProps) {
  // This component represents the HTML email template that would be sent
  // In a real implementation, this would be rendered server-side and sent via email
  
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '600px', margin: '0 auto', padding: '20px', backgroundColor: '#f9fafb', color: '#1f2937' }}>
      <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '30px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <h1 style={{ color: '#4f46e5', fontSize: '24px', margin: '0' }}>Redshift Outpost</h1>
          <p style={{ color: '#6b7280', fontSize: '16px', marginTop: '5px' }}>Verify Your Email Address</p>
        </div>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          Hi {recipientName},
        </p>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          Thanks for signing up for Redshift Outpost! Please verify your email address by clicking the button below.
        </p>
        
        <div style={{ textAlign: 'center', margin: '32px 0' }}>
          <a 
            href={verificationUrl} 
            style={{ 
              backgroundColor: '#4f46e5', 
              color: 'white', 
              padding: '12px 24px', 
              borderRadius: '6px', 
              textDecoration: 'none', 
              fontWeight: 'bold',
              display: 'inline-block'
            }}
          >
            Verify Email Address
          </a>
        </div>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          This verification link will expire in 24 hours. If you did not create an account, you can safely ignore this email.
        </p>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          If you're having trouble clicking the button, copy and paste the URL below into your web browser:
        </p>
        
        <p style={{ 
          fontSize: '14px', 
          lineHeight: '1.5', 
          marginBottom: '24px', 
          padding: '12px', 
          backgroundColor: '#f3f4f6', 
          borderRadius: '4px',
          wordBreak: 'break-all'
        }}>
          {verificationUrl}
        </p>
        
        <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: '24px', marginTop: '24px', textAlign: 'center', color: '#6b7280', fontSize: '14px' }}>
          <p style={{ margin: '0 0 8px 0' }}>
            &copy; 2025 Redshift Outpost. All rights reserved.
          </p>
          <p style={{ margin: '0' }}>
            Spaceship.com, Inc. • 123 Galactic Way • Universe City, Space 12345
          </p>
        </div>
      </div>
    </div>
  );
}

export function PasswordResetTemplate({ verificationUrl, recipientName = 'there' }: EmailTemplateProps) {
  // This component represents the HTML email template that would be sent for password reset
  // In a real implementation, this would be rendered server-side and sent via email
  
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '600px', margin: '0 auto', padding: '20px', backgroundColor: '#f9fafb', color: '#1f2937' }}>
      <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '30px', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <div style={{ textAlign: 'center', marginBottom: '30px' }}>
          <h1 style={{ color: '#4f46e5', fontSize: '24px', margin: '0' }}>Redshift Outpost</h1>
          <p style={{ color: '#6b7280', fontSize: '16px', marginTop: '5px' }}>Reset Your Password</p>
        </div>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          Hi {recipientName},
        </p>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          We received a request to reset your password for your Redshift Outpost account. Click the button below to reset your password.
        </p>
        
        <div style={{ textAlign: 'center', margin: '32px 0' }}>
          <a 
            href={verificationUrl} 
            style={{ 
              backgroundColor: '#4f46e5', 
              color: 'white', 
              padding: '12px 24px', 
              borderRadius: '6px', 
              textDecoration: 'none', 
              fontWeight: 'bold',
              display: 'inline-block'
            }}
          >
            Reset Password
          </a>
        </div>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          This password reset link will expire in 1 hour. If you did not request a password reset, you can safely ignore this email.
        </p>
        
        <p style={{ fontSize: '16px', lineHeight: '1.5', marginBottom: '24px' }}>
          If you're having trouble clicking the button, copy and paste the URL below into your web browser:
        </p>
        
        <p style={{ 
          fontSize: '14px', 
          lineHeight: '1.5', 
          marginBottom: '24px', 
          padding: '12px', 
          backgroundColor: '#f3f4f6', 
          borderRadius: '4px',
          wordBreak: 'break-all'
        }}>
          {verificationUrl}
        </p>
        
        <div style={{ borderTop: '1px solid #e5e7eb', paddingTop: '24px', marginTop: '24px', textAlign: 'center', color: '#6b7280', fontSize: '14px' }}>
          <p style={{ margin: '0 0 8px 0' }}>
            &copy; 2025 Redshift Outpost. All rights reserved.
          </p>
          <p style={{ margin: '0' }}>
            Spaceship.com, Inc. • 123 Galactic Way • Universe City, Space 12345
          </p>
        </div>
      </div>
    </div>
  );
}