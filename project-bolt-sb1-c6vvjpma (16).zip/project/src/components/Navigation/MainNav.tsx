import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Menu, X, ChevronDown, ChevronRight, Database, 
  LineChart, Newspaper, FileText, TableProperties, 
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface NavItem {
  name: string;
  path: string;
  icon: React.ReactNode;
  requiresAuth?: boolean;
  children?: NavItem[];
}

export function MainNav() {
  const { user } = useAuth();
  const location = useLocation();
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const navItems = [
    {
      name: 'Analytics',
      path: '/analytics',
      icon: <LineChart className="h-5 w-5" />,
      children: [
        { name: 'Query Analysis', path: '/analytics', icon: <LineChart className="h-5 w-5" /> },
        { name: 'Query Visualizer', path: '/visualizer', icon: <Database className="h-5 w-5" /> }
      ]
    },
    {
      name: 'Data Management',
      path: '/data-explorer',
      icon: <Database className="h-5 w-5" />,
      requiresAuth: true,
      children: [
        { name: 'Data Explorer', path: '/data-explorer', icon: <TableProperties className="h-5 w-5" /> },
        { name: 'Content Management', path: '/admin/content', icon: <Newspaper className="h-5 w-5" /> }
      ]
    },
    {
      name: 'Resources',
      path: '/news',
      icon: <Newspaper className="h-5 w-5" />,
      children: [
        { name: 'News', path: '/news', icon: <Newspaper className="h-5 w-5" /> },
        { name: 'Scripts', path: '/scripts', icon: <FileText className="h-5 w-5" /> },
        { name: 'Forum', path: '/forum', icon: <MessageSquare className="h-5 w-5" /> }
      ]
    }
  ];

  const filteredNavItems = navItems.filter(item => {
    if (item.requiresAuth && !user) return false;
    return true;
  });

  const handleDropdownToggle = (path: string) => {
    setOpenDropdown(openDropdown === path ? null : path);
  };

  const isActive = (path: string) => location.pathname === path;
  const isParentActive = (item: NavItem) => {
    if (isActive(item.path)) return true;
    return item.children?.some(child => isActive(child.path));
  };

  return (
    <nav className="hidden md:flex space-x-1">
      {filteredNavItems.map((item) => (
        <div key={item.path} className="relative group">
          {item.children ? (
            <button
              onClick={() => handleDropdownToggle(item.path)}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium ${
                isParentActive(item)
                  ? 'text-indigo-600 bg-indigo-50'
                  : 'text-gray-500 hover:text-indigo-600 hover:bg-gray-50'
              }`}
            >
              {item.icon}
              <span>{item.name}</span>
              {openDropdown === item.path ? (
                <ChevronDown className="h-4 w-4 ml-1" />
              ) : (
                <ChevronRight className="h-4 w-4 ml-1" />
              )}
            </button>
          ) : (
            <Link
              to={item.path}
              className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium ${
                isActive(item.path)
                  ? 'text-indigo-600 bg-indigo-50'
                  : 'text-gray-500 hover:text-indigo-600 hover:bg-gray-50'
              }`}
            >
              {item.icon}
              <span>{item.name}</span>
            </Link>
          )}

          {item.children && openDropdown === item.path && (
            <div className="absolute z-10 left-0 mt-1 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
              <div className="py-1" role="menu">
                {item.children.map((child) => (
                  <Link
                    key={child.path}
                    to={child.path}
                    className={`flex items-center px-4 py-2 text-sm ${
                      isActive(child.path)
                        ? 'text-indigo-600 bg-indigo-50'
                        : 'text-gray-700 hover:bg-gray-50 hover:text-indigo-600'
                    }`}
                    role="menuitem"
                  >
                    {child.icon}
                    <span className="ml-2">{child.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </nav>
  );
}