import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Menu, X, ChevronDown, ChevronRight, Database, 
  LineChart, Newspaper, FileText, TableProperties, 
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface NavItem {
  name: string;
  path: string;
  icon: React.ReactNode;
  requiresAuth?: boolean;
  children?: NavItem[];
}

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const [openSections, setOpenSections] = useState<string[]>([]);
  const { user } = useAuth();
  const location = useLocation();

  const toggleSection = (path: string) => {
    setOpenSections(prev => 
      prev.includes(path) 
        ? prev.filter(p => p !== path)
        : [...prev, path]
    );
  };

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    {
      name: 'Analytics',
      path: '/analytics',
      icon: <LineChart className="h-5 w-5" />,
      children: [
        { name: 'Query Analysis', path: '/analytics', icon: <LineChart className="h-5 w-5" /> },
        { name: 'Query Visualizer', path: '/visualizer', icon: <Database className="h-5 w-5" /> }
      ]
    },
    {
      name: 'Data Management',
      path: '/data-explorer',
      icon: <Database className="h-5 w-5" />,
      requiresAuth: true,
      children: [
        { name: 'Data Explorer', path: '/data-explorer', icon: <TableProperties className="h-5 w-5" /> },
        { name: 'Content Management', path: '/admin/content', icon: <Newspaper className="h-5 w-5" /> }
      ]
    },
    {
      name: 'Resources',
      path: '/news',
      icon: <Newspaper className="h-5 w-5" />,
      children: [
        { name: 'News', path: '/news', icon: <Newspaper className="h-5 w-5" /> },
        { name: 'Scripts', path: '/scripts', icon: <FileText className="h-5 w-5" /> },
        { name: 'Forum', path: '/forum', icon: <MessageSquare className="h-5 w-5" /> }
      ]
    }
  ];

  const filteredNavItems = navItems.filter(item => {
    if (item.requiresAuth && !user) return false;
    return true;
  });

  return (
    <div className="md:hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
      >
        <span className="sr-only">Open main menu</span>
        {isOpen ? (
          <X className="block h-6 w-6" />
        ) : (
          <Menu className="block h-6 w-6" />
        )}
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 bg-gray-600 bg-opacity-75">
          <div className="fixed inset-y-0 left-0 w-full bg-white shadow-xl">
            <div className="pt-5 pb-6 px-4">
              <div className="flex items-center justify-end">
                <button
                  onClick={() => setIsOpen(false)}
                  className="rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
                >
                  <span className="sr-only">Close menu</span>
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="mt-6 space-y-1">
                {filteredNavItems.map((item) => (
                  <div key={item.path}>
                    {item.children ? (
                      <>
                        <button
                          onClick={() => toggleSection(item.path)}
                          className={`w-full flex items-center justify-between px-3 py-2 text-base font-medium rounded-md ${
                            isActive(item.path)
                              ? 'text-indigo-600 bg-indigo-50'
                              : 'text-gray-900 hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center">
                            {item.icon}
                            <span className="ml-3">{item.name}</span>
                          </div>
                          {openSections.includes(item.path) ? (
                            <ChevronDown className="h-5 w-5" />
                          ) : (
                            <ChevronRight className="h-5 w-5" />
                          )}
                        </button>
                        {openSections.includes(item.path) && (
                          <div className="ml-4 space-y-1">
                            {item.children.map((child) => (
                              <Link
                                key={child.path}
                                to={child.path}
                                onClick={() => setIsOpen(false)}
                                className={`flex items-center pl-3 pr-4 py-2 text-base font-medium rounded-md ${
                                  isActive(child.path)
                                    ? 'text-indigo-600 bg-indigo-50'
                                    : 'text-gray-600 hover:bg-gray-50 hover:text-indigo-600'
                                }`}
                              >
                                {child.icon}
                                <span className="ml-3">{child.name}</span>
                              </Link>
                            ))}
                          </div>
                        )}
                      </>
                    ) : (
                      <Link
                        to={item.path}
                        onClick={() => setIsOpen(false)}
                        className={`flex items-center px-3 py-2 text-base font-medium rounded-md ${
                          isActive(item.path)
                            ? 'text-indigo-600 bg-indigo-50'
                            : 'text-gray-900 hover:bg-gray-50'
                        }`}
                      >
                        {item.icon}
                        <span className="ml-3">{item.name}</span>
                      </Link>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}