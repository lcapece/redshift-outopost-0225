import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbsProps {
  items?: Array<{
    name: string;
    path?: string;
  }>;
}

export function Breadcrumbs({ items = [] }: BreadcrumbsProps) {
  const location = useLocation();
  
  // Generate breadcrumbs from current path if no items provided
  const pathItems = items.length === 0 
    ? location.pathname.split('/')
        .filter(Boolean)
        .map((part, index, array) => ({
          name: part.charAt(0).toUpperCase() + part.slice(1),
          path: '/' + array.slice(0, index + 1).join('/')
        }))
    : items;

  return (
    <nav className="flex" aria-label="Breadcrumb">
      <ol className="flex items-center space-x-4">
        <li>
          <Link
            to="/"
            className="text-gray-400 hover:text-gray-500"
          >
            <Home className="h-5 w-5" />
            <span className="sr-only">Home</span>
          </Link>
        </li>
        {pathItems.map((item, index) => (
          <li key={index} className="flex items-center">
            <ChevronRight className="h-5 w-5 text-gray-400" />
            {item.path && index < pathItems.length - 1 ? (
              <Link
                to={item.path}
                className="ml-4 text-sm font-medium text-gray-500 hover:text-gray-700"
              >
                {item.name}
              </Link>
            ) : (
              <span className="ml-4 text-sm font-medium text-gray-700">
                {item.name}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}