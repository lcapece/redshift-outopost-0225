import React, { useEffect, useRef, useState } from 'react';

interface MermaidDiagramProps {
  chart: string;
  svg?: string;
  className?: string;
}

export function MermaidDiagram({ chart, svg, className = '' }: MermaidDiagramProps) {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [textRepresentation, setTextRepresentation] = useState<string | null>(null);

  useEffect(() => {
    if (!chart) {
      setIsLoading(false);
      return;
    }

    // Generate a text representation of the chart
    try {
      const lines = chart.split('\n');
      let textRep = '';
      
      // Skip the first line if it's flowchart TD
      const startIndex = lines[0].trim().startsWith('flowchart TD') ? 1 : 0;
      
      for (let i = startIndex; i < lines.length; i++) {
        const line = lines[i].trim();
        
        // Skip class definitions and style lines
        if (line.startsWith('classDef') || line.startsWith('style') || line.startsWith('linkStyle')) {
          continue;
        }
        
        // Process node definitions and connections
        if (line.includes('-->')) {
          const parts = line.split('-->').map(p => p.trim());
          textRep += `${parts[0]} connects to ${parts[1]}\n`;
        } else if (line.includes('--')) {
          const parts = line.split('--').map(p => p.trim());
          textRep += `${parts[0]} links to ${parts[1]}\n`;
        } else if (line.match(/\w+\[.*\]/)) {
          // Node definition
          const match = line.match(/(\w+)\[(.*)\]/);
          if (match) {
            const [, id, label] = match;
            textRep += `Node ${id}: ${label.replace(/"/g, '')}\n`;
          } else {
            textRep += `${line}\n`;
          }
        } else if (line) {
          textRep += `${line}\n`;
        }
      }
      
      setTextRepresentation(textRep);
      setError(null);
    } catch (err) {
      console.error('Error generating text representation:', err);
      setTextRepresentation('Could not generate text representation of the diagram.');
      setError('Failed to process diagram');
    } finally {
      setIsLoading(false);
    }
  }, [chart]);

  if (isLoading) {
    return (
      <div className={`flex items-center justify-center p-8 bg-gray-50 rounded-lg ${className}`}>
        <div className="animate-pulse text-gray-400">Rendering diagram...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={`p-4 bg-red-50 border border-red-200 rounded-lg ${className}`}>
        <h3 className="text-sm font-medium text-red-800 mb-2">Diagram Rendering Error</h3>
        <p className="text-sm text-red-700">{error}</p>
      </div>
    );
  }

  if (!chart) {
    return (
      <div className={`flex items-center justify-center p-8 bg-gray-50 rounded-lg ${className}`}>
        <div className="text-gray-400">No diagram to display</div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-lg shadow p-4 ${className}`}>
      <div className="flex flex-col items-center justify-center">
        {svg ? (
          <div 
            className="mb-4 w-full overflow-auto"
            dangerouslySetInnerHTML={{ __html: svg }}
          />
        ) : (
          <div className="mb-4 p-4 bg-gray-50 border border-gray-200 rounded-md w-full">
            <p className="text-sm text-gray-600 text-center">SVG rendering not available</p>
          </div>
        )}
        
        {textRepresentation && (
          <div className="w-full">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Text Representation</h3>
            <pre className="text-xs bg-gray-50 p-4 rounded-md overflow-auto max-h-[200px] w-full border border-gray-200">
              {textRepresentation}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}