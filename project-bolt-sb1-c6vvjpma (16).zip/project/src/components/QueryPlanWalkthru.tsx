import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Info, AlertCircle } from 'lucide-react';
import { getDistributionStyleExplanation } from '../utils/distributionStylesGuide';

interface QueryPlanWalkthruProps {
  queryPlan: string;
}

interface PlanStep {
  operation: string;
  details: string;
  indentation: number;
  distributionStyle?: string;
  rowCount?: number;
  formattedRowCount?: string;
  cost?: string;
  costLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'HIGHEST';
  explanation?: string;
  tableName?: string;
  columnName?: string;
  filterCondition?: string;
  sortKey?: string;
  hashCondition?: string;
}

interface PredicateIssue {
  type: string;
  message: string;
  tables: Array<{
    name: string;
    condition: string;
  }>;
}

export function QueryPlanWalkthru({ queryPlan }: QueryPlanWalkthruProps) {
  const [steps, setSteps] = useState<PlanStep[]>([]);
  const [expanded, setExpanded] = useState(true);
  const [distributionStyles, setDistributionStyles] = useState<string[]>([]);
  const [predicateIssues, setPredicateIssues] = useState<PredicateIssue[]>([]);

  useEffect(() => {
    if (!queryPlan) return;

    // Parse the query plan into steps
    const lines = queryPlan.split('\n').filter(line => line.trim());
    const parsedSteps: PlanStep[] = [];
    const foundDistStyles: Set<string> = new Set();
    
    // Find all costs to determine relative levels
    const allCosts: number[] = [];
    lines.forEach(line => {
      const costMatch = line.trim().match(/cost=([^.]+)\.\.([^)]+)/);
      if (costMatch) {
        const endCost = parseFloat(costMatch[2]);
        if (!isNaN(endCost)) {
          allCosts.push(endCost);
        }
      }
    });
    
    // Sort costs to determine quartiles
    allCosts.sort((a, b) => a - b);
    const costThresholds = {
      low: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.25)] : 0,
      medium: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.5)] : 0,
      high: allCosts.length > 0 ? allCosts[Math.floor(allCosts.length * 0.75)] : 0
    };

    lines.forEach(line => {
      const indentation = line.search(/\S|$/);
      const trimmedLine = line.trim();
      
      // Extract distribution style if present
      const distStyleMatch = trimmedLine.match(/DS_[A-Z_]+/);
      const distStyle = distStyleMatch ? distStyleMatch[0] : undefined;
      
      if (distStyle) {
        foundDistStyles.add(distStyle);
      }
      
      // Extract row count if present
      const rowCountMatch = trimmedLine.match(/rows=(\d+)/);
      const rowCount = rowCountMatch ? parseInt(rowCountMatch[1]) : undefined;
      
      // Format row count as K, M, B
      let formattedRowCount: string | undefined;
      if (rowCount !== undefined) {
        if (rowCount >= 1000000000) {
          formattedRowCount = (rowCount / 1000000000).toFixed(1) + 'B';
        } else if (rowCount >= 1000000) {
          formattedRowCount = (rowCount / 1000000).toFixed(1) + 'M';
        } else if (rowCount >= 1000) {
          formattedRowCount = (rowCount / 1000).toFixed(1) + 'K';
        } else {
          formattedRowCount = rowCount.toString();
        }
      }
      
      // Extract cost if present
      const costMatch = trimmedLine.match(/cost=([^.]+)\.\.([^)]+)/);
      const cost = costMatch ? `${costMatch[1]}..${costMatch[2]}` : undefined;
      
      // Determine cost level
      let costLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'HIGHEST' | undefined;
      if (costMatch) {
        const endCost = parseFloat(costMatch[2]);
        if (!isNaN(endCost)) {
          if (endCost <= costThresholds.low) {
            costLevel = 'LOW';
          } else if (endCost <= costThresholds.medium) {
            costLevel = 'MEDIUM';
          } else if (endCost <= costThresholds.high) {
            costLevel = 'HIGH';
          } else {
            costLevel = 'HIGHEST';
          }
        }
      }
      
      // Extract table name if present
      const tableMatch = trimmedLine.match(/on\s+([a-zA-Z0-9_]+)(?:\s+([a-zA-Z0-9_]+))?/);
      const tableName = tableMatch ? tableMatch[1] : undefined;
      const tableAlias = tableMatch && tableMatch[2] ? tableMatch[2] : undefined;
      
      // Extract filter condition if present
      const filterMatch = trimmedLine.match(/Filter:\s+(.+?)(?:\)|$)/);
      const filterCondition = filterMatch ? filterMatch[1].trim() : undefined;
      
      // Extract sort key if present
      const sortKeyMatch = trimmedLine.match(/Sort Key:\s+(.+?)(?:\)|$)/);
      const sortKey = sortKeyMatch ? sortKeyMatch[1].trim() : undefined;
      
      // Extract hash condition if present
      const hashCondMatch = trimmedLine.match(/Hash Cond:\s+(.+?)(?:\)|$)/);
      const hashCondition = hashCondMatch ? hashCondMatch[1].trim() : undefined;
      
      // Split into operation and details
      let operation = trimmedLine;
      let details = '';
      
      const bracketIndex = trimmedLine.indexOf('(');
      if (bracketIndex > 0) {
        operation = trimmedLine.substring(0, bracketIndex).trim();
        details = trimmedLine.substring(bracketIndex).trim();
      }
      
      // Generate explanation based on operation type
      let explanation = '';
      
      if (operation.includes('Limit')) {
        explanation = 'Limits the number of rows returned by the query. This is typically a very fast operation with minimal impact on performance.';
      } else if (operation.includes('Sort')) {
        const sortKeyInfo = sortKey ? ` sorting by ${sortKey}` : '';
        explanation = `Sorts the result set${sortKeyInfo}. Sorting can be memory-intensive for large datasets and may require disk-based operations if the data doesn't fit in memory.`;
      } else if (operation.includes('HashAggregate')) {
        explanation = 'Performs aggregation operations (like SUM, COUNT, AVG) using a hash table to group rows. This requires building a hash table in memory, which can be resource-intensive for large datasets.';
      } else if (operation.includes('Hash Join')) {
        const distStyleExplanation = distStyle ? getDistributionStyleExplanation(distStyle) : null;
        const joinCondition = hashCondition ? ` on condition ${hashCondition}` : '';
        explanation = `Joins two tables${joinCondition} using a hash-based algorithm. ${distStyleExplanation ? distStyleExplanation.description : ''} The smaller table is typically used to build a hash table in memory, which is then probed with rows from the larger table.`;
      } else if (operation.includes('Hash')) {
        explanation = 'Creates a hash table from the input rows. This is typically used as part of a Hash Join operation and requires memory proportional to the number of rows being hashed.';
      } else if (operation.includes('Seq Scan')) {
        const tableInfo = tableName ? ` on table ${tableName}${tableAlias ? ` (alias: ${tableAlias})` : ''}` : '';
        const filterInfo = filterCondition ? ` with filter ${filterCondition}` : '';
        explanation = `Performs a full table scan${tableInfo}${filterInfo}, reading all rows from the table. This is the most basic access method and can be expensive for large tables if no filtering is applied.`;
      } else if (operation.includes('Index Scan')) {
        const tableInfo = tableName ? ` on table ${tableName}${tableAlias ? ` (alias: ${tableAlias})` : ''}` : '';
        const filterInfo = filterCondition ? ` with filter ${filterCondition}` : '';
        explanation = `Uses an index to access table data${tableInfo}${filterInfo}. This is typically more efficient than a sequential scan when retrieving a small subset of rows.`;
      } else if (operation.includes('Nested Loop')) {
        const joinCondition = hashCondition ? ` on condition ${hashCondition}` : '';
        explanation = `Joins tables${joinCondition} using a nested loop algorithm. For each row from the outer table, all rows from the inner table are scanned. This can be efficient for small tables but scales poorly for large datasets.`;
      } else if (operation.includes('Merge Join')) {
        const joinCondition = hashCondition ? ` on condition ${hashCondition}` : '';
        explanation = `Joins pre-sorted tables${joinCondition} by merging them. This requires both inputs to be sorted on the join keys but can be very efficient for large datasets.`;
      } else if (operation.includes('Broadcast')) {
        explanation = 'Copies (broadcasts) a small table to all nodes in the cluster. This is efficient for joining small dimension tables with large fact tables.';
      } else if (operation.includes('Network')) {
        explanation = 'Involves network transfer of data between nodes. This can be a bottleneck if large amounts of data need to be transferred.';
      }
      
      parsedSteps.push({
        operation,
        details,
        indentation: Math.floor(indentation / 2),
        distributionStyle: distStyle,
        rowCount,
        formattedRowCount,
        cost,
        costLevel,
        explanation,
        tableName,
        filterCondition,
        sortKey,
        hashCondition
      });
    });
    
    setSteps(parsedSteps);
    setDistributionStyles(Array.from(foundDistStyles));
    
    // Analyze predicates for optimization opportunities
    const issues: PredicateIssue[] = [];
    
    // Check for equality filters on sequential scans
    const seqScansWithEquality = parsedSteps.filter(s => 
      s.operation.includes('Seq Scan') && 
      s.filterCondition && 
      s.filterCondition.includes('=')
    );
    
    if (seqScansWithEquality.length > 0) {
      issues.push({
        type: 'equality_on_seq_scan',
        message: 'Equality filters on sequential scans could benefit from indexes',
        tables: seqScansWithEquality.map(s => ({
          name: s.tableName || 'Unknown',
          condition: s.filterCondition || ''
        }))
      });
    }
    
    // Check for range scans without appropriate sort keys
    const rangeScans = parsedSteps.filter(s => 
      s.filterCondition && 
      (s.filterCondition.includes('>') || 
       s.filterCondition.includes('<') || 
       s.filterCondition.includes('BETWEEN'))
    );
    
    if (rangeScans.length > 0) {
      issues.push({
        type: 'range_scan_optimization',
        message: 'Range scans could benefit from appropriate sort keys',
        tables: rangeScans.map(s => ({
          name: s.tableName || 'Unknown',
          condition: s.filterCondition || ''
        }))
      });
    }
    
    // Check for filter order optimization
    const multipleFilters = parsedSteps.filter(s => 
      s.filterCondition && 
      s.filterCondition.includes(' AND ')
    );
    
    if (multipleFilters.length > 0) {
      issues.push({
        type: 'filter_order',
        message: 'Multiple filter conditions should have most selective filters first',
        tables: multipleFilters.map(s => ({
          name: s.tableName || 'Unknown',
          condition: s.filterCondition || ''
        }))
      });
    }
    
    setPredicateIssues(issues);
  }, [queryPlan]);

  if (!queryPlan || steps.length === 0) {
    return null;
  }

  const getCostLevelColor = (level?: 'LOW' | 'MEDIUM' | 'HIGH' | 'HIGHEST') => {
    switch (level) {
      case 'LOW': return 'bg-green-100 text-green-800';
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800';
      case 'HIGH': return 'bg-orange-100 text-orange-800';
      case 'HIGHEST': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCostLevelBorderColor = (level?: 'LOW' | 'MEDIUM' | 'HIGH' | 'HIGHEST') => {
    switch (level) {
      case 'LOW': return 'border-green-300';
      case 'MEDIUM': return 'border-yellow-300';
      case 'HIGH': return 'border-orange-300';
      case 'HIGHEST': return 'border-red-300';
      default: return 'border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4 mb-4">
      <div 
        className="flex justify-between items-center cursor-pointer mb-4"
        onClick={() => setExpanded(!expanded)}
      >
        <h2 className="text-lg font-semibold text-gray-900">Plan Walkthru</h2>
        {expanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
      </div>
      
      {expanded && (
        <div className="space-y-4">
          {/* Step-by-Step Walkthrough */}
          <div className="space-y-3">
            <h3 className="text-md font-medium text-gray-800">Execution Flow</h3>
            <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
              <ol className="space-y-6">
                {steps.map((step, index) => {
                  const distStyleExplanation = step.distributionStyle 
                    ? getDistributionStyleExplanation(step.distributionStyle)
                    : null;
                  
                  // Build a detailed operation description with table/column info
                  let detailedOperation = step.operation;
                  
                  if (step.tableName) {
                    detailedOperation += ` on ${step.tableName}`;
                  }
                  
                  // Add specific details based on operation type
                  const operationDetails = [];
                  
                  if (step.filterCondition) {
                    operationDetails.push(`Filter: ${step.filterCondition}`);
                  }
                  
                  if (step.sortKey) {
                    operationDetails.push(`Sort Key: ${step.sortKey}`);
                  }
                  
                  if (step.hashCondition) {
                    operationDetails.push(`Join Condition: ${step.hashCondition}`);
                  }
                  
                  return (
                    <li 
                      key={index} 
                      className={`relative pl-8 p-3 rounded-lg border-2 ${getCostLevelBorderColor(step.costLevel)}`} 
                      style={{ marginLeft: `${step.indentation * 20}px` }}
                    >
                      <div className="absolute left-0 top-1 w-5 h-5 bg-indigo-100 rounded-full flex items-center justify-center text-xs text-indigo-800 font-medium">
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium text-gray-800 flex items-center gap-2">
                          {detailedOperation}
                          {step.costLevel && (
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${getCostLevelColor(step.costLevel)}`}>
                              {step.costLevel}
                            </span>
                          )}
                        </div>
                        
                        {operationDetails.length > 0 && (
                          <div className="mt-1 text-xs text-gray-600">
                            {operationDetails.map((detail, i) => (
                              <div key={i} className="font-mono">{detail}</div>
                            ))}
                          </div>
                        )}
                        
                        {step.explanation && (
                          <div className="mt-2 text-sm text-gray-700">
                            {step.explanation}
                          </div>
                        )}
                        
                        {step.distributionStyle && distStyleExplanation && (
                          <div className="mt-2 text-sm text-blue-700 bg-blue-50 p-2 rounded">
                            <span className="font-medium">Distribution:</span>{' '}
                            {distStyleExplanation.description}
                          </div>
                        )}
                        
                        <div className="mt-2 text-sm text-gray-600 flex flex-wrap gap-3">
                          {step.formattedRowCount && (
                            <span className="inline-flex items-center">
                              <span className="font-medium mr-1">Rows:</span> 
                              {step.formattedRowCount}
                            </span>
                          )}
                          
                          {step.cost && (
                            <span className="inline-flex items-center">
                              <span className="font-medium mr-1">Cost:</span> 
                              {step.cost}
                            </span>
                          )}
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ol>
            </div>
          </div>
          
          {/* Performance Insights */}
          <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
            <div className="flex items-center mb-2">
              <AlertCircle className="h-5 w-5 text-amber-600 mr-2" />
              <h3 className="text-md font-medium text-amber-800">Performance Insights</h3>
            </div>
            <ul className="space-y-2 text-sm text-amber-700">
              {steps.some(s => s.distributionStyle?.includes('BCAST')) && (
                <li>
                  <span className="font-medium">Broadcast Operation:</span> One table is being broadcast to all nodes, which can be expensive for large tables.
                  {steps.filter(s => s.distributionStyle?.includes('BCAST')).map((s, i) => (
                    <div key={i} className="ml-4 mt-1 text-xs">
                      Table: {s.tableName || 'Unknown'} ({s.formattedRowCount || 'unknown'} rows)
                    </div>
                  ))}
                </li>
              )}
              
              {steps.some(s => s.distributionStyle?.includes('DIST_BOTH')) && (
                <li>
                  <span className="font-medium">Dual Redistribution:</span> Both tables are being redistributed, which can cause significant network traffic.
                </li>
              )}
              
              {steps.some(s => s.operation.includes('Seq Scan') && (s.rowCount || 0) > 1000000) && (
                <li>
                  <span className="font-medium">Large Sequential Scan:</span> Consider adding appropriate sort keys or distribution keys to improve performance.
                  {steps.filter(s => s.operation.includes('Seq Scan') && (s.rowCount || 0) > 1000000).map((s, i) => (
                    <div key={i} className="ml-4 mt-1 text-xs">
                      Table: {s.tableName || 'Unknown'} ({s.formattedRowCount} rows)
                    </div>
                  ))}
                </li>
              )}
              
              {steps.some(s => s.operation.includes('Hash') && !s.operation.includes('Join') && (s.rowCount || 0) > 5000000) && (
                <li>
                  <span className="font-medium">Large Hash Table:</span> Building a large hash table may cause memory pressure.
                  {steps.filter(s => s.operation.includes('Hash') && !s.operation.includes('Join') && (s.rowCount || 0) > 5000000).map((s, i) => (
                    <div key={i} className="ml-4 mt-1 text-xs">
                      Size: {s.formattedRowCount} rows
                    </div>
                  ))}
                </li>
              )}
              
              {steps.some(s => s.costLevel === 'HIGHEST') && (
                <li>
                  <span className="font-medium">High-Cost Operations:</span> The plan contains operations with the highest relative cost, which may be bottlenecks.
                  {steps.filter(s => s.costLevel === 'HIGHEST').map((s, i) => (
                    <div key={i} className="ml-4 mt-1 text-xs">
                      {s.operation}{s.tableName ? ` on ${s.tableName}` : ''} (Cost: {s.cost})
                    </div>
                  ))}
                </li>
              )}
              
              {steps.some(s => s.filterCondition?.includes('=')) && steps.some(s => s.operation.includes('Seq Scan')) && (
                <li>
                  <span className="font-medium">Equality Filter on Sequential Scan:</span> Consider adding an index for equality conditions to avoid full table scans.
                </li>
              )}
            </ul>
          </div>
          
          {/* Predicate Optimization */}
          {predicateIssues.length > 0 && (
            <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
              <div className="flex items-center mb-2">
                <Info className="h-5 w-5 text-indigo-600 mr-2" />
                <h3 className="text-md font-medium text-indigo-800">Optimizing Predicates</h3>
              </div>
              <ul className="space-y-3 text-sm text-indigo-700">
                {predicateIssues.map((issue, index) => (
                  <li key={index}>
                    <span className="font-medium">{issue.message}</span>
                    <ul className="mt-1 ml-4 space-y-1">
                      {issue.tables.map((table, i) => (
                        <li key={i} className="text-xs">
                          <span className="font-mono">{table.name}</span>: {table.condition}
                          {issue.type === 'equality_on_seq_scan' && (
                            <div className="ml-2 mt-0.5 text-indigo-600">
                              → Consider adding an index on {table.condition.split('=')[0].trim()}
                            </div>
                          )}
                          {issue.type === 'range_scan_optimization' && (
                            <div className="ml-2 mt-0.5 text-indigo-600">
                              → Consider adding a sort key on {table.condition.split(/[<>]/)[0].trim()}
                            </div>
                          )}
                          {issue.type === 'filter_order' && (
                            <div className="ml-2 mt-0.5 text-indigo-600">
                              → Reorder filters to put most selective conditions first
                            </div>
                          )}
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}