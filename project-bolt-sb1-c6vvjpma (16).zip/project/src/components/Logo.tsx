import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  maxHeight?: number;
}

export function Logo({ className = '', maxHeight = 40 }: LogoProps) {
  return (
    <Link 
      to="/" 
      className={`flex items-center ${className}`}
      aria-label="Home"
    >
      <img 
        src="/images/rsop.png" 
        alt="Redshift Outpost"
        className="h-auto w-auto object-contain"
        style={{ maxHeight }}
      />
    </Link>
  );
}