import React from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface ExamplePlan {
  title: string;
  description: string;
  plan: string;
}

const examplePlans: ExamplePlan[] = [
  {
    title: "Very Simple Scan",
    description: "Extremely basic scan with minimal operations",
    plan: `XN Seq Scan on users (cost=0.00..1.01 rows=1 width=36)
  Filter: (id = 1)`
  },
  {
    title: "Simple Table Scan",
    description: "Basic sequential scan with filter",
    plan: `XN Seq Scan on sales (cost=0.00..1250.60 rows=50000 width=16)
  Filter: (date_id > 20230101)`
  },
  {
    title: "Basic Join",
    description: "Simple join between two tables",
    plan: `XN Hash Join DS_DIST_NONE (cost=0.04..0.07 rows=1 width=40)
  Hash Cond: ("outer".order_id = "inner".id)
  ->  XN Seq Scan on order_items (cost=0.00..0.01 rows=1 width=20)
  ->  XN Hash (cost=0.02..0.02 rows=1 width=20)
        ->  XN Seq Scan on orders (cost=0.00..0.02 rows=1 width=20)
              Filter: (status = 'completed'::text)`
  },
  {
    title: "Hash Join with Distribution",
    description: "Hash join between two tables with network distribution",
    plan: `XN Hash Join DS_DIST_BOTH (cost=112.50..3250.63 rows=25000 width=48)
  Hash Cond: ("outer".customer_id = "inner".id)
  ->  XN Seq Scan on sales (cost=0.00..1250.60 rows=50000 width=16)
  ->  XN Hash (cost=100.00..100.00 rows=5000 width=32)
        ->  XN Seq Scan on customers (cost=0.00..100.00 rows=5000 width=32)`
  },
  {
    title: "Nested Loop Join",
    description: "Nested loop join with index scan",
    plan: `XN Nested Loop (cost=0.00..15.00 rows=10 width=16)
  Join Filter: ("outer".customer_id = "inner".id)
  ->  XN Seq Scan on orders (cost=0.00..10.00 rows=100 width=8)
  ->  XN Index Scan on customers (cost=0.00..0.05 rows=1 width=8)
        Index Cond: (id = "outer".customer_id)`
  },
  {
    title: "Complex Aggregation",
    description: "Query with multiple aggregations and sorting",
    plan: `XN Merge (cost=1000000015243.75..1000000015243.80 rows=20 width=32)
  Merge Key: sum(sales.amount)
  ->  XN Network (cost=1000000015243.75..1000000015243.80 rows=20 width=32)
        Send to leader
        ->  XN Sort (cost=1000000015243.75..1000000015243.80 rows=20 width=32)
              Sort Key: sum(sales.amount)
              ->  XN HashAggregate (cost=15243.50..15243.55 rows=20 width=32)
                    ->  XN Hash Join DS_BCAST_INNER (cost=112.50..15243.00 rows=100 width=32)
                          Hash Cond: ("outer".customer_id = "inner".id)
                          ->  XN Seq Scan on sales (cost=0.00..1250.60 rows=50000 width=16)
                          ->  XN Hash (cost=100.00..100.00 rows=5000 width=32)
                                ->  XN Seq Scan on customers (cost=0.00..100.00 rows=5000 width=32)
                                      Filter: (region = 'WEST')`
  }
];

export function ExampleQueryPlans({ onSelectPlan }: { onSelectPlan: (plan: string) => void }) {
  const [isOpen, setIsOpen] = React.useState(false);
  const [selectedExample, setSelectedExample] = React.useState<ExamplePlan | null>(null);

  const handleSelectPlan = (plan: ExamplePlan) => {
    setSelectedExample(plan);
    onSelectPlan(plan.plan);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div 
        className="flex justify-between items-center p-3 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <h3 className="text-sm font-medium text-gray-700">
          {selectedExample ? selectedExample.title : 'Example Query Plans'}
        </h3>
        {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
      </div>
      
      {isOpen && (
        <div className="border-t border-gray-200 p-3">
          <div className="space-y-2">
            {examplePlans.map((plan, index) => (
              <div 
                key={index}
                className={`p-2 rounded cursor-pointer hover:bg-gray-50 ${
                  selectedExample === plan ? 'bg-indigo-50 border border-indigo-100' : ''
                }`}
                onClick={() => handleSelectPlan(plan)}
              >
                <h4 className="text-sm font-medium text-gray-800">{plan.title}</h4>
                <p className="text-xs text-gray-600">{plan.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}