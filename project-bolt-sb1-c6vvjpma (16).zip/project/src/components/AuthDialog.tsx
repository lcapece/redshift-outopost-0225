import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { SignInForm } from './SignInForm';
import { SignUpForm } from './SignUpForm';
import { ForgotPasswordForm } from './ForgotPasswordForm';

interface AuthDialogProps {
  isOpen: boolean;
  onClose: () => void;
  initialView?: 'signin' | 'signup' | 'forgot-password';
}

export function AuthDialog({ isOpen, onClose, initialView = 'signin' }: AuthDialogProps) {
  const [view, setView] = useState(initialView);

  useEffect(() => {
    // Reset view when dialog opens
    if (isOpen) {
      setView(initialView);
    }
  }, [isOpen, initialView]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold">
            {view === 'signin' && 'Sign In'}
            {view === 'signup' && 'Create an Account'}
            {view === 'forgot-password' && 'Reset Password'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {view === 'signin' && (
          <>
            <SignInForm 
              onSuccess={onClose}
              onForgotPassword={() => setView('forgot-password')}
            />
            
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => setView('signup')}
                  className="font-medium text-indigo-600 hover:text-indigo-500"
                >
                  Sign up
                </button>
              </p>
            </div>
          </>
        )}
        
        {view === 'signup' && (
          <>
            <SignUpForm onSuccess={() => {}} />
            
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setView('signin')}
                  className="font-medium text-indigo-600 hover:text-indigo-500"
                >
                  Sign in
                </button>
              </p>
            </div>
          </>
        )}
        
        {view === 'forgot-password' && (
          <ForgotPasswordForm onBack={() => setView('signin')} />
        )}
      </div>
    </div>
  );
}