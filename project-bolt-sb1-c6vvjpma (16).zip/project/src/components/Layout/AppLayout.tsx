import React from 'react';
import { Outlet } from 'react-router-dom';
import { MainNav } from '../Navigation/MainNav';
import { MobileNav } from '../Navigation/MobileNav';
import { Breadcrumbs } from '../Navigation/Breadcrumbs';
import { UserMenu } from '../UserMenu';
import { AuthDialog } from '../AuthDialog';
import { Logo } from '../Logo';
import { useAuth } from '../../hooks/useAuth';

export function AppLayout() {
  const { user } = useAuth();
  const [isAuthDialogOpen, setIsAuthDialogOpen] = React.useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-8">
              <Logo maxHeight={40} />
              <MainNav />
            </div>
            <div className="flex items-center gap-4">
              <UserMenu 
                user={user} 
                onSignInClick={() => setIsAuthDialogOpen(true)} 
              />
              <MobileNav />
            </div>
          </div>
          <div className="py-2">
            <Breadcrumbs />
          </div>
        </div>
      </header>

      <main>
        <Outlet />
      </main>

      <AuthDialog 
        isOpen={isAuthDialogOpen} 
        onClose={() => setIsAuthDialogOpen(false)} 
      />
    </div>
  );
}