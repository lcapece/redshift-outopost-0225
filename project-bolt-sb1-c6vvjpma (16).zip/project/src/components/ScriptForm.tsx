import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Tag, Plus, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  RedshiftScript, 
  createScript, 
  updateScript, 
  fetchCategories, 
  fetchScriptTypes,
  formatSqlScript
} from '../services/scriptsService';

interface ScriptFormProps {
  script?: RedshiftScript;
  isEditMode: boolean;
  onBack: () => void;
}

export function ScriptForm({ script, isEditMode, onBack }: ScriptFormProps) {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<Partial<RedshiftScript>>({
    title: '',
    description: '',
    script_content: '',
    original_url: '',
    category: '',
    script_type: '',
    published_at: new Date().toISOString().split('T')[0],
    tags: [],
    author: '',
    status: 'draft'
  });
  
  const [categories, setCategories] = useState<{id: string; name: string}[]>([]);
  const [scriptTypes, setScriptTypes] = useState<{id: string; name: string}[]>([]);
  const [newTag, setNewTag] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [previewFormatted, setPreviewFormatted] = useState<string | null>(null);

  useEffect(() => {
    // Load categories and script types
    const loadData = async () => {
      const fetchedCategories = await fetchCategories();
      const fetchedScriptTypes = await fetchScriptTypes();
      
      setCategories(fetchedCategories);
      setScriptTypes(fetchedScriptTypes);
    };
    
    loadData();
    
    // If in edit mode, populate form with script data
    if (isEditMode && script) {
      setFormData({
        title: script.title,
        description: script.description,
        script_content: script.script_content,
        original_url: script.original_url || '',
        category: script.category,
        script_type: script.script_type,
        published_at: script.published_at,
        tags: script.tags || [],
        author: script.author || '',
        status: script.status
      });
    }
  }, [isEditMode, script]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear preview when script content changes
    if (name === 'script_content') {
      setPreviewFormatted(null);
    }
  };

  const handleAddTag = () => {
    if (!newTag.trim()) return;
    
    setFormData(prev => ({
      ...prev,
      tags: [...(prev.tags || []), newTag.trim()]
    }));
    
    setNewTag('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: (prev.tags || []).filter(tag => tag !== tagToRemove)
    }));
  };

  const handlePreviewFormat = () => {
    if (!formData.script_content) return;
    
    const formatted = formatSqlScript(formData.script_content);
    setPreviewFormatted(formatted);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setError(null);
    
    try {
      // Format the script content
      const formatted_content = formatSqlScript(formData.script_content || '');
      
      if (isEditMode && script) {
        // Update existing script
        const updatedScript = await updateScript(script.id, {
          ...formData,
          formatted_content
        });
        
        if (updatedScript) {
          navigate('/admin/scripts');
        } else {
          setError('Failed to update script');
        }
      } else {
        // Create new script
        const newScript = await createScript({
          ...formData as Required<Omit<RedshiftScript, 'id' | 'created_at' | 'updated_at' | 'views' | 'downloads'>>,
          formatted_content
        });
        
        if (newScript) {
          navigate('/admin/scripts');
        } else {
          setError('Failed to create script');
        }
      }
    } catch (err) {
      setError('An error occurred while saving the script');
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={onBack}
            className="inline-flex items-center text-indigo-600 hover:text-indigo-800"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </button>
          
          <h1 className="text-2xl font-bold text-gray-900">
            {isEditMode ? 'Edit Script' : 'Add New Script'}
          </h1>
          
          <button
            type="button"
            onClick={handleSubmit}
            disabled={isSaving}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
          >
            <Save className="h-4 w-4 mr-2" />
            {isSaving ? 'Saving...' : 'Save Script'}
          </button>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title
              </label>
              <input
                type="text"
                name="title"
                id="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="author" className="block text-sm font-medium text-gray-700">
                Author (Optional)
              </label>
              <input
                type="text"
                name="author"
                id="author"
                value={formData.author || ''}
                onChange={handleInputChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              name="description"
              id="description"
              rows={3}
              value={formData.description}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>
          
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="category" className="block text-sm font-medium text-gray-700">
                Category
              </label>
              <select
                name="category"
                id="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                <option value="">Select a category</option>
                {categories.map(category => (
                  <option key={category.id} value={category.name}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="script_type" className="block text-sm font-medium text-gray-700">
                Script Type
              </label>
              <select
                name="script_type"
                id="script_type"
                value={formData.script_type}
                onChange={handleInputChange}
                required
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                <option value="">Select a script type</option>
                {scriptTypes.map(type => (
                  <option key={type.id} value={type.name}>
                    {type.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label htmlFor="original_url" className="block text-sm font-medium text-gray-700">
                Original URL (Optional)
              </label>
              <input
                type="url"
                name="original_url"
                id="original_url"
                value={formData.original_url || ''}
                onChange={handleInputChange}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
            
            <div>
              <label htmlFor="published_at" className="block text-sm font-medium text-gray-700">
                Published Date
              </label>
              <input
                type="date"
                name="published_at"
                id="published_at"
                value={formData.published_at?.split('T')[0]}
                onChange={handleInputChange}
                required
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700">
              Status
            </label>
            <select
              name="status"
              id="status"
              value={formData.status}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            >
              <option value="draft">Draft</option>
              <option value="published">Published</option>
              <option value="archived">Archived</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Tags
            </label>
            <div className="flex flex-wrap gap-2 mb-2">
              {(formData.tags || []).map((tag) => (
                <div key={tag} className="inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                  {tag}
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-1.5 text-indigo-600 hover:text-indigo-900"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              {(formData.tags || []).length === 0 && (
                <div className="text-sm text-gray-500">No tags added yet.</div>
              )}
            </div>
            
            <div className="flex rounded-md shadow-sm">
              <input
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Add a new tag"
                className="flex-1 min-w-0 block w-full border border-gray-300 rounded-l-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
              <button
                type="button"
                onClick={handleAddTag}
                disabled={!newTag.trim()}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-r-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Tag
              </button>
            </div>
          </div>
          
          <div>
            <div className="flex justify-between items-center">
              <label htmlFor="script_content" className="block text-sm font-medium text-gray-700">
                Script Content
              </label>
              <button
                type="button"
                onClick={handlePreviewFormat}
                disabled={!formData.script_content}
                className="text-sm text-indigo-600 hover:text-indigo-800"
              >
                Preview Formatting
              </button>
            </div>
            <textarea
              name="script_content"
              id="script_content"
              rows={15}
              value={formData.script_content}
              onChange={handleInputChange}
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono"
            />
          </div>
          
          {previewFormatted && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Formatted Preview
              </label>
              <div className="border border-gray-300 rounded-md p-4 bg-gray-50">
                <div dangerouslySetInnerHTML={{ __html: previewFormatted }} />
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}