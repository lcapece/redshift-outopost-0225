import React, { useState, useEffect } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import { 
  Globe, Plus, RefreshCw, Download, Search, Filter, 
  ChevronDown, ChevronUp, Edit, Trash2, Play, Pause,
  AlertCircle, CheckCircle, XCircle, Clock, Brain
} from 'lucide-react';
import { 
  fetchScrapeUrls, 
  createScrapeUrl,
  updateScrapeUrl,
  deleteScrapeUrl,
  bulkUpdateStatus,
  exportScrapeUrls
} from '../services/scrapingService';
import { 
  ScrapeUrlWithStats,
  ScrapeUrlFilters,
  ScrapeUrlSort,
  ScrapeUrlPagination
} from '../types/scraping';
import { AddUrlModal } from '../components/AddUrlModal';
import { EditUrlModal } from '../components/EditUrlModal';
import { LlmModelSelector } from '../components/LlmModelSelector';

export function ScrapeUrlsPage() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth0();
  const [urls, setUrls] = useState<ScrapeUrlWithStats[]>([]);
  const [selectedUrls, setSelectedUrls] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<ScrapeUrlFilters>({});
  const [sort, setSort] = useState<ScrapeUrlSort>({
    field: 'dateAdded',
    direction: 'desc'
  });
  const [pagination, setPagination] = useState<ScrapeUrlPagination>({
    page: 0,
    pageSize: 10,
    total: 0
  });
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingUrl, setEditingUrl] = useState<ScrapeUrlWithStats | null>(null);
  const [selectedModel, setSelectedModel] = useState('anthropic/claude-3-sonnet');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    if (!authLoading && isAuthenticated) {
      loadUrls();
    }
  }, [authLoading, isAuthenticated, filters, sort, pagination.page, pagination.pageSize]);

  const loadUrls = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await fetchScrapeUrls(filters, sort, pagination);
      setUrls(result.data);
      setPagination(result.pagination);
    } catch (err) {
      setError('Failed to load URLs. Please try again.');
      console.error('Error loading URLs:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = async () => {
    try {
      const data = await exportScrapeUrls();
      
      // Convert to CSV
      const headers = ['URL', 'Status', 'Last Scrape', 'Next Scrape', 'Success Rate', 'Items Found'];
      const csvContent = [
        headers.join(','),
        ...data.map(url => [
          url.url,
          url.status,
          url.lastScrapeDate,
          url.nextScheduledScrape,
          `${((url.successfulScrapes / url.totalScrapes) * 100).toFixed(1)}%`,
          url.totalItemsFound
        ].join(','))
      ].join('\n');
      
      // Download file
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `scrape-urls-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError('Failed to export URLs');
      console.error('Error exporting URLs:', err);
    }
  };

  const handleDelete = async (url: string) => {
    if (!user?.sub) return;
    
    if (window.confirm('Are you sure you want to delete this URL? This action cannot be undone.')) {
      try {
        const success = await deleteScrapeUrl(url, user.sub);
        if (success) {
          loadUrls();
        } else {
          setError('Failed to delete URL');
        }
      } catch (err) {
        setError('Error deleting URL');
        console.error('Error:', err);
      }
    }
  };

  const handleBulkAction = async (action: 'activate' | 'deactivate' | 'delete') => {
    if (!user?.sub || selectedUrls.length === 0) return;
    
    try {
      switch (action) {
        case 'activate':
          await bulkUpdateStatus(selectedUrls, 'pending', user.sub);
          break;
        case 'deactivate':
          await bulkUpdateStatus(selectedUrls, 'failed', user.sub);
          break;
        case 'delete':
          if (window.confirm(`Are you sure you want to delete ${selectedUrls.length} URLs?`)) {
            for (const url of selectedUrls) {
              await deleteScrapeUrl(url, user.sub);
            }
          }
          break;
      }
      
      setSelectedUrls([]);
      loadUrls();
    } catch (err) {
      setError('Failed to perform bulk action');
      console.error('Error:', err);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
          <h2 className="mt-2 text-lg font-medium text-gray-900">Authentication Required</h2>
          <p className="mt-1 text-sm text-gray-500">Please sign in to access this page.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
            <div className="flex items-center">
              <Globe className="h-8 w-8 text-indigo-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Web Scraping Management</h1>
            </div>
            
            <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 md:space-x-4">
              <LlmModelSelector
                selectedModel={selectedModel}
                onModelChange={setSelectedModel}
                disabled={isAnalyzing}
              />
              
              <button
                onClick={handleExport}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Export
              </button>
              
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add URL
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-medium text-gray-900">Filters</h2>
          </div>
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={filters.status || ''}
                  onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value as any || undefined }))}
                >
                  <option value="">All</option>
                  <option value="pending">Pending</option>
                  <option value="success">Success</option>
                  <option value="failed">Failed</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Active</label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                  value={filters.active === undefined ? '' : filters.active.toString()}
                  onChange={(e) => setFilters(prev => ({ 
                    ...prev, 
                    active: e.target.value === '' ? undefined : e.target.value === 'true'
                  }))}
                >
                  <option value="">All</option>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Search</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <input
                    type="text"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    placeholder="Search URLs or comments..."
                    value={filters.search || ''}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value || undefined }))}
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700">Date Range</label>
                <div className="mt-1 grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    value={filters.dateRange?.start.toISOString().split('T')[0] || ''}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      dateRange: {
                        ...prev.dateRange,
                        start: e.target.value ? new Date(e.target.value) : new Date()
                      }
                    }))}
                  />
                  <input
                    type="date"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                    value={filters.dateRange?.end.toISOString().split('T')[0] || ''}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      dateRange: {
                        ...prev.dateRange,
                        end: e.target.value ? new Date(e.target.value) : new Date()
                      }
                    }))}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* URLs Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-4 border-b border-gray-200">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-medium text-gray-900">URLs</h2>
              
              {selectedUrls.length > 0 && (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-500">
                    {selectedUrls.length} selected
                  </span>
                  <button
                    onClick={() => handleBulkAction('activate')}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md text-sm font-medium text-white bg-green-600 hover:bg-green-700"
                  >
                    <Play className="h-4 w-4 mr-1.5" />
                    Activate
                  </button>
                  <button
                    onClick={() => handleBulkAction('deactivate')}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700"
                  >
                    <Pause className="h-4 w-4 mr-1.5" />
                    Deactivate
                  </button>
                  <button
                    onClick={() => handleBulkAction('delete')}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md text-sm font-medium text-white bg-red-600 hover:bg-red-700"
                  >
                    <Trash2 className="h-4 w-4 mr-1.5" />
                    Delete
                  </button>
                </div>
              )}
            </div>
          </div>
          
          {error && (
            <div className="p-4 bg-red-50 border-b border-red-200">
              <div className="flex items-center">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
                <span className="text-sm text-red-700">{error}</span>
              </div>
            </div>
          )}
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                      checked={selectedUrls.length === urls.length}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedUrls(urls.map(u => u.url));
                        } else {
                          setSelectedUrls([]);
                        }
                      }}
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <button 
                      onClick={() => setSort({ field: 'url', direction: sort.direction === 'asc' ? 'desc' : 'asc' })}
                      className="flex items-center space-x-1"
                    >
                      <span>URL</span>
                      {sort.field === 'url' && (
                        sort.direction === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                      )}
                    </button>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <button 
                      onClick={() => setSort({ field: 'lastScrapeDate', direction: sort.direction === 'asc' ? 'desc' : 'asc' })}
                      className="flex items-center space-x-1"
                    >
                      <span>Last Scrape</span>
                      {sort.field === 'lastScrapeDate' && (
                        sort.direction === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                      )}
                    </button>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <button 
                      onClick={() => setSort({ field: 'nextScheduledScrape', direction: sort.direction === 'asc' ? 'desc' : 'asc' })}
                      className="flex items-center space-x-1"
                    >
                      <span>Next Scrape</span>
                      {sort.field === 'nextScheduledScrape' && (
                        sort.direction === 'asc' ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />
                      )}
                    </button>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Success Rate
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Items Found
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {urls.map((url) => (
                  <tr key={url.url} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                        checked={selectedUrls.includes(url.url)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedUrls([...selectedUrls, url.url]);
                          } else {
                            setSelectedUrls(selectedUrls.filter(u => u !== url.url));
                          }
                        }}
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{url.url}</div>
                      {url.comments && (
                        <div className="text-sm text-gray-500">{url.comments}</div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        url.status === 'success' ? 'bg-green-100 text-green-800' :
                        url.status === 'failed' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {url.status === 'success' && <CheckCircle className="h-3 w-3 mr-1" />}
                        {url.status === 'failed' && <XCircle className="h-3 w-3 mr-1" />}
                        {url.status === 'pending' && <Clock className="h-3 w-3 mr-1" />}
                        {url.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {url.lastScrapeDate ? new Date(url.lastScrapeDate).toLocaleString() : 'Never'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {url.nextScheduledScrape ? new Date(url.nextScheduledScrape).toLocaleString() : 'Not scheduled'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {((url.successfulScrapes / (url.totalScrapes || 1)) * 100).toFixed(1)}%
                      </div>
                      <div className="text-xs text-gray-500">
                        {url.successfulScrapes} of {url.totalScrapes} scrapes
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {url.maxItemsFound.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        avg: {Math.round(url.avgItemsFound).toLocaleString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex justify-end space-x-2">
                        <button
                          onClick={() => {
                            setEditingUrl(url);
                            setIsEditModalOpen(true);
                          }}
                          className="text-indigo-600 hover:text-indigo-900"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleDelete(url.url)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
            <div className="flex-1 flex justify-between sm:hidden">
              <button
                onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
                disabled={pagination.page === 0}
                className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Previous
              </button>
              <button
                onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
                disabled={pagination.page >= Math.ceil(pagination.total / pagination.pageSize) - 1}
                className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Next
              </button>
            </div>
            <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
              <div>
                <p className="text-sm text-gray-700">
                  Showing{' '}
                  <span className="font-medium">{pagination.page * pagination.pageSize + 1}</span>
                  {' '}to{' '}
                  <span className="font-medium">
                    {Math.min((pagination.page + 1) * pagination.pageSize, pagination.total)}
                  </span>
                  {' '}of{' '}
                  <span className="font-medium">{pagination.total}</span>
                  {' '}results
                </p>
              </div>
              <div>
                <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                  <button
                    onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
                    disabled={pagination.page === 0}
                    className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                  >
                    Previous
                  </button>
                  {[...Array(Math.ceil(pagination.total / pagination.pageSize))].map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setPagination(prev => ({ ...prev, page: i }))}
                      className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                        pagination.page === i
                          ? 'z-10 bg-indigo-50 border-indigo-500 text-indigo-600'
                          : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                      }`}
                    >
                      {i + 1}
                    </button>
                  ))}
                  <button
                    onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
                    disabled={pagination.page >= Math.ceil(pagination.total / pagination.pageSize) - 1}
                    className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50"
                  >
                    Next
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}