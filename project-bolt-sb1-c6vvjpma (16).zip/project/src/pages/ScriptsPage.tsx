import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ScriptsList } from '../components/ScriptsList';
import { ScriptDetail } from '../components/ScriptDetail';
import { fetchScripts, fetchScriptById, fetchCategories, fetchScriptTypes } from '../services/scriptsService';
import { Database, Search, Filter, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

export function ScriptsPage() {
  const [scripts, setScripts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedScript, setSelectedScript] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [categories, setCategories] = useState([]);
  const [scriptTypes, setScriptTypes] = useState([]);
  
  const { scriptId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    loadScripts();
    loadFilters();
  }, []);

  useEffect(() => {
    if (scriptId && scripts.length > 0) {
      loadScriptDetail(scriptId);
    } else {
      setSelectedScript(null);
    }
  }, [scriptId, scripts]);

  const loadScripts = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const fetchedScripts = await fetchScripts(0, 'published', categoryFilter, typeFilter, searchTerm);
      setScripts(fetchedScripts || []);
    } catch (err) {
      setError('Failed to load scripts. Please try again later.');
      console.error('Error loading scripts:', err);
      setScripts([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadFilters = async () => {
    try {
      const [fetchedCategories, fetchedTypes] = await Promise.all([
        fetchCategories(),
        fetchScriptTypes()
      ]);
      
      setCategories(fetchedCategories || []);
      setScriptTypes(fetchedTypes || []);
    } catch (err) {
      console.error('Error loading filters:', err);
      setCategories([]);
      setScriptTypes([]);
    }
  };

  const loadScriptDetail = async (id) => {
    try {
      const script = await fetchScriptById(id);
      setSelectedScript(script);
      if (!script) {
        navigate('/scripts');
      }
    } catch (err) {
      console.error('Error loading script detail:', err);
      navigate('/scripts');
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    loadScripts();
  };

  const handleBackToList = () => {
    navigate('/scripts');
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'category') {
      setCategoryFilter(value);
    } else if (name === 'type') {
      setTypeFilter(value);
    }
    
    setTimeout(loadScripts, 0);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-indigo-700 to-purple-700 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <Database className="h-10 w-10 text-white mr-3" />
              <div>
                <h1 className="text-3xl font-bold">Redshift Scripts Library</h1>
                <p className="text-indigo-100 mt-1">
                  A collection of useful SQL scripts and utilities for Amazon Redshift
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link 
                to="/"
                className="inline-flex items-center px-4 py-2 border border-white text-sm font-medium rounded-md text-white hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Home
              </Link>
              
              {user && (
                <Link
                  to="/admin/scripts/new"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-indigo-700 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Script
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {selectedScript ? (
          <ScriptDetail 
            script={selectedScript} 
            onBack={handleBackToList} 
            isAdmin={user !== null}
          />
        ) : (
          <>
            <div className="bg-white rounded-lg shadow mb-6">
              <div className="p-4 border-b border-gray-200">
                <h2 className="text-lg font-medium text-gray-900">Search & Filters</h2>
              </div>
              <div className="p-4">
                <form onSubmit={handleSearch} className="flex flex-col md:flex-row md:items-end space-y-4 md:space-y-0 md:space-x-4">
                  <div className="flex-1">
                    <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">Search</label>
                    <div className="relative">
                      <input
                        type="text"
                        id="search"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search by title, description, or content..."
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm pl-10"
                      />
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search className="h-4 w-4 text-gray-400" />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select
                      id="category"
                      name="category"
                      value={categoryFilter}
                      onChange={handleFilterChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    >
                      <option value="">All Categories</option>
                      {categories && categories.map(category => (
                        <option key={category.id} value={category.name}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">Script Type</label>
                    <select
                      id="type"
                      name="type"
                      value={typeFilter}
                      onChange={handleFilterChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    >
                      <option value="">All Types</option>
                      {scriptTypes && scriptTypes.map(type => (
                        <option key={type.id} value={type.name}>
                          {type.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div>
                    <button
                      type="submit"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      <Filter className="h-4 w-4 mr-2" />
                      Apply Filters
                    </button>
                  </div>
                </form>
              </div>
            </div>
            
            <ScriptsList 
              scripts={scripts} 
              isLoading={isLoading} 
              error={error} 
            />
          </>
        )}
      </div>
    </div>
  );
}