import React, { useState, useEffect } from 'react';
import { Play, AlertCircle, Info, RefreshCw, Copy, CheckCircle, Code, Brain } from 'lucide-react';
import axios from 'axios';
import { generateHaiku } from '../services/openRouter';
import { QueryPlanWalkthru } from '../components/QueryPlanWalkthru';
import { QueryPlanToMermaid } from '../components/QueryPlanToMermaid';

interface OpenRouterResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

interface Analysis {
  explanation: string;
  concerns: string[];
  costs: {
    [key: string]: 'Lowest' | 'Average' | 'High' | 'Highest';
  };
}

// Function to extract JSON from a string that might have extra text
function extractJSON(text: string): string {
  try {
    // Try to parse as-is first
    JSON.parse(text);
    return text;
  } catch (e) {
    // Try to find JSON object with regex
    const jsonRegex = /(\{[\s\S]*\})/g;
    const matches = [...text.matchAll(jsonRegex)];
    
    // Try each match until we find valid JSON
    for (const match of matches) {
      try {
        const potentialJson = match[0];
        JSON.parse(potentialJson);
        return potentialJson;
      } catch (e) {
        // Continue to next match
      }
    }
    
    // If we get here, try a more aggressive approach - look for the largest {...} block
    const startBrace = text.indexOf('{');
    const endBrace = text.lastIndexOf('}');
    
    if (startBrace !== -1 && endBrace !== -1 && endBrace > startBrace) {
      const potentialJson = text.substring(startBrace, endBrace + 1);
      try {
        JSON.parse(potentialJson);
        return potentialJson;
      } catch (e) {
        // Last resort failed
      }
    }
    
    throw new Error("Could not extract valid JSON from response");
  }
}

export function QueryVisualizer() {
  const [queryPlan, setQueryPlan] = useState('');
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [haiku, setHaiku] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState('anthropic/claude-3-sonnet');
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const [textRepresentation, setTextRepresentation] = useState<string | null>(null);

  const models = [
    { id: 'anthropic/claude-3-sonnet', name: 'Claude 3 Sonnet' },
    { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku' },
    { id: 'meta-llama/llama-3.1-405b', name: 'Llama 3.1 405B' },
    { id: 'perplexity/r1-1776', name: 'Perplexity R1-1776' },
    { id: 'deepseek/deepseek-chat-v2.5', name: 'DeepSeek Chat v2.5' },
    { id: 'deepseek/deepseek-r1-distill-qwen-32b', name: 'DeepSeek R1 Distill' },
    { id: 'openai/chatgpt-4o-latest', name: 'GPT-4 Turbo' }
  ];

  // Effect to generate text representation when query plan changes
  useEffect(() => {
    if (!queryPlan.trim()) {
      setTextRepresentation(null);
      return;
    }

    // Generate a basic text representation
    try {
      const lines = queryPlan.split('\n').filter(line => line.trim());
      if (lines.length === 0) return;

      let textRep = "Query Plan Structure:\n";
      
      lines.forEach((line) => {
        const indentation = line.search(/\S|$/);
        const depth = Math.floor(indentation / 2);
        const prefix = "  ".repeat(depth) + (depth > 0 ? "└─ " : "");
        textRep += prefix + line.trim() + "\n";
      });
      
      setTextRepresentation(textRep);
    } catch (err) {
      console.error('Error generating text representation:', err);
      setTextRepresentation(null);
    }
  }, [queryPlan]);

  const testConnection = async () => {
    setConnectionStatus('testing');
    setError(null);
    setHaiku(null);

    try {
      const token = import.meta.env.VITE_OPENROUTER_TOKEN;
      if (!token) {
        throw new Error('OpenRouter API token is not configured. Please check your environment variables.');
      }

      const generatedHaiku = await generateHaiku(selectedModel);
      setHaiku(generatedHaiku);
      setConnectionStatus('success');
      setIsOfflineMode(false);
    } catch (error) {
      setConnectionStatus('error');
      setIsOfflineMode(true);
      let errorMessage = 'An error occurred during the connection test';
      
      if (axios.isAxiosError(error)) {
        console.error('API Error:', {
          status: error.response?.status,
          data: error.response?.data
        });
        
        if (error.response?.status === 401) {
          errorMessage = 'Authentication failed. Please ensure your OpenRouter API token is correctly set in the environment variables.';
        } else if (error.response?.status === 429) {
          errorMessage = 'Rate limit exceeded. Please try again later.';
        } else if (error.response?.data?.error?.message) {
          errorMessage = `API Error: ${error.response.data.error.message}`;
        } else if (error.response?.data?.error) {
          errorMessage = `API Error: ${error.response.data.error}`;
        }
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      setError(errorMessage);
    }
  };

  const fetchAnalysis = async () => {
    if (!queryPlan.trim()) {
      setError('Please enter a query plan');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setAnalysis(null);

    try {
      if (isOfflineMode) {
        // Generate a simple offline analysis
        const offlineAnalysis = {
          explanation: `<p>This is an offline analysis of your query plan. The API connection is currently unavailable.</p>
                       <p>The query plan shows a typical execution flow for a SQL query. In offline mode, we can't provide a detailed analysis, but here are some general observations:</p>
                       <ul>
                         <li>Query plans typically start with a scan operation (Sequential Scan, Index Scan, etc.)</li>
                         <li>Join operations combine data from multiple tables</li>
                         <li>Aggregation operations group and summarize data</li>
                         <li>Sort operations arrange data in a specific order</li>
                       </ul>
                       <p>To get a detailed analysis, please ensure your OpenRouter API connection is working.</p>`,
          concerns: [
            "Working in offline mode - limited analysis available",
            "API connection is currently unavailable"
          ],
          costs: {
            "Scan Operations": "Average",
            "Join Operations": "Average",
            "Sort Operations": "Average"
          }
        };
        
        setAnalysis(offlineAnalysis);
        return;
      }

      const token = import.meta.env.VITE_OPENROUTER_TOKEN;
      if (!token) {
        throw new Error('OpenRouter API token is not configured. Please check your environment variables.');
      }

      const response = await axios.post<OpenRouterResponse>(
        'https://openrouter.ai/api/v1/chat/completions',
        {
          model: selectedModel,
          messages: [
            {
              role: 'system',
              content: `You are an Amazon Redshift query plan analysis expert. Your task is to analyze the provided query plan and return a JSON object with specific information.

CRITICAL: Your entire response must be a single, valid JSON object with exactly these fields:
{
  "explanation": "HTML-formatted explanation with <p> tags",
  "concerns": ["Array of strings with concerns"],
  "costs": {"operation_name": "cost_category"}
}

EXTREMELY IMPORTANT JSON FORMATTING RULES:
1. Use ONLY double quotes for all JSON properties and string values
2. Escape all internal double quotes with a backslash: \\"
3. DO NOT include any mermaid diagram in this response
4. Ensure all JSON is properly escaped and valid
5. For the explanation field, provide a COMPREHENSIVE analysis with multiple paragraphs using proper HTML formatting
6. Make sure the explanation is COMPLETE and not truncated

For the "costs" field, use only these categories: "Lowest", "Average", "High", or "Highest".

DO NOT include any text, markdown formatting, or code blocks outside the JSON object.
DO NOT use backticks, triple backticks, or any other wrapping around the JSON.
Your response must be a raw, parseable JSON object and nothing else.

IMPORTANT: When explaining distribution styles like DS_DIST_BOTH, DS_DIST_INNER, DS_BCAST_INNER, DS_DIST_ALL_NONE, translate them to plain language:
- DS_DIST_BOTH: "Both tables are redistributed across nodes based on the join key"
- DS_DIST_INNER: "The inner table is redistributed to match the outer table's distribution"
- DS_BCAST_INNER: "The inner table is broadcast (copied) to all nodes"
- DS_DIST_ALL_NONE: "One table is already on all nodes, the other doesn't need redistribution"
- DS_DIST_NONE: "No redistribution needed as data is already correctly distributed"

NEVER use generic descriptions like "The plan uses various distribution styles to optimize data distribution". Always explain what each specific distribution style means in plain language.`
            },
            {
              role: 'user',
              content: queryPlan
            }
          ],
          temperature: 0.05,
          max_tokens: 2000
        },
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'HTTP-Referer': window.location.origin,
            'X-Title': 'Query Plan Analyzer',
            'Content-Type': 'application/json'
          }
        }
      );

      if (!response.data?.choices?.[0]?.message?.content) {
        throw new Error('Invalid response format from API');
      }

      const content = response.data.choices[0].message.content.trim();
      
      try {
        // Try to extract JSON from the response
        const jsonContent = extractJSON(content);
        console.log('Extracted JSON content:', jsonContent);
        
        const parsedData = JSON.parse(jsonContent);
        
        if (parsedData && parsedData.explanation && parsedData.concerns && parsedData.costs) {
          setAnalysis(parsedData);
        } else {
          throw new Error('Invalid analysis format');
        }
      } catch (err) {
        console.error('Error parsing analysis JSON:', err);
        setError(`Failed to parse analysis: ${err instanceof Error ? err.message : String(err)}`);
      }
    } catch (error) {
      let errorMessage = 'An error occurred during analysis';
      setIsOfflineMode(true);
      
      if (axios.isAxiosError(error)) {
        console.error('API Error:', {
          status: error.response?.status,
          data: error.response?.data
        });
        
        if (error.response?.status === 401) {
          errorMessage = 'Authentication failed. Please ensure your OpenRouter API token is correctly set in the environment variables.';
        } else if (error.response?.status === 429) {
          errorMessage = 'Rate limit exceeded. Please try again later.';
        } else if (error.response?.data?.error?.message) {
          errorMessage = `API Error: ${error.response.data.error.message}`;
        } else if (error.response?.data?.error) {
          errorMessage = `API Error: ${error.response.data.error}`;
        }
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      setError(errorMessage);
      
      // Generate a simple offline analysis as fallback
      const offlineAnalysis = {
        explanation: `<p>This is a fallback analysis of your query plan. The API request failed with error: ${errorMessage}</p>
                     <p>The query plan shows a typical execution flow for a SQL query. Since we couldn't connect to the API, here are some general observations:</p>
                     <ul>
                       <li>Query plans typically start with a scan operation (Sequential Scan, Index Scan, etc.)</li>
                       <li>Join operations combine data from multiple tables</li>
                       <li>Aggregation operations group and summarize data</li>
                       <li>Sort operations arrange data in a specific order</li>
                     </ul>
                     <p>To get a detailed analysis, please ensure your OpenRouter API connection is working.</p>`,
        concerns: [
          "API connection failed - limited analysis available",
          "Using fallback analysis mode"
        ],
        costs: {
          "Scan Operations": "Average",
          "Join Operations": "Average",
          "Sort Operations": "Average"
        }
      };
      
      setAnalysis(offlineAnalysis);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAnalyze = async () => {
    if (!queryPlan.trim()) {
      setError('Please enter a query plan');
      return;
    }

    // Reset all states
    setError(null);
    setAnalysis(null);
    
    // Fetch the analysis
    await fetchAnalysis();
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center space-x-3">
            <h1 className="text-2xl font-bold text-gray-900">Query Plan Visualizer</h1>
            {isOfflineMode && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                Offline Mode
              </span>
            )}
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Brain className="h-5 w-5 text-purple-600" />
              <select
                value={selectedModel}
                onChange={(e) => setSelectedModel(e.target.value)}
                className="block w-56 rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500 text-sm"
                disabled={isAnalyzing}
              >
                {models.map((model) => (
                  <option key={model.id} value={model.id}>
                    {model.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              onClick={testConnection}
              disabled={connectionStatus === 'testing'}
              className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
                connectionStatus === 'testing' ? 'bg-blue-400' :
                connectionStatus === 'success' ? 'bg-green-600' :
                connectionStatus === 'error' ? 'bg-red-600' :
                'bg-blue-600 hover:bg-blue-700'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
            >
              {connectionStatus === 'testing' ? 'Testing...' :
               connectionStatus === 'success' ? 'Connection Successful' :
               connectionStatus === 'error' ? 'Connection Failed' :
               'Test Connection'}
            </button>
          </div>
        </div>

        {haiku && (
          <div className="mb-8 p-4 bg-indigo-50 border border-indigo-100 rounded-lg">
            <h3 className="text-sm font-medium text-indigo-800 mb-2">Redshift Haiku:</h3>
            <p className="text-sm text-indigo-900 whitespace-pre-line font-mono">{haiku}</p>
          </div>
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="mb-4">
                <label 
                  htmlFor="queryPlan" 
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  Paste Query Execution Plan
                </label>
                <textarea
                  id="queryPlan"
                  value={queryPlan}
                  onChange={(e) => setQueryPlan(e.target.value)}
                  className="w-full h-64 p-4 text-sm font-mono bg-gray-50 border border-gray-300 rounded-lg focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Paste your query execution plan here..."
                  spellCheck="false"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleAnalyze}
                  disabled={!queryPlan.trim() || isAnalyzing}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  <Play className={`h-4 w-4 mr-2 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                </button>

                {error && (
                  <div className="flex-1 flex items-center p-3 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0" />
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}
              </div>
            </div>
            
            {/* Text representation of query plan */}
            {textRepresentation && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Query Plan Structure</h2>
                </div>
                
                <pre className="text-xs bg-gray-50 p-4 rounded-lg overflow-x-auto whitespace-pre font-mono max-h-[300px] overflow-y-auto border border-gray-200">
                  {textRepresentation}
                </pre>
              </div>
            )}
            
            {queryPlan && <QueryPlanToMermaid queryPlan={queryPlan} />}
          </div>

          <div className="space-y-6">
            {queryPlan && <QueryPlanWalkthru queryPlan={queryPlan} />}

            {analysis && (
              <div className="bg-white rounded-lg shadow-lg p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h2>
                
                <div className="mb-6">
                  <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: analysis.explanation }} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}