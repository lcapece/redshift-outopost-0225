import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ScriptForm } from '../components/ScriptForm';
import { fetchScriptById } from '../services/scriptsService';
import { useAuth } from '../hooks/useAuth';

export function ScriptFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [script, setScript] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const isEditMode = id !== 'new';

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    
    if (isEditMode) {
      loadScript();
    } else {
      setIsLoading(false);
    }
  }, [id, user, navigate, isEditMode]);

  const loadScript = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const fetchedScript = await fetchScriptById(id);
      if (fetchedScript) {
        setScript(fetchedScript);
      } else {
        setError('Script not found');
        navigate('/admin/scripts');
      }
    } catch (err) {
      setError('Failed to load script');
      console.error('Error loading script:', err);
      navigate('/admin/scripts');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/admin/scripts');
  };

  if (!user) {
    return null; // Redirect handled in useEffect
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <ScriptForm 
          script={script} 
          isEditMode={isEditMode} 
          onBack={handleBack} 
        />
      </div>
    </div>
  );
}