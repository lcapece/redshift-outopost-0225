import React, { useState, useEffect } from 'react';
import { TableProperties, AlertTriangle, Database } from 'lucide-react';
import { ImportModal } from '../components/DataImport/ImportModal';
import { ErrorReport } from '../components/DataImport/ErrorReport';
import { ModernDataGrid } from '../components/DataImport/ModernDataGrid';
import { useAuth } from '../hooks/useAuth';
import { Link } from 'react-router-dom';
import { supabase } from '../services/supabase';

export function DataImportPage() {
  const { user, loading: isLoading } = useAuth();
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [showErrorReport, setShowErrorReport] = useState(false);
  const [tableData, setTableData] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadTableData();
    }
  }, [user]);

  const loadTableData = async () => {
    try {
      const { data, error } = await supabase
        .from('imported_svv_data')
        .select('*')
        .eq('created_by_user', user?.id);

      if (error) throw error;
      setTableData(data || []);
    } catch (err) {
      console.error('Error loading table data:', err);
      setError('Failed to load table data');
    }
  };

  const handleImport = async (data: any) => {
    try {
      const { error } = await supabase
        .from('imported_svv_data')
        .insert(data);

      if (error) throw error;
      await loadTableData();
      setIsImportModalOpen(false);
    } catch (error) {
      console.error('Import error:', error);
      setShowErrorReport(true);
    }
  };

  const handleDeleteAll = async () => {
    try {
      const { error } = await supabase
        .from('imported_svv_data')
        .delete()
        .eq('created_by_user', user?.id);

      if (error) throw error;
      setTableData([]);
    } catch (err) {
      console.error('Error deleting records:', err);
      setError('Failed to delete records');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-red-500" />
          <h2 className="mt-4 text-lg font-medium text-gray-900">Authentication Required</h2>
          <p className="mt-2 text-sm text-gray-500">
            Please sign in to access the data explorer feature.
          </p>
          <div className="mt-6">
            <Link
              to="/"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
            >
              Return to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Database className="h-8 w-8 text-indigo-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Data Explorer</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link
                to="/"
                className="text-gray-500 hover:text-gray-700"
              >
                Back to Home
              </Link>
              <button
                onClick={() => setIsImportModalOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
              >
                <TableProperties className="h-4 w-4 mr-2" />
                Import Data
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex">
              <AlertTriangle className="h-5 w-5 text-red-400 mr-2" />
              <span className="text-red-700">{error}</span>
            </div>
          </div>
        )}

        {showErrorReport ? (
          <ErrorReport
            onSubmit={(report) => {
              console.log('Error report submitted:', report);
              setShowErrorReport(false);
            }}
          />
        ) : tableData.length > 0 ? (
          <ModernDataGrid 
            data={tableData}
            onDeleteAll={handleDeleteAll}
          />
        ) : (
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <TableProperties className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-4 text-lg font-medium text-gray-900">No Data Imported</h3>
            <p className="mt-2 text-sm text-gray-500 max-w-sm mx-auto">
              Import your SVV_TABLE_INFO data to analyze table metrics and optimize your Redshift cluster.
            </p>
            <div className="mt-6">
              <button
                onClick={() => setIsImportModalOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
              >
                <TableProperties className="h-4 w-4 mr-2" />
                Import Data
              </button>
            </div>
          </div>
        )}
      </div>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
      />
    </div>
  );
}