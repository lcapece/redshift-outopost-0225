import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Database, Search, Upload, AlertCircle, Lock, RefreshCw, Download, 
  Plus, Trash2, Edit, Eye, CheckCircle, XCircle, Filter, 
  Calendar, Tag, User, Star, MessageSquare, ExternalLink
} from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { supabase } from '../services/supabase';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

interface ContentSource {
  id: string;
  url: string;
  name: string;
  status: 'active' | 'inactive';
  lastScanDate: string;
  scanFrequency: 'daily' | 'weekly' | 'monthly';
  category: string;
  tags: string[];
}

interface ContentItem {
  id: string;
  title: string;
  sourceUrl: string;
  dateRetrieved: string;
  status: 'new' | 'pending' | 'approved' | 'rejected';
  assignedReviewer: string;
  priority: 'low' | 'medium' | 'high';
  categories: string[];
  tags: string[];
  previewSnippet: string;
  content: string;
}

export function ContentDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'sources' | 'content'>('sources');
  const [sources, setSources] = useState<ContentSource[]>([]);
  const [contentItems, setContentItems] = useState<ContentItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [isAddSourceModalOpen, setIsAddSourceModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>({
    start: '',
    end: ''
  });
  const [sortField, setSortField] = useState<string>('dateRetrieved');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [selectedContent, setSelectedContent] = useState<ContentItem | null>(null);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    loadData();
  }, [user, navigate]);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      if (activeTab === 'sources') {
        const { data: sourcesData, error: sourcesError } = await supabase
          .from('content_sources')
          .select('*')
          .order('created_at', { ascending: false });

        if (sourcesError) throw sourcesError;
        setSources(sourcesData || []);
      } else {
        const { data: contentData, error: contentError } = await supabase
          .from('content_items')
          .select('*')
          .order('date_scraped', { ascending: false });

        if (contentError) throw contentError;
        setContentItems(contentData || []);
      }
    } catch (err) {
      console.error('Error loading data:', err);
      setError('Failed to load data. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddSource = async (source: Omit<ContentSource, 'id'>) => {
    try {
      const { error } = await supabase
        .from('content_sources')
        .insert([source]);

      if (error) throw error;
      
      toast.success('Source added successfully');
      loadData();
      setIsAddSourceModalOpen(false);
    } catch (err) {
      console.error('Error adding source:', err);
      toast.error('Failed to add source');
    }
  };

  const handleUpdateSource = async (id: string, updates: Partial<ContentSource>) => {
    try {
      const { error } = await supabase
        .from('content_sources')
        .update(updates)
        .eq('id', id);

      if (error) throw error;
      
      toast.success('Source updated successfully');
      loadData();
    } catch (err) {
      console.error('Error updating source:', err);
      toast.error('Failed to update source');
    }
  };

  const handleBulkAction = async (action: 'enable' | 'disable' | 'delete') => {
    if (!selectedItems.length) return;

    try {
      if (action === 'delete') {
        const { error } = await supabase
          .from(activeTab === 'sources' ? 'content_sources' : 'content_items')
          .delete()
          .in('id', selectedItems);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('content_sources')
          .update({ status: action === 'enable' ? 'active' : 'inactive' })
          .in('id', selectedItems);

        if (error) throw error;
      }

      toast.success(`Bulk action "${action}" completed successfully`);
      setSelectedItems([]);
      loadData();
    } catch (err) {
      console.error('Error performing bulk action:', err);
      toast.error('Failed to perform bulk action');
    }
  };

  const handleExport = async () => {
    try {
      const { data, error } = await supabase
        .from('content_items')
        .select('*')
        .in('id', selectedItems);

      if (error) throw error;

      const csvContent = 'data:text/csv;charset=utf-8,' + 
        encodeURIComponent(Papa.unparse(data));
      
      const link = document.createElement('a');
      link.setAttribute('href', csvContent);
      link.setAttribute('download', `content-export-${format(new Date(), 'yyyy-MM-dd')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Export completed successfully');
    } catch (err) {
      console.error('Error exporting data:', err);
      toast.error('Failed to export data');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Database className="h-8 w-8 text-indigo-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Content Management</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setActiveTab('sources')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeTab === 'sources'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Sources Management
              </button>
              <button
                onClick={() => setActiveTab('content')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  activeTab === 'content'
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Content Review
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <span className="text-red-700">{error}</span>
            </div>
          </div>
        )}

        {/* Sources Management Tab */}
        {activeTab === 'sources' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setIsAddSourceModalOpen(true)}
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Source
                  </button>
                  {selectedItems.length > 0 && (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleBulkAction('enable')}
                        className="inline-flex items-center px-3 py-1.5 border border-green-600 rounded-md text-sm font-medium text-green-600 hover:bg-green-50"
                      >
                        <CheckCircle className="h-4 w-4 mr-1.5" />
                        Enable
                      </button>
                      <button
                        onClick={() => handleBulkAction('disable')}
                        className="inline-flex items-center px-3 py-1.5 border border-yellow-600 rounded-md text-sm font-medium text-yellow-600 hover:bg-yellow-50"
                      >
                        <XCircle className="h-4 w-4 mr-1.5" />
                        Disable
                      </button>
                      <button
                        onClick={() => handleBulkAction('delete')}
                        className="inline-flex items-center px-3 py-1.5 border border-red-600 rounded-md text-sm font-medium text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4 mr-1.5" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search sources..."
                      className="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm"
                    />
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  </div>
                  <button
                    onClick={loadData}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    <RefreshCw className="h-4 w-4 mr-1.5" />
                    Refresh
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <input
                          type="checkbox"
                          checked={selectedItems.length === sources.length}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedItems(sources.map(s => s.id));
                            } else {
                              setSelectedItems([]);
                            }
                          }}
                          className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                        />
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        URL/Name
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Scan
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Frequency
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Category/Tags
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {sources.map((source) => (
                      <tr key={source.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <input
                            type="checkbox"
                            checked={selectedItems.includes(source.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedItems([...selectedItems, source.id]);
                              } else {
                                setSelectedItems(selectedItems.filter(id => id !== source.id));
                              }
                            }}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm font-medium text-gray-900">{source.name}</div>
                          <div className="text-sm text-gray-500">{source.url}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            source.status === 'active' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {source.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {source.lastScanDate ? format(new Date(source.lastScanDate), 'PPp') : 'Never'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {source.scanFrequency}
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-gray-900">{source.category}</div>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {source.tags.map((tag, index) => (
                              <span
                                key={index}
                                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end space-x-2">
                            <button
                              onClick={() => handleUpdateSource(source.id, { status: source.status === 'active' ? 'inactive' : 'active' })}
                              className={`text-sm font-medium ${
                                source.status === 'active' 
                                  ? 'text-red-600 hover:text-red-900' 
                                  : 'text-green-600 hover:text-green-900'
                              }`}
                            >
                              {source.status === 'active' ? 'Disable' : 'Enable'}
                            </button>
                            <button
                              onClick={() => {/* Handle edit */}}
                              className="text-indigo-600 hover:text-indigo-900"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => {/* Handle delete */}}
                              className="text-red-600 hover:text-red-900"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Content Review Tab */}
        {activeTab === 'content' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-4">
                  {selectedItems.length > 0 && (
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {/* Handle approve */}}
                        className="inline-flex items-center px-3 py-1.5 border border-green-600 rounded-md text-sm font-medium text-green-600 hover:bg-green-50"
                      >
                        <CheckCircle className="h-4 w-4 mr-1.5" />
                        Approve
                      </button>
                      <button
                        onClick={() => {/* Handle reject */}}
                        className="inline-flex items-center px-3 py-1.5 border border-red-600 rounded-md text-sm font-medium text-red-600 hover:bg-red-50"
                      >
                        <XCircle className="h-4 w-4 mr-1.5" />
                        Reject
                      </button>
                      <button
                        onClick={() => {/* Handle assign */}}
                        className="inline-flex items-center px-3 py-1.5 border border-indigo-600 rounded-md text-sm font-medium text-indigo-600 hover:bg-indigo-50"
                      >
                        <User className="h-4 w-4 mr-1.5" />
                        Assign
                      </button>
                    </div>
                  )}
                  <button
                    onClick={handleExport}
                    className="inline-flex items-center px-3 py-1.5 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    <Download className="h-4 w-4 mr-1.5" />
                    Export
                  </button>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search content..."
                      className="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm"
                    />
                    <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                  </div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="pl-3 pr-10 py-2 text-sm border border-gray-300 rounded-md"
                  >
                    <option value="all">All Status</option>
                    <option value="new">New</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                  </select>
                  <div className="flex items-center space-x-2">
                    <input
                      type="date"
                      value={dateRange.start}
                      onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                      className="pl-3 pr-10 py-2 text-sm border border-gray-300 rounded-md"
                    />
                    <span className="text-gray-500">to</span>
                    <input
                      type="date"
                      value={dateRange.end}
                      onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                      className="pl-3 pr-10 py-2 text-sm border border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>

              <div className="flex">
                {/* Content List */}
                <div className="flex-1 overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <input
                            type="checkbox"
                            checked={selectedItems.length === contentItems.length}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedItems(contentItems.map(item => item.id));
                              } else {
                                setSelectedItems([]);
                              }
                            }}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Title
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Source
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Reviewer
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Priority
                        </th>
                        <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {contentItems.map((item) => (
                        <tr 
                          key={item.id} 
                          className={`hover:bg-gray-50 ${selectedContent?.id === item.id ? 'bg-indigo-50' : ''}`}
                          onClick={() => setSelectedContent(item)}
                        >
                          <td className="px-6 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedItems.includes(item.id)}
                              onChange={(e) => {
                                e.stopPropagation();
                                if (e.target.checked) {
                                  setSelectedItems([...selectedItems, item.id]);
                                } else {
                                  setSelectedItems(selectedItems.filter(id => id !== item.id));
                                }
                              }}
                              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                            />
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">{item.title}</div>
                            <div className="text-sm text-gray-500 line-clamp-1">{item.previewSnippet}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <a 
                              href={item.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm text-indigo-600 hover:text-indigo-900"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {format(new Date(item.dateRetrieved), 'PPp')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              item.status === 'approved' ? 'bg-green-100 text-green-800' :
                              item.status === 'rejected' ? 'bg-red-100 text-red-800' :
                              item.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {item.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {item.assignedReviewer || '-'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              item.priority === 'high' ? 'bg-red-100 text-red-800' :
                              item.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }`}>
                              {item.priority}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div className="flex justify-end space-x-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  /* Handle edit */
                                }}
                                className="text-indigo-600 hover:text-indigo-900"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  /* Handle delete */
                                }}
                                className="text-red-600 hover:text-red-900"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Preview Pane */}
                {selectedContent && (
                  <div className="w-1/3 ml-6 bg-white rounded-lg shadow-sm p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h2 className="text-lg font-medium text-gray-900">{selectedContent.title}</h2>
                      <button
                        onClick={() => setSelectedContent(null)}
                        className="text-gray-400 hover:text-gray-500"
                      >
                        <XCircle className="h-5 w-5" />
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Status</h3>
                        <div className="mt-1 flex items-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            selectedContent.status === 'approved' ? 'bg-green-100 text-green-800' :
                            selectedContent.status === 'rejected' ? 'bg-red-100 text-red-800' :
                            selectedContent.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {selectedContent.status}
                          </span>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Categories & Tags</h3>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {selectedContent.categories.map((category, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800"
                            >
                              {category}
                            </span>
                          ))}
                          {selectedContent.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-sm font-medium text-gray-500">Content Preview</h3>
                        <div className="mt-1 prose prose-sm max-w-none">
                          {selectedContent.content}
                        </div>
                      </div>

                      <div className="flex justify-end space-x-3 pt-4 border-t">
                        <button
                          onClick={() => {/* Handle approve */}}
                          className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1.5" />
                          Approve
                        </button>
                        <button
                          onClick={() => {/* Handle reject */}}
                          className="inline-flex items-center px-3 py-1.5 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
                        >
                          <XCircle className="h-4 w-4 mr-1.5" />
                          Reject
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}