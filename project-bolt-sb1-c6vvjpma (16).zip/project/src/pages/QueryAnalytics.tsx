import React from 'react';
import { QueryPlanVisualizer } from '../components/QueryPlanVisualizer';

export function QueryAnalytics() {
  return <QueryPlanVisualizer />;
}