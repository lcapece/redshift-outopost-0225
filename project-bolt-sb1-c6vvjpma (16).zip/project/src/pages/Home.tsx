import React from 'react';
import { Link } from 'react-router-dom';
import { Database, LineChart, FileText, ArrowRight, Code, BarChart, Terminal, Zap, Users, Settings } from 'lucide-react';
import { Footer } from '../components/Footer';
import { useAuth } from '../hooks/useAuth';

export function Home() {
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <main className="flex-grow">
        {/* Hero Section */}
        <div className="relative isolate overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=2850')] bg-cover bg-center bg-no-repeat opacity-10"></div>
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-900 via-indigo-800 to-purple-900 mix-blend-multiply"></div>
          </div>

          <div className="relative mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-4xl text-center">
              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl">
                Redshift Query
                <span className="block text-indigo-200">Performance Mastery</span>
              </h1>
              <p className="mt-6 text-lg leading-8 text-gray-300">
                Transform your Redshift queries from complex challenges into optimized solutions. 
                Visualize execution plans, analyze performance bottlenecks, and implement proven optimization strategies.
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6">
                <Link
                  to="/visualizer"
                  className="rounded-md bg-indigo-500 px-6 py-3 text-base font-semibold text-white shadow-sm hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-400"
                >
                  Start Analyzing
                  <ArrowRight className="ml-2 -mr-1 h-5 w-5 inline-block" />
                </Link>
                <Link
                  to="/scripts"
                  className="text-base font-semibold leading-6 text-white hover:text-indigo-200"
                >
                  Browse Scripts <span aria-hidden="true">→</span>
                </Link>
              </div>
            </div>
          </div>

          <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80">
            <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-indigo-200 to-indigo-800 opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"></div>
          </div>
        </div>

        {/* Features Section */}
        <div className="py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-base font-semibold leading-7 text-indigo-600">Powerful Features</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                Everything you need to master Redshift
              </p>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                Comprehensive tools and insights to optimize your database performance
              </p>
            </div>

            <div className="mx-auto mt-16 max-w-7xl sm:mt-20 lg:mt-24">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
                {/* Query Visualization */}
                <div className="relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg border border-gray-100 hover:border-indigo-100 transition-colors duration-200">
                  <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500"></div>
                  <div className="relative">
                    <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600">
                      <LineChart className="h-6 w-6" />
                    </div>
                    <h3 className="mt-6 text-xl font-semibold text-gray-900">Query Visualization</h3>
                    <p className="mt-2 text-gray-700">
                      Interactive visual representation of query execution plans with cost analysis and bottleneck detection.
                    </p>
                  </div>
                </div>

                {/* Data Management */}
                <Link
                  to="/data-explorer"
                  className="relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg border border-gray-100 hover:border-indigo-100 transition-colors duration-200 group"
                >
                  <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-500 group-hover:opacity-20 transition-opacity"></div>
                  <div className="relative">
                    <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
                      <Database className="h-6 w-6" />
                    </div>
                    <h3 className="mt-6 text-xl font-semibold text-gray-900">Data Management</h3>
                    <p className="mt-2 text-gray-700">
                      Comprehensive tools for managing and analyzing your Redshift data structures and performance metrics.
                    </p>
                    <div className="mt-4 inline-flex items-center text-sm font-medium text-blue-600">
                      Explore Data Management
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </div>
                  </div>
                </Link>

                {/* Script Library */}
                <div className="relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg border border-gray-100 hover:border-indigo-100 transition-colors duration-200">
                  <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-pink-500 via-red-500 to-orange-500"></div>
                  <div className="relative">
                    <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-600">
                      <Code className="h-6 w-6" />
                    </div>
                    <h3 className="mt-6 text-xl font-semibold text-gray-900">Script Library</h3>
                    <p className="mt-2 text-gray-700">
                      Curated collection of SQL scripts and utilities for common Redshift administration tasks.
                    </p>
                  </div>
                </div>

                {/* Admin Dashboard - Only shown to admin users */}
                {user?.email && (user.email.includes('@admin.com') || user.email === 'lcapece@optonline.net') && (
                  <>
                    <Link
                      to="/admin"
                      className="relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg border border-gray-100 hover:border-indigo-100 transition-colors duration-200 group"
                    >
                      <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-purple-500 via-indigo-500 to-blue-500 group-hover:opacity-20 transition-opacity"></div>
                      <div className="relative">
                        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-purple-100 text-purple-600">
                          <Settings className="h-6 w-6" />
                        </div>
                        <h3 className="mt-6 text-xl font-semibold text-gray-900">Admin Dashboard</h3>
                        <p className="mt-2 text-gray-700">
                          Manage content, users, and system settings through the administrative interface.
                        </p>
                        <div className="mt-4 inline-flex items-center text-sm font-medium text-purple-600">
                          Access Admin Panel
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </div>
                      </div>
                    </Link>

                    <Link
                      to="/admin"
                      className="relative overflow-hidden rounded-2xl bg-white p-8 shadow-lg border border-gray-100 hover:border-indigo-100 transition-colors duration-200 group"
                    >
                      <div className="absolute inset-0 opacity-10 bg-gradient-to-br from-green-500 via-emerald-500 to-teal-500 group-hover:opacity-20 transition-opacity"></div>
                      <div className="relative">
                        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-green-100 text-green-600">
                          <Settings className="h-6 w-6" />
                        </div>
                        <h3 className="mt-6 text-xl font-semibold text-gray-900">Admin Dashboard (Test)</h3>
                        <p className="mt-2 text-gray-700">
                          Alternative link to access the administrative interface.
                        </p>
                        <div className="mt-4 inline-flex items-center text-sm font-medium text-green-600">
                          Access Admin Panel
                          <ArrowRight className="ml-1 h-4 w-4" />
                        </div>
                      </div>
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-white py-24 sm:py-32">
          <div className="mx-auto max-w-7xl px-6 lg:px-8">
            <div className="mx-auto max-w-2xl lg:max-w-none">
              <div className="text-center">
                <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                  Trusted by data teams worldwide
                </h2>
                <p className="mt-4 text-lg leading-8 text-gray-600">
                  Helping teams optimize their Redshift performance every day
                </p>
              </div>
              <dl className="mt-16 grid grid-cols-1 gap-0.5 overflow-hidden rounded-2xl text-center sm:grid-cols-2 lg:grid-cols-4">
                <div className="flex flex-col bg-gray-50 p-8">
                  <dt className="text-sm font-semibold leading-6 text-gray-600">Queries Analyzed</dt>
                  <dd className="order-first text-3xl font-semibold tracking-tight text-gray-900">100K+</dd>
                </div>
                <div className="flex flex-col bg-gray-50 p-8">
                  <dt className="text-sm font-semibold leading-6 text-gray-600">Performance Gains</dt>
                  <dd className="order-first text-3xl font-semibold tracking-tight text-gray-900">40%</dd>
                </div>
                <div className="flex flex-col bg-gray-50 p-8">
                  <dt className="text-sm font-semibold leading-6 text-gray-600">Active Users</dt>
                  <dd className="order-first text-3xl font-semibold tracking-tight text-gray-900">10K+</dd>
                </div>
                <div className="flex flex-col bg-gray-50 p-8">
                  <dt className="text-sm font-semibold leading-6 text-gray-600">Scripts Available</dt>
                  <dd className="order-first text-3xl font-semibold tracking-tight text-gray-900">500+</dd>
                </div>
              </dl>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="relative isolate overflow-hidden bg-gray-900">
          <div className="px-6 py-24 sm:px-6 sm:py-32 lg:px-8">
            <div className="mx-auto max-w-2xl text-center">
              <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
                Ready to optimize your queries?
                <br />
                Start analyzing today.
              </h2>
              <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-gray-300">
                Join thousands of data professionals who use our tools to improve their Redshift performance.
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6">
                <Link
                  to="/visualizer"
                  className="rounded-md bg-white px-3.5 py-2.5 text-sm font-semibold text-gray-900 shadow-sm hover:bg-gray-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                >
                  Get started
                </Link>
                <Link
                  to="/scripts"
                  className="text-sm font-semibold leading-6 text-white"
                >
                  Learn more <span aria-hidden="true">→</span>
                </Link>
              </div>
            </div>
          </div>
          <div className="absolute left-1/2 top-0 -z-10 -translate-x-1/2 blur-3xl xl:-top-6" aria-hidden="true">
            <div className="aspect-[1155/678] w-[72.1875rem] bg-gradient-to-tr from-indigo-500 to-purple-500 opacity-30"></div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}