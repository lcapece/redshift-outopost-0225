import React, { useState, useEffect } from 'react';
import { Database, Search, Upload, AlertCircle, Lock, RefreshCw } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { ImportModal } from '../components/DataImport/ImportModal';
import { DataVisualizer } from '../components/DataImport/DataVisualizer';
import { DatabaseNavigator } from '../components/Database/DatabaseNavigator';
import { TableDetails } from '../components/Database/TableDetails';
import { supabase } from '../services/supabase';
import CryptoJS from 'crypto-js';

interface TableInfo {
  schema: string;
  name: string;
  attributes: Array<{
    name: string;
    type: string;
    nullable: boolean;
  }>;
}

function decryptIdentifier(value: string, type: 'D' | 'S' | 'T', password: string): string {
  // Check if value has the expected format (D/S/T prefix + 15 chars)
  if (!value || value.length !== 16 || !/^[DST]/.test(value)) {
    return value;
  }

  try {
    // Remove the prefix
    const prefix = value.charAt(0);
    const encryptedPart = value.substring(1);

    // Try to decrypt each possible original value until we find a match
    const possibleValues = [
      'analytics', 'staging', 'reporting', 'public', 'sales', 'customers',
      'orders', 'products', 'inventory', 'users', 'transactions', 'metrics',
      'datawarehouse', 'development', 'production'
    ];

    for (const original of possibleValues) {
      const hash = CryptoJS.SHA256(original + password).toString();
      if (hash.substring(0, 15) === encryptedPart) {
        return original;
      }
    }

    // If no match found, return formatted encrypted value
    return `${type}:${encryptedPart.substring(0, 8)}...`;
  } catch (error) {
    console.error('Error decrypting identifier:', error);
    return value;
  }
}

export function DatabaseManagementPage() {
  const { user, loading: isLoading } = useAuth();
  const [schemas, setSchemas] = useState<string[]>([]);
  const [tables, setTables] = useState<Record<string, TableInfo[]>>({});
  const [selectedSchema, setSelectedSchema] = useState<string | null>(null);
  const [selectedTable, setSelectedTable] = useState<TableInfo | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [decryptionPassword, setDecryptionPassword] = useState('');
  const [isDecrypting, setIsDecrypting] = useState(false);

  useEffect(() => {
    if (user) {
      loadDatabaseStructure();
    }
  }, [user]);

  const loadDatabaseStructure = async () => {
    try {
      // Load schemas and tables from encrypted storage
      const { data: encryptedData, error: fetchError } = await supabase
        .from('imported_svv_data')
        .select('*')
        .eq('created_by_user', user?.id);

      if (fetchError) throw fetchError;

      if (encryptedData && encryptedData.length > 0) {
        // Process and organize the data
        const schemaMap = new Map<string, TableInfo[]>();
        
        encryptedData.forEach(item => {
          const schemaName = item.schema_name;
          if (!schemaMap.has(schemaName)) {
            schemaMap.set(schemaName, []);
          }
          
          schemaMap.get(schemaName)?.push({
            schema: schemaName,
            name: item.table_name,
            attributes: [] // These would be populated from the actual data
          });
        });

        setSchemas(Array.from(schemaMap.keys()).sort());
        setTables(Object.fromEntries(schemaMap));
      }
    } catch (err) {
      console.error('Error loading database structure:', err);
      setError('Failed to load database structure');
    }
  };

  const handleDecrypt = async () => {
    if (!decryptionPassword) {
      setError('Please enter a decryption password');
      return;
    }

    setIsDecrypting(true);
    setError(null);

    try {
      const { data: encryptedData, error: fetchError } = await supabase
        .from('imported_svv_data')
        .select('*')
        .eq('created_by_user', user?.id);

      if (fetchError) throw fetchError;

      if (encryptedData && encryptedData.length > 0) {
        // Process and organize the decrypted data
        const schemaMap = new Map<string, TableInfo[]>();
        
        encryptedData.forEach(item => {
          const decryptedSchema = decryptIdentifier(item.schema_name, 'S', decryptionPassword);
          const decryptedTable = decryptIdentifier(item.table_name, 'T', decryptionPassword);
          
          if (!schemaMap.has(decryptedSchema)) {
            schemaMap.set(decryptedSchema, []);
          }
          
          schemaMap.get(decryptedSchema)?.push({
            schema: decryptedSchema,
            name: decryptedTable,
            attributes: [] // These would be populated from the actual data
          });
        });

        setSchemas(Array.from(schemaMap.keys()).sort());
        setTables(Object.fromEntries(schemaMap));
      }
    } catch (err) {
      console.error('Error decrypting data:', err);
      setError('Failed to decrypt data. Please check your password and try again.');
    } finally {
      setIsDecrypting(false);
    }
  };

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handleImport = async (data: any) => {
    try {
      // Store the imported data
      const { error: importError } = await supabase
        .from('imported_svv_data')
        .insert(data);

      if (importError) throw importError;

      setIsImportModalOpen(false);
      loadDatabaseStructure();
    } catch (err) {
      console.error('Error importing data:', err);
      setError('Failed to import data');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="mx-auto h-12 w-12 text-red-500" />
          <h2 className="mt-2 text-lg font-medium text-gray-900">Authentication Required</h2>
          <p className="mt-1 text-sm text-gray-500">Please sign in to access database management.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Database className="h-8 w-8 text-indigo-600 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">Database Management</h1>
            </div>
            <button
              onClick={() => setIsImportModalOpen(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
            >
              <Upload className="h-4 w-4 mr-2" />
              Import Data
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <span className="text-red-700">{error}</span>
            </div>
          </div>
        )}

        {/* Decryption Password Section */}
        <div className="mb-6 bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div className="flex-1 max-w-lg">
              <label htmlFor="decryptionPassword" className="block text-sm font-medium text-gray-700 mb-2">
                Decryption Password
              </label>
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="password"
                  id="decryptionPassword"
                  value={decryptionPassword}
                  onChange={(e) => setDecryptionPassword(e.target.value)}
                  className="block w-full pl-10 pr-12 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Enter password to decrypt table names"
                />
              </div>
            </div>
            <button
              onClick={handleDecrypt}
              disabled={isDecrypting || !decryptionPassword}
              className="ml-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400"
            >
              {isDecrypting ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Decrypting...
                </>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Decrypt Names
                </>
              )}
            </button>
          </div>
        </div>

        <div className="flex space-x-8">
          {/* Left Panel - Navigation */}
          <div className="w-2/5 bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => handleSearch(e.target.value)}
                  placeholder="Search tables..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
            <DatabaseNavigator
              schemas={schemas}
              tables={tables}
              selectedSchema={selectedSchema}
              selectedTable={selectedTable}
              onSchemaSelect={setSelectedSchema}
              onTableSelect={setSelectedTable}
              searchTerm={searchTerm}
            />
          </div>

          {/* Right Panel - Details */}
          <div className="flex-1">
            {selectedTable ? (
              <TableDetails table={selectedTable} />
            ) : (
              <div className="bg-white rounded-lg shadow-lg p-8 text-center">
                <Database className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">Select a Table</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Choose a table from the navigation panel to view its details
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImport}
      />
    </div>
  );
}