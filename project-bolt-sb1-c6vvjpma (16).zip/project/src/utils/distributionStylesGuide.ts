/**
 * Redshift Distribution Styles Guide
 * 
 * This file provides explanations for Redshift distribution styles found in query plans.
 * These explanations translate technical terms into plain language for better understanding.
 */

export interface DistributionStyleExplanation {
  code: string;
  name: string;
  description: string;
  impact: string;
  whenToUse: string;
}

export const distributionStyles: DistributionStyleExplanation[] = [
  {
    code: "DS_DIST_NONE",
    name: "No Redistribution",
    description: "Data is already correctly distributed and doesn't need to be moved between nodes.",
    impact: "Fastest option as it avoids network traffic between compute nodes.",
    whenToUse: "Ideal scenario when tables are already distributed optimally."
  },
  {
    code: "DS_DIST_ALL_NONE",
    name: "Distributed Table with No Redistribution",
    description: "One table is distributed to all nodes (ALL distribution) and the other table doesn't need redistribution.",
    impact: "Efficient for joining a small table that's replicated across all nodes with a large distributed table.",
    whenToUse: "When joining a small dimension table (ALL distribution) with a large fact table."
  },
  {
    code: "DS_DIST_INNER",
    name: "Inner Table Redistribution",
    description: "The inner table is redistributed across compute nodes to match the outer table's distribution.",
    impact: "Requires network traffic to move the inner table data, but keeps the larger outer table in place.",
    whenToUse: "When the inner table is smaller than the outer table."
  },
  {
    code: "DS_DIST_OUTER",
    name: "Outer Table Redistribution",
    description: "The outer table is redistributed across compute nodes to match the inner table's distribution.",
    impact: "Requires network traffic to move the outer table data, but keeps the inner table in place.",
    whenToUse: "When the outer table is smaller than the inner table."
  },
  {
    code: "DS_DIST_BOTH",
    name: "Both Tables Redistribution",
    description: "Both tables are redistributed across compute nodes based on the join key.",
    impact: "Highest network traffic as both tables are redistributed, but ensures optimal join performance.",
    whenToUse: "When neither table has a distribution style that matches the join key."
  },
  {
    code: "DS_BCAST_INNER",
    name: "Broadcast Inner Table",
    description: "The inner table is copied (broadcast) to all compute nodes.",
    impact: "Requires network traffic to copy the inner table to all nodes, but avoids redistributing the outer table.",
    whenToUse: "When the inner table is small enough to fit in memory on all nodes."
  },
  {
    code: "DS_BCAST_OUTER",
    name: "Broadcast Outer Table",
    description: "The outer table is copied (broadcast) to all compute nodes.",
    impact: "Requires network traffic to copy the outer table to all nodes, but avoids redistributing the inner table.",
    whenToUse: "When the outer table is small enough to fit in memory on all nodes."
  },
  {
    code: "DS_DIST_ALL_INNER",
    name: "Inner Table Already on All Nodes",
    description: "The inner table uses ALL distribution style and is already present on all nodes.",
    impact: "Very efficient as the inner table is already replicated across all nodes.",
    whenToUse: "When the inner table is a small dimension table with ALL distribution."
  },
  {
    code: "DS_DIST_ALL_OUTER",
    name: "Outer Table Already on All Nodes",
    description: "The outer table uses ALL distribution style and is already present on all nodes.",
    impact: "Very efficient as the outer table is already replicated across all nodes.",
    whenToUse: "When the outer table is a small dimension table with ALL distribution."
  }
];

/**
 * Get a human-readable explanation for a distribution style code
 * @param code The distribution style code from the query plan (e.g., DS_DIST_BOTH)
 * @returns A plain language explanation of the distribution style
 */
export function getDistributionStyleExplanation(code: string): DistributionStyleExplanation | undefined {
  return distributionStyles.find(style => style.code === code);
}

/**
 * Get a short description for a distribution style code
 * @param code The distribution style code from the query plan
 * @returns A short description of what the distribution style means
 */
export function getDistributionStyleShortDescription(code: string): string {
  const style = distributionStyles.find(style => style.code === code);
  if (!style) return "Unknown distribution style";
  return style.description;
}