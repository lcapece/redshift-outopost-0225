/*
  # Add authentication schema and policies

  1. New Tables
    - None (using built-in auth.users)
  
  2. Security
    - Update RLS policies to require authentication for write operations
    - Keep read operations public
*/

-- Update policies for redshift_simulations
DROP POLICY IF EXISTS "Enable public access" ON redshift_simulations;

CREATE POLICY "Enable public read access"
  ON redshift_simulations
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Enable authenticated write access"
  ON redshift_simulations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable authenticated delete access"
  ON redshift_simulations
  FOR DELETE
  TO authenticated
  USING (true);

-- Update policies for simulation_metrics
DROP POLICY IF EXISTS "Enable public access" ON simulation_metrics;

CREATE POLICY "Enable public read access"
  ON simulation_metrics
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Enable authenticated write access"
  ON simulation_metrics
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable authenticated delete access"
  ON simulation_metrics
  FOR DELETE
  TO authenticated
  USING (true);