-- Drop existing objects if they exist
DROP VIEW IF EXISTS v_svv_table_info;
DROP FUNCTION IF EXISTS validate_svv_table_info(jsonb);
DROP FUNCTION IF EXISTS get_table_metrics(text, text);
DROP TABLE IF EXISTS imported_svv_data;
DROP TABLE IF EXISTS svv_data_staging;

-- Create imported_svv_data table with proper constraints
CREATE TABLE imported_svv_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL,
  schema_name text NOT NULL,
  table_name text NOT NULL,
  encoded boolean DEFAULT false,
  diststyle text NOT NULL DEFAULT 'AUTO',
  sortkey1 text,
  sortkey1_enc text,
  sortkey_num integer DEFAULT 0,
  size_gb numeric DEFAULT 0,
  pct_empty numeric DEFAULT 0,
  unsorted_pct numeric DEFAULT 0,
  stats_off numeric DEFAULT 0,
  tbl_rows bigint DEFAULT 0,
  skew_sortkey1 numeric DEFAULT 0,
  skew_rows numeric DEFAULT 0,
  estimated_visible_rows bigint DEFAULT 0,
  risk_event text,
  created_by_user uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create view matching SVV_TABLE_INFO structure
CREATE VIEW v_svv_table_info AS
SELECT
  database_name AS dbname,
  schema_name AS schemaname,
  table_name AS tablename,
  encoded,
  diststyle,
  sortkey1,
  sortkey1_enc,
  sortkey_num,
  size_gb,
  pct_empty,
  unsorted_pct,
  stats_off,
  tbl_rows,
  skew_sortkey1,
  skew_rows,
  estimated_visible_rows,
  risk_event
FROM
  imported_svv_data;

-- Enable RLS on imported_svv_data
ALTER TABLE imported_svv_data ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON imported_svv_data
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert for authenticated users"
  ON imported_svv_data
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by_user);

CREATE POLICY "Enable update for data owners"
  ON imported_svv_data
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by_user)
  WITH CHECK (auth.uid() = created_by_user);

CREATE POLICY "Enable delete for data owners"
  ON imported_svv_data
  FOR DELETE
  TO authenticated
  USING (auth.uid() = created_by_user);

-- Create indexes for better performance
CREATE INDEX idx_imported_svv_data_schema_table 
  ON imported_svv_data(schema_name, table_name);

CREATE INDEX idx_imported_svv_data_created 
  ON imported_svv_data(created_at);

CREATE INDEX idx_imported_svv_data_user
  ON imported_svv_data(created_by_user);

-- Create unique constraint for user's tables
CREATE UNIQUE INDEX unique_table_per_user 
  ON imported_svv_data(created_by_user, database_name, schema_name, table_name);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_imported_svv_data_updated_at
  BEFORE UPDATE ON imported_svv_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();