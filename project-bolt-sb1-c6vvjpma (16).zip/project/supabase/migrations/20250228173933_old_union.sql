-- Create forum tables
CREATE TABLE IF NOT EXISTS forum_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  slug text NOT NULL UNIQUE,
  icon text,
  color text,
  position integer DEFAULT 0,
  is_private boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS forum_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  category_id uuid REFERENCES forum_categories(id) ON DELETE CASCADE,
  tags text[],
  is_pinned boolean DEFAULT false,
  is_locked boolean DEFAULT false,
  view_count integer DEFAULT 0,
  like_count integer DEFAULT 0,
  reply_count integer DEFAULT 0,
  last_reply_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid REFERENCES forum_threads(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  content text NOT NULL,
  is_solution boolean DEFAULT false,
  like_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS forum_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  thread_id uuid REFERENCES forum_threads(id) ON DELETE CASCADE,
  reply_id uuid REFERENCES forum_replies(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, thread_id),
  UNIQUE(user_id, reply_id),
  CHECK (
    (thread_id IS NOT NULL AND reply_id IS NULL) OR
    (thread_id IS NULL AND reply_id IS NOT NULL)
  )
);

CREATE TABLE IF NOT EXISTS forum_bookmarks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  thread_id uuid REFERENCES forum_threads(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, thread_id)
);

-- Enable RLS
ALTER TABLE forum_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_bookmarks ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON forum_categories
  FOR SELECT
  TO public
  USING (NOT is_private OR EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND auth.users.email LIKE '%@admin.com'
  ));

CREATE POLICY "Enable read access for all users"
  ON forum_threads
  FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM forum_categories
      WHERE forum_categories.id = forum_threads.category_id
      AND (NOT forum_categories.is_private OR EXISTS (
        SELECT 1 FROM auth.users
        WHERE auth.users.id = auth.uid()
        AND auth.users.email LIKE '%@admin.com'
      ))
    )
  );

CREATE POLICY "Enable insert for authenticated users"
  ON forum_threads
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable update for thread authors and admins"
  ON forum_threads
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.com'
    )
  )
  WITH CHECK (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.com'
    )
  );

CREATE POLICY "Enable read access for all users"
  ON forum_replies
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert for authenticated users"
  ON forum_replies
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable update for reply authors and admins"
  ON forum_replies
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.com'
    )
  )
  WITH CHECK (
    auth.uid() = user_id OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.email LIKE '%@admin.com'
    )
  );

CREATE POLICY "Enable read access for all users"
  ON forum_likes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert/delete for authenticated users"
  ON forum_likes
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable read access for all users"
  ON forum_bookmarks
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert/delete for authenticated users"
  ON forum_bookmarks
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create functions
CREATE OR REPLACE FUNCTION increment_thread_view()
RETURNS trigger AS $$
BEGIN
  UPDATE forum_threads
  SET view_count = view_count + 1
  WHERE id = NEW.thread_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_thread_metrics()
RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_threads
    SET 
      reply_count = reply_count + 1,
      last_reply_at = NEW.created_at
    WHERE id = NEW.thread_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_threads
    SET 
      reply_count = reply_count - 1,
      last_reply_at = (
        SELECT created_at
        FROM forum_replies
        WHERE thread_id = OLD.thread_id
        ORDER BY created_at DESC
        LIMIT 1
      )
    WHERE id = OLD.thread_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_like_count()
RETURNS trigger AS $$
BEGIN
  IF NEW.thread_id IS NOT NULL THEN
    IF TG_OP = 'INSERT' THEN
      UPDATE forum_threads
      SET like_count = like_count + 1
      WHERE id = NEW.thread_id;
    ELSIF TG_OP = 'DELETE' THEN
      UPDATE forum_threads
      SET like_count = like_count - 1
      WHERE id = OLD.thread_id;
    END IF;
  ELSE
    IF TG_OP = 'INSERT' THEN
      UPDATE forum_replies
      SET like_count = like_count + 1
      WHERE id = NEW.reply_id;
    ELSIF TG_OP = 'DELETE' THEN
      UPDATE forum_replies
      SET like_count = like_count - 1
      WHERE id = OLD.reply_id;
    END IF;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER update_thread_metrics_insert
  AFTER INSERT ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION update_thread_metrics();

CREATE TRIGGER update_thread_metrics_delete
  AFTER DELETE ON forum_replies
  FOR EACH ROW
  EXECUTE FUNCTION update_thread_metrics();

CREATE TRIGGER update_like_count_insert
  AFTER INSERT ON forum_likes
  FOR EACH ROW
  EXECUTE FUNCTION update_like_count();

CREATE TRIGGER update_like_count_delete
  AFTER DELETE ON forum_likes
  FOR EACH ROW
  EXECUTE FUNCTION update_like_count();

-- Insert default categories
INSERT INTO forum_categories (name, description, slug, icon, color, position)
VALUES 
  ('General Discussion', 'General discussions about Amazon Redshift', 'general', 'MessageSquare', 'blue', 1),
  ('Performance Tuning', 'Tips and tricks for optimizing Redshift performance', 'performance', 'Zap', 'yellow', 2),
  ('Script Sharing', 'Share and discuss useful Redshift scripts', 'scripts', 'Code', 'purple', 3),
  ('Help & Support', 'Get help with Redshift issues', 'help', 'HelpCircle', 'red', 4),
  ('News & Announcements', 'Latest Redshift news and announcements', 'news', 'Bell', 'green', 5),
  ('Best Practices', 'Redshift best practices and guidelines', 'best-practices', 'CheckCircle', 'indigo', 6)
ON CONFLICT (name) DO NOTHING;