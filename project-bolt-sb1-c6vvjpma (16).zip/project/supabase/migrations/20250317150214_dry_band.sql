/*
  # Article Relationships Schema

  1. New Tables
    - `article_relationships`: Tracks relationships between articles
    - `article_relationship_logs`: Logs relationship processing history

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users

  3. Functions
    - Add functions for relationship strength calculation
    - Add triggers for relationship maintenance
*/

-- Create article_relationships table
CREATE TABLE IF NOT EXISTS article_relationships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  target_article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  relationship_type text NOT NULL DEFAULT 'related',
  strength numeric NOT NULL DEFAULT 0,
  bidirectional boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_processed_at timestamptz DEFAULT now(),
  metadata jsonb,
  UNIQUE(source_article_id, target_article_id)
);

-- Create article_relationship_logs table
CREATE TABLE IF NOT EXISTS article_relationship_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  target_article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  process_type text NOT NULL,
  strength_before numeric,
  strength_after numeric,
  process_duration interval,
  created_at timestamptz DEFAULT now(),
  metadata jsonb
);

-- Enable RLS
ALTER TABLE article_relationships ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_relationship_logs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON article_relationships
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON article_relationships
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON article_relationship_logs
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON article_relationship_logs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_article_relationships_source ON article_relationships(source_article_id);
CREATE INDEX idx_article_relationships_target ON article_relationships(target_article_id);
CREATE INDEX idx_article_relationships_strength ON article_relationships(strength DESC);
CREATE INDEX idx_article_relationship_logs_source ON article_relationship_logs(source_article_id);
CREATE INDEX idx_article_relationship_logs_target ON article_relationship_logs(target_article_id);
CREATE INDEX idx_article_relationship_logs_created ON article_relationship_logs(created_at DESC);

-- Create function to update relationship strength
CREATE OR REPLACE FUNCTION update_relationship_strength(
  source_id uuid,
  target_id uuid,
  new_strength numeric
) RETURNS void AS $$
DECLARE
  old_strength numeric;
BEGIN
  -- Get current strength
  SELECT strength INTO old_strength
  FROM article_relationships
  WHERE source_article_id = source_id AND target_article_id = target_id;

  -- Update relationship
  INSERT INTO article_relationships (
    source_article_id,
    target_article_id,
    strength,
    last_processed_at
  )
  VALUES (
    source_id,
    target_id,
    new_strength,
    now()
  )
  ON CONFLICT (source_article_id, target_article_id)
  DO UPDATE SET
    strength = new_strength,
    last_processed_at = now(),
    updated_at = now();

  -- Log the change
  INSERT INTO article_relationship_logs (
    source_article_id,
    target_article_id,
    process_type,
    strength_before,
    strength_after,
    process_duration,
    metadata
  )
  VALUES (
    source_id,
    target_id,
    'strength_update',
    old_strength,
    new_strength,
    now() - COALESCE(
      (SELECT last_processed_at 
       FROM article_relationships 
       WHERE source_article_id = source_id 
       AND target_article_id = target_id),
      now()
    ),
    jsonb_build_object(
      'update_type', 'manual',
      'timestamp', extract(epoch from now())
    )
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to get related articles
CREATE OR REPLACE FUNCTION get_related_articles(article_id uuid, limit_param integer DEFAULT 5)
RETURNS TABLE (
  related_article_id uuid,
  relationship_strength numeric,
  is_bidirectional boolean
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE 
      WHEN source_article_id = article_id THEN target_article_id
      ELSE source_article_id
    END as related_article_id,
    strength as relationship_strength,
    bidirectional
  FROM article_relationships
  WHERE source_article_id = article_id OR target_article_id = article_id
  ORDER BY strength DESC
  LIMIT limit_param;
END;
$$ LANGUAGE plpgsql;

-- Create function to calculate relationship metrics
CREATE OR REPLACE FUNCTION calculate_relationship_metrics(article_id uuid)
RETURNS TABLE (
  total_relationships integer,
  avg_strength numeric,
  strongest_relationship numeric,
  bidirectional_count integer
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*)::integer as total_relationships,
    AVG(strength) as avg_strength,
    MAX(strength) as strongest_relationship,
    COUNT(*) FILTER (WHERE bidirectional)::integer as bidirectional_count
  FROM article_relationships
  WHERE source_article_id = article_id OR target_article_id = article_id;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to maintain bidirectional relationships
CREATE OR REPLACE FUNCTION maintain_bidirectional_relationships()
RETURNS trigger AS $$
BEGIN
  IF NEW.bidirectional AND NOT EXISTS (
    SELECT 1 FROM article_relationships
    WHERE source_article_id = NEW.target_article_id
    AND target_article_id = NEW.source_article_id
  ) THEN
    INSERT INTO article_relationships (
      source_article_id,
      target_article_id,
      relationship_type,
      strength,
      bidirectional,
      metadata
    ) VALUES (
      NEW.target_article_id,
      NEW.source_article_id,
      NEW.relationship_type,
      NEW.strength,
      true,
      NEW.metadata
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER maintain_bidirectional_relationships_trigger
  AFTER INSERT OR UPDATE ON article_relationships
  FOR EACH ROW
  WHEN (NEW.bidirectional)
  EXECUTE FUNCTION maintain_bidirectional_relationships();