/*
  # Content Tracking System

  1. New Tables
    - `content_items` - Stores content metadata and tracking information
      - Comprehensive tracking of content lifecycle
      - Rich metadata fields
      - Quality metrics and analytics
      - Link tracking
      - Content status workflow

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Create content_items table
CREATE TABLE IF NOT EXISTS content_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  date_scraped timestamptz NOT NULL DEFAULT now(),
  date_published timestamptz,
  article_title text NOT NULL,
  author text,
  content_category text NOT NULL,
  word_count integer DEFAULT 0,
  main_keywords text[],
  content_status text NOT NULL CHECK (content_status IN ('new', 'reviewed', 'approved', 'published')),
  quality_score integer CHECK (quality_score >= 1 AND quality_score <= 5),
  target_audience text,
  source_authority text,
  key_takeaways text[],
  notes text,
  last_modified_at timestamptz DEFAULT now(),
  content_format text NOT NULL CHECK (content_format IN ('article', 'blog', 'news')),
  meta_description text,
  featured_image_url text,
  internal_links_count integer DEFAULT 0,
  external_links_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX idx_content_items_date_scraped ON content_items(date_scraped DESC);
CREATE INDEX idx_content_items_status ON content_items(content_status);
CREATE INDEX idx_content_items_category ON content_items(content_category);
CREATE INDEX idx_content_items_format ON content_items(content_format);
CREATE INDEX idx_content_items_quality ON content_items(quality_score);

-- Enable RLS
ALTER TABLE content_items ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON content_items
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON content_items
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update last_modified_at
CREATE OR REPLACE FUNCTION update_content_modified_timestamp()
RETURNS trigger AS $$
BEGIN
  NEW.last_modified_at = now();
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for last_modified_at
CREATE TRIGGER update_content_modified_timestamp
  BEFORE UPDATE ON content_items
  FOR EACH ROW
  EXECUTE FUNCTION update_content_modified_timestamp();

-- Create view for content analytics
CREATE OR REPLACE VIEW v_content_analytics AS
SELECT 
  content_category,
  content_format,
  COUNT(*) as total_items,
  AVG(quality_score) as avg_quality_score,
  AVG(word_count) as avg_word_count,
  COUNT(*) FILTER (WHERE content_status = 'published') as published_count,
  COUNT(*) FILTER (WHERE content_status = 'new') as new_count,
  COUNT(*) FILTER (WHERE content_status = 'reviewed') as reviewed_count,
  COUNT(*) FILTER (WHERE content_status = 'approved') as approved_count,
  AVG(internal_links_count) as avg_internal_links,
  AVG(external_links_count) as avg_external_links,
  MIN(date_scraped) as oldest_content,
  MAX(date_scraped) as newest_content
FROM content_items
GROUP BY content_category, content_format;

-- Insert sample data
INSERT INTO content_items (
  url,
  date_scraped,
  date_published,
  article_title,
  author,
  content_category,
  word_count,
  main_keywords,
  content_status,
  quality_score,
  target_audience,
  source_authority,
  key_takeaways,
  notes,
  content_format,
  meta_description,
  featured_image_url,
  internal_links_count,
  external_links_count
) VALUES (
  'https://aws.amazon.com/blogs/database/best-practices-for-amazon-redshift-query-optimization/',
  now(),
  '2025-03-15T14:30:00Z',
  'Best Practices for Amazon Redshift Query Optimization',
  'AWS Database Blog Team',
  'Performance Optimization',
  2500,
  ARRAY['redshift', 'performance', 'optimization', 'query tuning', 'best practices'],
  'published',
  5,
  'Database Administrators, Data Engineers',
  'AWS Official Blog',
  ARRAY[
    'Proper distribution key selection is crucial for performance',
    'Regular VACUUM and ANALYZE maintenance is essential',
    'Use appropriate sort keys for common query patterns'
  ],
  'Comprehensive guide with practical examples',
  'article',
  'Learn essential best practices for optimizing Amazon Redshift query performance, including distribution strategies, sort keys, and maintenance procedures.',
  'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
  8,
  12
);

-- Create function to calculate content quality metrics
CREATE OR REPLACE FUNCTION calculate_content_quality(
  word_count integer,
  internal_links integer,
  external_links integer,
  has_featured_image boolean,
  has_meta_description boolean
) RETURNS integer AS $$
DECLARE
  score integer := 3; -- Start with middle score
BEGIN
  -- Word count scoring
  IF word_count >= 2000 THEN
    score := score + 1;
  ELSIF word_count < 500 THEN
    score := score - 1;
  END IF;

  -- Links scoring
  IF internal_links + external_links >= 10 THEN
    score := score + 1;
  END IF;

  -- Image and meta description
  IF has_featured_image AND has_meta_description THEN
    score := score + 1;
  END IF;

  -- Ensure score stays within 1-5 range
  RETURN GREATEST(1, LEAST(5, score));
END;
$$ LANGUAGE plpgsql;

-- Create function to update content quality score
CREATE OR REPLACE FUNCTION update_content_quality_score()
RETURNS trigger AS $$
BEGIN
  NEW.quality_score := calculate_content_quality(
    NEW.word_count,
    NEW.internal_links_count,
    NEW.external_links_count,
    NEW.featured_image_url IS NOT NULL,
    NEW.meta_description IS NOT NULL
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for quality score updates
CREATE TRIGGER update_content_quality_score
  BEFORE INSERT OR UPDATE OF word_count, internal_links_count, external_links_count, featured_image_url, meta_description
  ON content_items
  FOR EACH ROW
  EXECUTE FUNCTION update_content_quality_score();