/*
  # News Aggregation System Schema

  1. New Tables
    - `news_sources`
      - Configuration for news sources to scrape
      - Includes scheduling and retry settings
    - `news_articles`
      - Stores aggregated news articles
      - Includes versioning and validation status
    - `news_article_versions`
      - Historical versions of articles
      - Tracks changes and updates
    - `news_collection_logs`
      - Detailed logging of collection runs
      - Tracks successes, failures, and metrics
    - `news_alerts`
      - System alerts and notifications
      - Tracks collection failures and data quality issues

  2. Security
    - Enable RLS on all tables
    - Add policies for data access control

  3. Indexes
    - Optimized for common query patterns
    - Support efficient deduplication checks
*/

-- Create news aggregation schema
CREATE SCHEMA IF NOT EXISTS news_aggregation;

-- News Sources Table
CREATE TABLE IF NOT EXISTS news_aggregation.news_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text NOT NULL,
  source_type text NOT NULL CHECK (source_type IN ('rss', 'web', 'api')),
  active boolean DEFAULT true,
  schedule_time time NOT NULL,
  schedule_timezone text NOT NULL DEFAULT 'UTC',
  retry_attempts int NOT NULL DEFAULT 3,
  retry_delay_minutes int NOT NULL DEFAULT 15,
  last_collection_at timestamptz,
  next_collection_at timestamptz,
  selector_config jsonb,
  headers jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_news_sources_url ON news_aggregation.news_sources(url);

-- News Articles Table
CREATE TABLE IF NOT EXISTS news_aggregation.news_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid NOT NULL REFERENCES news_aggregation.news_sources(id),
  headline text NOT NULL,
  url text NOT NULL,
  publication_date timestamptz NOT NULL,
  source_name text NOT NULL,
  content text NOT NULL,
  content_html text,
  category text,
  authors text[],
  tags text[],
  image_url text,
  engagement_metrics jsonb,
  validation_status text NOT NULL DEFAULT 'pending' CHECK (validation_status IN ('pending', 'valid', 'invalid')),
  validation_errors text[],
  current_version int NOT NULL DEFAULT 1,
  hash_signature text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT unique_article_url UNIQUE (url)
);

CREATE INDEX idx_news_articles_publication_date ON news_aggregation.news_articles(publication_date DESC);
CREATE INDEX idx_news_articles_category ON news_aggregation.news_articles(category);
CREATE INDEX idx_news_articles_validation_status ON news_aggregation.news_articles(validation_status);
CREATE INDEX idx_news_articles_hash ON news_aggregation.news_articles(hash_signature);

-- Article Versions Table
CREATE TABLE IF NOT EXISTS news_aggregation.news_article_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id uuid NOT NULL REFERENCES news_aggregation.news_articles(id),
  version_number int NOT NULL,
  headline text NOT NULL,
  content text NOT NULL,
  content_html text,
  category text,
  authors text[],
  tags text[],
  changed_fields text[],
  change_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT unique_article_version UNIQUE (article_id, version_number)
);

CREATE INDEX idx_article_versions_article_id ON news_aggregation.news_article_versions(article_id);

-- Collection Logs Table
CREATE TABLE IF NOT EXISTS news_aggregation.news_collection_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid NOT NULL REFERENCES news_aggregation.news_sources(id),
  start_time timestamptz NOT NULL DEFAULT now(),
  end_time timestamptz,
  status text NOT NULL CHECK (status IN ('in_progress', 'completed', 'failed')),
  articles_found int NOT NULL DEFAULT 0,
  articles_processed int NOT NULL DEFAULT 0,
  articles_failed int NOT NULL DEFAULT 0,
  error_message text,
  retry_count int NOT NULL DEFAULT 0,
  performance_metrics jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_collection_logs_source_id ON news_aggregation.news_collection_logs(source_id);
CREATE INDEX idx_collection_logs_status ON news_aggregation.news_collection_logs(status);

-- Alerts Table
CREATE TABLE IF NOT EXISTS news_aggregation.news_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_type text NOT NULL CHECK (alert_type IN ('collection_failure', 'validation_failure', 'data_quality')),
  severity text NOT NULL CHECK (severity IN ('info', 'warning', 'error', 'critical')),
  source_id uuid REFERENCES news_aggregation.news_sources(id),
  message text NOT NULL,
  details jsonb,
  resolved boolean NOT NULL DEFAULT false,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_news_alerts_unresolved ON news_aggregation.news_alerts(alert_type) WHERE NOT resolved;

-- Enable Row Level Security
ALTER TABLE news_aggregation.news_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_aggregation.news_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_aggregation.news_article_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_aggregation.news_collection_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_aggregation.news_alerts ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Public news articles are viewable by everyone"
  ON news_aggregation.news_articles
  FOR SELECT
  TO public
  USING (validation_status = 'valid');

CREATE POLICY "Admins can manage news sources"
  ON news_aggregation.news_sources
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@admin%')
  WITH CHECK (auth.jwt() ->> 'email' LIKE '%@admin%');

-- Create functions for news collection
CREATE OR REPLACE FUNCTION news_aggregation.schedule_next_collection(source_id uuid)
RETURNS timestamptz AS $$
DECLARE
  source_record news_aggregation.news_sources%ROWTYPE;
BEGIN
  SELECT * INTO source_record
  FROM news_aggregation.news_sources
  WHERE id = source_id;

  RETURN timezone(source_record.schedule_timezone,
    date_trunc('day', now()) +
    source_record.schedule_time +
    CASE
      WHEN (now() AT TIME ZONE source_record.schedule_timezone)::time > source_record.schedule_time
      THEN interval '1 day'
      ELSE interval '0'
    END
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to generate article hash
CREATE OR REPLACE FUNCTION news_aggregation.generate_article_hash(
  url text,
  headline text,
  content text
) RETURNS text AS $$
BEGIN
  RETURN encode(
    sha256(
      CONCAT(
        COALESCE(url, ''),
        COALESCE(headline, ''),
        COALESCE(substring(content, 1, 1000), '')
      )::bytea
    ),
    'hex'
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to check for duplicate articles
CREATE OR REPLACE FUNCTION news_aggregation.is_duplicate_article(
  url text,
  headline text,
  content text
) RETURNS boolean AS $$
DECLARE
  hash_value text;
BEGIN
  hash_value := news_aggregation.generate_article_hash(url, headline, content);
  
  RETURN EXISTS (
    SELECT 1 
    FROM news_aggregation.news_articles 
    WHERE hash_signature = hash_value
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to version article changes
CREATE OR REPLACE FUNCTION news_aggregation.version_article_changes()
RETURNS trigger AS $$
BEGIN
  IF (TG_OP = 'UPDATE') THEN
    -- Determine which fields changed
    WITH changed_fields AS (
      SELECT array_agg(field) as fields
      FROM (
        SELECT unnest(ARRAY['headline', 'content', 'content_html', 'category', 'authors', 'tags']) as field
        WHERE OLD.headline != NEW.headline
           OR OLD.content != NEW.content
           OR OLD.content_html IS DISTINCT FROM NEW.content_html
           OR OLD.category IS DISTINCT FROM NEW.category
           OR OLD.authors IS DISTINCT FROM NEW.authors
           OR OLD.tags IS DISTINCT FROM NEW.tags
      ) f
    )
    INSERT INTO news_aggregation.news_article_versions (
      article_id,
      version_number,
      headline,
      content,
      content_html,
      category,
      authors,
      tags,
      changed_fields,
      change_reason
    )
    SELECT
      NEW.id,
      NEW.current_version,
      NEW.headline,
      NEW.content,
      NEW.content_html,
      NEW.category,
      NEW.authors,
      NEW.tags,
      cf.fields,
      'Content update'
    FROM changed_fields cf;
    
    NEW.current_version := OLD.current_version + 1;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for article versioning
CREATE TRIGGER version_article_changes
  BEFORE UPDATE ON news_aggregation.news_articles
  FOR EACH ROW
  WHEN (OLD.* IS DISTINCT FROM NEW.*)
  EXECUTE FUNCTION news_aggregation.version_article_changes();

-- Insert initial news sources
INSERT INTO news_aggregation.news_sources 
(name, url, source_type, schedule_time, schedule_timezone, selector_config) 
VALUES 
(
  'AWS What''s New - Redshift',
  'https://aws.amazon.com/about-aws/whats-new/recent/redshift/',
  'web',
  '00:00:00',
  'UTC',
  '{"article_selector": ".lb-content-item", "title_selector": ".lb-title", "date_selector": ".lb-date"}'
),
(
  'AWS Database Blog - Redshift',
  'https://aws.amazon.com/blogs/database/category/database/amazon-redshift/',
  'web',
  '01:00:00',
  'UTC',
  '{"article_selector": ".blog-post", "title_selector": ".blog-post-title", "date_selector": ".blog-post-date"}'
),
(
  'AWS Big Data Blog - Redshift',
  'https://aws.amazon.com/blogs/big-data/tag/amazon-redshift/',
  'web',
  '02:00:00',
  'UTC',
  '{"article_selector": ".blog-post", "title_selector": ".blog-post-title", "date_selector": ".blog-post-date"}'
);

-- Create backup table for disaster recovery
CREATE TABLE IF NOT EXISTS news_aggregation.news_articles_backup (
  LIKE news_aggregation.news_articles INCLUDING ALL
);

-- Create function to backup articles daily
CREATE OR REPLACE FUNCTION news_aggregation.backup_articles()
RETURNS void AS $$
BEGIN
  INSERT INTO news_aggregation.news_articles_backup
  SELECT *
  FROM news_aggregation.news_articles
  WHERE created_at >= current_date - interval '1 day'
  ON CONFLICT (id) DO NOTHING;
END;
$$ LANGUAGE plpgsql;