/*
  # Create Redshift Scripts Library

  1. New Tables
    - `redshift_scripts` - Stores SQL scripts and utilities for Redshift
      - `id` (uuid, primary key)
      - `title` (text, not null)
      - `description` (text, not null)
      - `script_content` (text, not null)
      - `original_url` (text)
      - `category` (text, not null)
      - `script_type` (text, not null)
      - `published_at` (date)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `tags` (text array)
      - `formatted_content` (text)
      - `author` (text)
      - `views` (integer)
      - `downloads` (integer)
      - `status` (text)
  
  2. Security
    - Enable RLS on `redshift_scripts` table
    - Add policy for public users to read published scripts
    - Add policy for authenticated users to manage scripts
*/

-- Create redshift_scripts table
CREATE TABLE IF NOT EXISTS redshift_scripts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  script_content text NOT NULL,
  original_url text,
  category text NOT NULL,
  script_type text NOT NULL,
  published_at date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tags text[],
  formatted_content text,
  author text,
  views integer DEFAULT 0,
  downloads integer DEFAULT 0,
  status text DEFAULT 'published'
);

-- Create script_categories table for predefined categories
CREATE TABLE IF NOT EXISTS script_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create script_types table for predefined script types
CREATE TABLE IF NOT EXISTS script_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create script_comments table for user comments
CREATE TABLE IF NOT EXISTS script_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create script_ratings table for user ratings
CREATE TABLE IF NOT EXISTS script_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  UNIQUE(script_id, user_id)
);

-- Create script_views table to track view history
CREATE TABLE IF NOT EXISTS script_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  viewed_at timestamptz DEFAULT now(),
  ip_address text
);

-- Create script_downloads table to track download history
CREATE TABLE IF NOT EXISTS script_downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  downloaded_at timestamptz DEFAULT now(),
  ip_address text
);

-- Enable RLS
ALTER TABLE redshift_scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_downloads ENABLE ROW LEVEL SECURITY;

-- Create policies for redshift_scripts
CREATE POLICY "Enable public read access for published scripts"
  ON redshift_scripts
  FOR SELECT
  TO public
  USING (status = 'published');

CREATE POLICY "Enable authenticated users to manage scripts"
  ON redshift_scripts
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for script_categories
CREATE POLICY "Enable public read access for script_categories"
  ON script_categories
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage script_categories"
  ON script_categories
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for script_types
CREATE POLICY "Enable public read access for script_types"
  ON script_types
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage script_types"
  ON script_types
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for script_comments
CREATE POLICY "Enable public read access for script_comments"
  ON script_comments
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage their own comments"
  ON script_comments
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Enable admins to manage all comments"
  ON script_comments
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND auth.users.email LIKE '%@admin.com'
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM auth.users
    WHERE auth.users.id = auth.uid()
    AND auth.users.email LIKE '%@admin.com'
  ));

-- Create policies for script_ratings
CREATE POLICY "Enable public read access for script_ratings"
  ON script_ratings
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage their own ratings"
  ON script_ratings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policies for script_views
CREATE POLICY "Enable authenticated users to view script_views"
  ON script_views
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable public to insert script_views"
  ON script_views
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policies for script_downloads
CREATE POLICY "Enable authenticated users to view script_downloads"
  ON script_downloads
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable public to insert script_downloads"
  ON script_downloads
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Insert default categories
INSERT INTO script_categories (name, description)
VALUES 
  ('DBA Helper Queries', 'Queries to assist database administrators with common tasks'),
  ('Diagnostics', 'Scripts for diagnosing performance issues and errors'),
  ('Monitoring', 'Scripts for monitoring database health and performance'),
  ('Optimization', 'Scripts for optimizing database performance'),
  ('Security', 'Scripts for managing database security and access control'),
  ('Maintenance', 'Scripts for routine database maintenance tasks'),
  ('Utilities', 'Utility scripts for various database operations')
ON CONFLICT (name) DO NOTHING;

-- Insert default script types
INSERT INTO script_types (name, description)
VALUES 
  ('SQL', 'Standard SQL queries'),
  ('PL/pgSQL', 'PostgreSQL procedural language'),
  ('Python', 'Python scripts for database operations'),
  ('Shell', 'Shell scripts for database operations'),
  ('Other', 'Other script types')
ON CONFLICT (name) DO NOTHING;

-- Create a view for script details with ratings
CREATE OR REPLACE VIEW script_details AS
SELECT 
  s.id,
  s.title,
  s.description,
  s.script_content,
  s.original_url,
  s.category,
  s.script_type,
  s.published_at,
  s.created_at,
  s.updated_at,
  s.tags,
  s.formatted_content,
  s.author,
  s.views,
  s.downloads,
  s.status,
  COALESCE(AVG(r.rating), 0) as average_rating,
  COUNT(r.id) as rating_count,
  COUNT(c.id) as comment_count
FROM 
  redshift_scripts s
LEFT JOIN 
  script_ratings r ON s.id = r.script_id
LEFT JOIN 
  script_comments c ON s.id = c.script_id
GROUP BY 
  s.id;

-- Create a function to increment view count
CREATE OR REPLACE FUNCTION increment_script_view(script_id_param uuid, user_id_param uuid DEFAULT NULL, ip_address_param text DEFAULT NULL)
RETURNS void AS $$
BEGIN
  -- Insert view record
  INSERT INTO script_views (script_id, user_id, ip_address)
  VALUES (script_id_param, user_id_param, ip_address_param);
  
  -- Update view count
  UPDATE redshift_scripts
  SET views = views + 1
  WHERE id = script_id_param;
END;
$$ LANGUAGE plpgsql;

-- Create a function to increment download count
CREATE OR REPLACE FUNCTION increment_script_download(script_id_param uuid, user_id_param uuid DEFAULT NULL, ip_address_param text DEFAULT NULL)
RETURNS void AS $$
BEGIN
  -- Insert download record
  INSERT INTO script_downloads (script_id, user_id, ip_address)
  VALUES (script_id_param, user_id_param, ip_address_param);
  
  -- Update download count
  UPDATE redshift_scripts
  SET downloads = downloads + 1
  WHERE id = script_id_param;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get related scripts
CREATE OR REPLACE FUNCTION get_related_scripts(script_id_param uuid, limit_param integer DEFAULT 5)
RETURNS SETOF redshift_scripts AS $$
BEGIN
  RETURN QUERY
  SELECT s.*
  FROM redshift_scripts s
  JOIN (
    SELECT category, script_type
    FROM redshift_scripts
    WHERE id = script_id_param
  ) as source ON s.category = source.category OR s.script_type = source.script_type
  WHERE s.id != script_id_param
  AND s.status = 'published'
  ORDER BY s.views DESC
  LIMIT limit_param;
END;
$$ LANGUAGE plpgsql;