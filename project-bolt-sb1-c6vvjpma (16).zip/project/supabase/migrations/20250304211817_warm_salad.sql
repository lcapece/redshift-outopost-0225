-- Create staging table for SVV data imports
CREATE TABLE IF NOT EXISTS svv_data_staging (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL,
  schema_name text NOT NULL,
  table_name text NOT NULL,
  encoded boolean DEFAULT false,
  diststyle text NOT NULL DEFAULT 'AUTO',
  sortkey1 text,
  sortkey1_enc text,
  sortkey_num integer DEFAULT 0,
  size_gb numeric DEFAULT 0,
  pct_empty numeric DEFAULT 0,
  unsorted_pct numeric DEFAULT 0,
  stats_off numeric DEFAULT 0,
  tbl_rows bigint DEFAULT 0,
  skew_sortkey1 numeric DEFAULT 0,
  skew_rows numeric DEFAULT 0,
  estimated_visible_rows bigint DEFAULT 0,
  risk_event text,
  created_by_user uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE svv_data_staging ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable access for authenticated users"
  ON svv_data_staging
  FOR ALL
  TO authenticated
  USING (auth.uid() = created_by_user)
  WITH CHECK (auth.uid() = created_by_user);

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS upsert_svv_data(uuid);

-- Create upsert function with consistent return type
CREATE OR REPLACE FUNCTION upsert_svv_data(user_id uuid)
RETURNS TABLE (
  original_count integer,
  inserted_count integer,
  updated_count integer,
  final_count integer
) LANGUAGE plpgsql AS $$
DECLARE
  v_original_count integer;
  v_inserted_count integer;
  v_updated_count integer;
  v_final_count integer;
BEGIN
  -- Get original count
  SELECT COUNT(*) INTO v_original_count
  FROM imported_svv_data
  WHERE created_by_user = user_id;

  -- Insert new records
  WITH new_records AS (
    INSERT INTO imported_svv_data (
      database_name, schema_name, table_name, encoded, diststyle,
      sortkey1, sortkey1_enc, sortkey_num, size_gb, pct_empty,
      unsorted_pct, stats_off, tbl_rows, skew_sortkey1, skew_rows,
      estimated_visible_rows, risk_event, created_by_user
    )
    SELECT 
      s.database_name, s.schema_name, s.table_name, s.encoded, s.diststyle,
      s.sortkey1, s.sortkey1_enc, s.sortkey_num, s.size_gb, s.pct_empty,
      s.unsorted_pct, s.stats_off, s.tbl_rows, s.skew_sortkey1, s.skew_rows,
      s.estimated_visible_rows, s.risk_event, s.created_by_user
    FROM svv_data_staging s
    WHERE s.created_by_user = user_id
    AND NOT EXISTS (
      SELECT 1 FROM imported_svv_data i
      WHERE i.created_by_user = user_id
      AND i.database_name = s.database_name
      AND i.schema_name = s.schema_name
      AND i.table_name = s.table_name
    )
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_inserted_count FROM new_records;

  -- Update existing records
  WITH updated_records AS (
    UPDATE imported_svv_data i
    SET
      encoded = s.encoded,
      diststyle = s.diststyle,
      sortkey1 = s.sortkey1,
      sortkey1_enc = s.sortkey1_enc,
      sortkey_num = s.sortkey_num,
      size_gb = s.size_gb,
      pct_empty = s.pct_empty,
      unsorted_pct = s.unsorted_pct,
      stats_off = s.stats_off,
      tbl_rows = s.tbl_rows,
      skew_sortkey1 = s.skew_sortkey1,
      skew_rows = s.skew_rows,
      estimated_visible_rows = s.estimated_visible_rows,
      risk_event = s.risk_event,
      updated_at = now()
    FROM svv_data_staging s
    WHERE i.created_by_user = user_id
    AND i.database_name = s.database_name
    AND i.schema_name = s.schema_name
    AND i.table_name = s.table_name
    AND s.created_by_user = user_id
    AND (
      i.encoded != s.encoded OR
      i.diststyle != s.diststyle OR
      COALESCE(i.sortkey1, '') != COALESCE(s.sortkey1, '') OR
      COALESCE(i.sortkey1_enc, '') != COALESCE(s.sortkey1_enc, '') OR
      i.sortkey_num != s.sortkey_num OR
      i.size_gb != s.size_gb OR
      i.pct_empty != s.pct_empty OR
      i.unsorted_pct != s.unsorted_pct OR
      i.stats_off != s.stats_off OR
      i.tbl_rows != s.tbl_rows OR
      i.skew_sortkey1 != s.skew_sortkey1 OR
      i.skew_rows != s.skew_rows OR
      i.estimated_visible_rows != s.estimated_visible_rows OR
      COALESCE(i.risk_event, '') != COALESCE(s.risk_event, '')
    )
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_updated_count FROM updated_records;

  -- Get final count
  SELECT COUNT(*) INTO v_final_count
  FROM imported_svv_data
  WHERE created_by_user = user_id;

  -- Clean up staging table
  DELETE FROM svv_data_staging WHERE created_by_user = user_id;

  RETURN QUERY SELECT 
    v_original_count,
    v_inserted_count,
    v_updated_count,
    v_final_count;
END;
$$;