/*
  # Create news tables and policies

  1. New Tables
    - `redshift_news` - Stores news articles
    - `news_sources` - Stores news source configurations
    - `news_collection_logs` - Tracks news collection activities
  2. Security
    - Enable RLS on all tables
    - Add policies for public and authenticated access
  3. Initial Data
    - Add initial news sources
*/

-- Check if redshift_news table already exists
DO $$ 
BEGIN
  IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'redshift_news') THEN
    -- Table exists, do nothing
    RAISE NOTICE 'Table redshift_news already exists';
  ELSE
    -- Create redshift_news table with enhanced fields
    CREATE TABLE redshift_news (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      title text NOT NULL,
      "originalTitle" text,
      summary text NOT NULL,
      content text NOT NULL,
      url text NOT NULL,
      source text NOT NULL,
      "publishedAt" text NOT NULL,
      "imageUrl" text,
      "secondaryImageUrl" text,
      "relatedArticles" jsonb,
      status text DEFAULT 'published',
      tags text[],
      "wordCount" integer,
      processed boolean DEFAULT false,
      "createdAt" timestamptz DEFAULT now()
    );
  END IF;
END $$;

-- Create news_sources table if it doesn't exist
CREATE TABLE IF NOT EXISTS news_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text NOT NULL,
  type text NOT NULL,
  selector text,
  active boolean DEFAULT true,
  "createdAt" timestamptz DEFAULT now(),
  "lastScraped" timestamptz
);

-- Create news_collection_logs table if it doesn't exist
CREATE TABLE IF NOT EXISTS news_collection_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  "sourceId" uuid REFERENCES news_sources(id),
  "articlesFound" integer,
  "articlesProcessed" integer,
  "articlesAdded" integer,
  "startTime" timestamptz NOT NULL,
  "endTime" timestamptz NOT NULL,
  status text NOT NULL,
  error text,
  "createdAt" timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE redshift_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE news_collection_logs ENABLE ROW LEVEL SECURITY;

-- Create a simple policy for redshift_news
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'redshift_news' AND policyname = 'Enable public access to redshift_news'
  ) THEN
    EXECUTE 'CREATE POLICY "Enable public access to redshift_news" ON redshift_news FOR SELECT TO public USING (true)';
  END IF;
END $$;

-- Create policy for authenticated users to manage all articles
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'redshift_news' AND policyname = 'Enable authenticated users to manage all articles'
  ) THEN
    EXECUTE 'CREATE POLICY "Enable authenticated users to manage all articles" ON redshift_news FOR ALL TO authenticated USING (true) WITH CHECK (true)';
  END IF;
END $$;

-- Create policies for news_sources
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'news_sources' AND policyname = 'Enable authenticated users to manage news sources'
  ) THEN
    EXECUTE 'CREATE POLICY "Enable authenticated users to manage news sources" ON news_sources FOR ALL TO authenticated USING (true) WITH CHECK (true)';
  END IF;
END $$;

-- Create policies for news_collection_logs
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'news_collection_logs' AND policyname = 'Enable authenticated users to manage collection logs'
  ) THEN
    EXECUTE 'CREATE POLICY "Enable authenticated users to manage collection logs" ON news_collection_logs FOR ALL TO authenticated USING (true) WITH CHECK (true)';
  END IF;
END $$;

-- Insert initial news sources if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT FROM news_sources WHERE name = 'AWS What''s New') THEN
    INSERT INTO news_sources (name, url, type, selector, active)
    VALUES ('AWS What''s New', 'https://aws.amazon.com/about-aws/whats-new/recent/redshift/', 'web', '.lb-content-item', true);
  END IF;
  
  IF NOT EXISTS (SELECT FROM news_sources WHERE name = 'AWS Database Blog') THEN
    INSERT INTO news_sources (name, url, type, selector, active)
    VALUES ('AWS Database Blog', 'https://aws.amazon.com/blogs/database/category/database/amazon-redshift/', 'web', '.blog-post', true);
  END IF;
  
  IF NOT EXISTS (SELECT FROM news_sources WHERE name = 'AWS Big Data Blog') THEN
    INSERT INTO news_sources (name, url, type, selector, active)
    VALUES ('AWS Big Data Blog', 'https://aws.amazon.com/blogs/big-data/tag/amazon-redshift/', 'web', '.blog-post', true);
  END IF;
END $$;

-- Now create the status-specific policy, but only if the table exists and has the status column
DO $$ 
BEGIN
  -- First check if the table exists and has the status column
  IF EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'redshift_news' AND column_name = 'status'
  ) THEN
    -- Drop the temporary policy if it exists
    DROP POLICY IF EXISTS "Enable public access to redshift_news" ON redshift_news;
    
    -- Create the proper policy using the status column
    IF NOT EXISTS (
      SELECT FROM pg_policies 
      WHERE tablename = 'redshift_news' AND policyname = 'Enable public read access for published articles'
    ) THEN
      EXECUTE 'CREATE POLICY "Enable public read access for published articles" ON redshift_news FOR SELECT TO public USING (status = ''published'')';
    END IF;
  END IF;
END $$;