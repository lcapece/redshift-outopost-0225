-- Drop existing objects if they exist
DROP VIEW IF EXISTS v_svv_table_info;
DROP FUNCTION IF EXISTS validate_svv_table_info(jsonb);
DROP FUNCTION IF EXISTS get_table_metrics(text, text);
DROP TABLE IF EXISTS imported_svv_data;

-- Create imported_svv_data table
CREATE TABLE imported_svv_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL,
  schema_name text NOT NULL,
  table_name text NOT NULL,
  encoded boolean NOT NULL,
  diststyle text NOT NULL,
  sortkey1 text,
  sortkey1_enc text,
  sortkey_num integer NOT NULL,
  size_gb numeric NOT NULL,
  pct_empty numeric NOT NULL,
  unsorted_pct numeric NOT NULL,
  stats_off numeric NOT NULL,
  tbl_rows bigint NOT NULL,
  skew_sortkey1 numeric NOT NULL,
  skew_rows numeric NOT NULL,
  estimated_visible_rows bigint NOT NULL,
  risk_event text,
  created_by_user uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Create view matching SVV_TABLE_INFO structure
CREATE VIEW v_svv_table_info AS
SELECT
  database_name AS dbname,
  schema_name AS schemaname,
  table_name AS tablename,
  encoded,
  diststyle,
  sortkey1,
  sortkey1_enc,
  sortkey_num,
  size_gb,
  pct_empty,
  unsorted_pct,
  stats_off,
  tbl_rows,
  skew_sortkey1,
  skew_rows,
  estimated_visible_rows,
  risk_event
FROM
  imported_svv_data;

-- Create function to validate SVV_TABLE_INFO data
CREATE FUNCTION validate_svv_table_info(
  data jsonb
) RETURNS TABLE (
  is_valid boolean,
  error_message text
) AS $$
BEGIN
  -- Check required columns
  IF NOT (
    data ? 'database_name' AND
    data ? 'schema_name' AND
    data ? 'table_name' AND
    data ? 'encoded' AND
    data ? 'diststyle' AND
    data ? 'size_gb' AND
    data ? 'tbl_rows'
  ) THEN
    RETURN QUERY SELECT 
      false,
      'Missing required columns. Required: database_name, schema_name, table_name, encoded, diststyle, size_gb, tbl_rows';
    RETURN;
  END IF;

  -- Validate data types
  IF NOT (
    (data->>'size_gb')::numeric >= 0 AND
    (data->>'tbl_rows')::bigint >= 0
  ) THEN
    RETURN QUERY SELECT 
      false,
      'Invalid numeric values. size_gb and tbl_rows must be non-negative numbers';
    RETURN;
  END IF;

  -- Data looks valid
  RETURN QUERY SELECT true, null::text;
END;
$$ LANGUAGE plpgsql;

-- Enable RLS on imported_svv_data
ALTER TABLE imported_svv_data ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON imported_svv_data
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert for authenticated users"
  ON imported_svv_data
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by_user);

CREATE POLICY "Enable update for data owners"
  ON imported_svv_data
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by_user)
  WITH CHECK (auth.uid() = created_by_user);

-- Create helper function to get table metrics
CREATE FUNCTION get_table_metrics(
  schema_name text,
  table_name text
) RETURNS TABLE (
  metric_name text,
  metric_value text,
  metric_status text
) AS $$
BEGIN
  RETURN QUERY
  WITH metrics AS (
    SELECT
      database_name,
      schema_name,
      table_name,
      size_gb,
      tbl_rows,
      pct_empty,
      unsorted_pct,
      stats_off,
      skew_sortkey1,
      skew_rows
    FROM imported_svv_data
    WHERE schema_name = schema_name
    AND table_name = table_name
  )
  SELECT 'Size (GB)'::text,
         size_gb::text,
         CASE 
           WHEN size_gb > 100 THEN 'warning'
           WHEN size_gb > 500 THEN 'critical'
           ELSE 'ok'
         END
  FROM metrics
  UNION ALL
  SELECT 'Row Count',
         tbl_rows::text,
         'info'
  FROM metrics
  UNION ALL
  SELECT 'Empty Space %',
         pct_empty::text,
         CASE
           WHEN pct_empty > 20 THEN 'warning'
           WHEN pct_empty > 40 THEN 'critical'
           ELSE 'ok'
         END
  FROM metrics
  UNION ALL
  SELECT 'Unsorted %',
         unsorted_pct::text,
         CASE
           WHEN unsorted_pct > 20 THEN 'warning'
           WHEN unsorted_pct > 50 THEN 'critical'
           ELSE 'ok'
         END
  FROM metrics
  UNION ALL
  SELECT 'Stats Accuracy',
         (100 - stats_off)::text || '%',
         CASE
           WHEN stats_off > 20 THEN 'warning'
           WHEN stats_off > 50 THEN 'critical'
           ELSE 'ok'
         END
  FROM metrics;
END;
$$ LANGUAGE plpgsql;

-- Create indexes for better performance
CREATE INDEX idx_imported_svv_data_schema_table 
  ON imported_svv_data(schema_name, table_name);

CREATE INDEX idx_imported_svv_data_created 
  ON imported_svv_data(created_at);

CREATE INDEX idx_imported_svv_data_user
  ON imported_svv_data(created_by_user);