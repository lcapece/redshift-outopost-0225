/*
  # Add status column to news_sources table

  1. Changes
    - Add status column to news_sources table
    - Set default value to 'pending'
    - Update existing rows
    - Add check constraint for valid status values

  2. Security
    - Maintain existing RLS policies
*/

-- Add status column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'news_sources' AND column_name = 'status'
  ) THEN
    ALTER TABLE news_sources ADD COLUMN status text NOT NULL DEFAULT 'pending';
    
    -- Add check constraint for valid status values
    ALTER TABLE news_sources 
      ADD CONSTRAINT news_sources_status_check 
      CHECK (status IN ('pending', 'completed', 'failed'));
  END IF;
END $$;

-- Update any existing rows to have a valid status
UPDATE news_sources 
SET status = 'pending' 
WHERE status IS NULL OR status NOT IN ('pending', 'completed', 'failed');

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_news_sources_status ON news_sources(status);