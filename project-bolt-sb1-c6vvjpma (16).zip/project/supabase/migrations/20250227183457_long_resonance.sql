/*
  # Create Redshift Scripts Library

  1. New Tables
    - `redshift_scripts` - Main table for storing scripts
    - `script_categories` - Predefined script categories
    - `script_types` - Predefined script types
    - `script_comments` - User comments on scripts
    - `script_ratings` - User ratings for scripts
    - `script_views` - Track script view history
    - `script_downloads` - Track script download history
  
  2. Security
    - Enable RLS on all tables
    - Add policies for public and authenticated access
  
  3. Functions
    - Add helper functions for view/download tracking
    - Add function to get related scripts
*/

-- Create redshift_scripts table if it doesn't exist
CREATE TABLE IF NOT EXISTS redshift_scripts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  script_content text NOT NULL,
  original_url text,
  category text NOT NULL,
  script_type text NOT NULL,
  published_at date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tags text[],
  formatted_content text,
  author text,
  views integer DEFAULT 0,
  downloads integer DEFAULT 0,
  status text DEFAULT 'published'
);

-- Create script_categories table for predefined categories
CREATE TABLE IF NOT EXISTS script_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create script_types table for predefined script types
CREATE TABLE IF NOT EXISTS script_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz DEFAULT now()
);

-- Create script_comments table for user comments
CREATE TABLE IF NOT EXISTS script_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  comment text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create script_ratings table for user ratings
CREATE TABLE IF NOT EXISTS script_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  UNIQUE(script_id, user_id)
);

-- Create script_views table to track view history
CREATE TABLE IF NOT EXISTS script_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  viewed_at timestamptz DEFAULT now(),
  ip_address text
);

-- Create script_downloads table to track download history
CREATE TABLE IF NOT EXISTS script_downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES redshift_scripts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  downloaded_at timestamptz DEFAULT now(),
  ip_address text
);

-- Enable RLS
ALTER TABLE redshift_scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_downloads ENABLE ROW LEVEL SECURITY;

-- Create policies for redshift_scripts (check if they exist first)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'redshift_scripts' AND policyname = 'Enable public read access for published scripts'
  ) THEN
    CREATE POLICY "Enable public read access for published scripts"
      ON redshift_scripts
      FOR SELECT
      TO public
      USING (status = 'published');
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'redshift_scripts' AND policyname = 'Enable authenticated users to manage scripts'
  ) THEN
    CREATE POLICY "Enable authenticated users to manage scripts"
      ON redshift_scripts
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for script_categories
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_categories' AND policyname = 'Enable public read access for script_categories'
  ) THEN
    CREATE POLICY "Enable public read access for script_categories"
      ON script_categories
      FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_categories' AND policyname = 'Enable authenticated users to manage script_categories'
  ) THEN
    CREATE POLICY "Enable authenticated users to manage script_categories"
      ON script_categories
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for script_types
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_types' AND policyname = 'Enable public read access for script_types'
  ) THEN
    CREATE POLICY "Enable public read access for script_types"
      ON script_types
      FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_types' AND policyname = 'Enable authenticated users to manage script_types'
  ) THEN
    CREATE POLICY "Enable authenticated users to manage script_types"
      ON script_types
      FOR ALL
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for script_comments
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_comments' AND policyname = 'Enable public read access for script_comments'
  ) THEN
    CREATE POLICY "Enable public read access for script_comments"
      ON script_comments
      FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_comments' AND policyname = 'Enable authenticated users to manage their own comments'
  ) THEN
    CREATE POLICY "Enable authenticated users to manage their own comments"
      ON script_comments
      FOR ALL
      TO authenticated
      USING (auth.uid() = user_id)
      WITH CHECK (auth.uid() = user_id);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_comments' AND policyname = 'Enable admins to manage all comments'
  ) THEN
    CREATE POLICY "Enable admins to manage all comments"
      ON script_comments
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM auth.users
        WHERE auth.users.id = auth.uid()
        AND auth.users.email LIKE '%@admin.com'
      ))
      WITH CHECK (EXISTS (
        SELECT 1 FROM auth.users
        WHERE auth.users.id = auth.uid()
        AND auth.users.email LIKE '%@admin.com'
      ));
  END IF;
END $$;

-- Create policies for script_ratings
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_ratings' AND policyname = 'Enable public read access for script_ratings'
  ) THEN
    CREATE POLICY "Enable public read access for script_ratings"
      ON script_ratings
      FOR SELECT
      TO public
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_ratings' AND policyname = 'Enable authenticated users to manage their own ratings'
  ) THEN
    CREATE POLICY "Enable authenticated users to manage their own ratings"
      ON script_ratings
      FOR ALL
      TO authenticated
      USING (auth.uid() = user_id)
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

-- Create policies for script_views
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_views' AND policyname = 'Enable authenticated users to view script_views'
  ) THEN
    CREATE POLICY "Enable authenticated users to view script_views"
      ON script_views
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_views' AND policyname = 'Enable public to insert script_views'
  ) THEN
    CREATE POLICY "Enable public to insert script_views"
      ON script_views
      FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;
END $$;

-- Create policies for script_downloads
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_downloads' AND policyname = 'Enable authenticated users to view script_downloads'
  ) THEN
    CREATE POLICY "Enable authenticated users to view script_downloads"
      ON script_downloads
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'script_downloads' AND policyname = 'Enable public to insert script_downloads'
  ) THEN
    CREATE POLICY "Enable public to insert script_downloads"
      ON script_downloads
      FOR INSERT
      TO public
      WITH CHECK (true);
  END IF;
END $$;

-- Insert default categories
INSERT INTO script_categories (name, description)
VALUES 
  ('DBA Helper Queries', 'Queries to assist database administrators with common tasks'),
  ('Diagnostics', 'Scripts for diagnosing performance issues and errors'),
  ('Monitoring', 'Scripts for monitoring database health and performance'),
  ('Optimization', 'Scripts for optimizing database performance'),
  ('Security', 'Scripts for managing database security and access control'),
  ('Maintenance', 'Scripts for routine database maintenance tasks'),
  ('Utilities', 'Utility scripts for various database operations')
ON CONFLICT (name) DO NOTHING;

-- Insert default script types
INSERT INTO script_types (name, description)
VALUES 
  ('SQL', 'Standard SQL queries'),
  ('PL/pgSQL', 'PostgreSQL procedural language'),
  ('Python', 'Python scripts for database operations'),
  ('Shell', 'Shell scripts for database operations'),
  ('Other', 'Other script types')
ON CONFLICT (name) DO NOTHING;

-- Create a view for script details with ratings
CREATE OR REPLACE VIEW script_details AS
SELECT 
  s.id,
  s.title,
  s.description,
  s.script_content,
  s.original_url,
  s.category,
  s.script_type,
  s.published_at,
  s.created_at,
  s.updated_at,
  s.tags,
  s.formatted_content,
  s.author,
  s.views,
  s.downloads,
  s.status,
  COALESCE(AVG(r.rating), 0) as average_rating,
  COUNT(r.id) as rating_count,
  COUNT(c.id) as comment_count
FROM 
  redshift_scripts s
LEFT JOIN 
  script_ratings r ON s.id = r.script_id
LEFT JOIN 
  script_comments c ON s.id = c.script_id
GROUP BY 
  s.id;

-- Create a function to increment view count
CREATE OR REPLACE FUNCTION increment_script_view(script_id_param uuid, user_id_param uuid DEFAULT NULL, ip_address_param text DEFAULT NULL)
RETURNS void AS $$
BEGIN
  -- Insert view record
  INSERT INTO script_views (script_id, user_id, ip_address)
  VALUES (script_id_param, user_id_param, ip_address_param);
  
  -- Update view count
  UPDATE redshift_scripts
  SET views = views + 1
  WHERE id = script_id_param;
END;
$$ LANGUAGE plpgsql;

-- Create a function to increment download count
CREATE OR REPLACE FUNCTION increment_script_download(script_id_param uuid, user_id_param uuid DEFAULT NULL, ip_address_param text DEFAULT NULL)
RETURNS void AS $$
BEGIN
  -- Insert download record
  INSERT INTO script_downloads (script_id, user_id, ip_address)
  VALUES (script_id_param, user_id_param, ip_address_param);
  
  -- Update download count
  UPDATE redshift_scripts
  SET downloads = downloads + 1
  WHERE id = script_id_param;
END;
$$ LANGUAGE plpgsql;

-- Create a function to get related scripts
CREATE OR REPLACE FUNCTION get_related_scripts(script_id_param uuid, limit_param integer DEFAULT 5)
RETURNS SETOF redshift_scripts AS $$
BEGIN
  RETURN QUERY
  SELECT s.*
  FROM redshift_scripts s
  JOIN (
    SELECT category, script_type
    FROM redshift_scripts
    WHERE id = script_id_param
  ) as source ON s.category = source.category OR s.script_type = source.script_type
  WHERE s.id != script_id_param
  AND s.status = 'published'
  ORDER BY s.views DESC
  LIMIT limit_param;
END;
$$ LANGUAGE plpgsql;