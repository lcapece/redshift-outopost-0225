/*
  # Web Scraping Management System

  1. New Tables
    - scrape_urls: Stores URLs to be scraped
    - scrape_audit_logs: Tracks changes to scrape URLs
    - scrape_history: Records scraping attempts and results

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users

  3. Changes
    - Add functions for URL validation and audit logging
    - Add views for URL management
*/

-- Create enum type for scrape status
CREATE TYPE scrape_status AS ENUM ('pending', 'success', 'failed');

-- Create scrape_urls table
CREATE TABLE IF NOT EXISTS scrape_urls (
  url text PRIMARY KEY,
  date_added timestamptz DEFAULT now(),
  last_scrape_date timestamptz,
  next_scheduled_scrape timestamptz,
  status scrape_status DEFAULT 'pending',
  comments text,
  active boolean DEFAULT true,
  deleted_at timestamptz,
  created_by uuid REFERENCES auth.users(id),
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create scrape_audit_logs table
CREATE TABLE IF NOT EXISTS scrape_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text REFERENCES scrape_urls(url),
  action text NOT NULL,
  changes jsonb,
  performed_by uuid REFERENCES auth.users(id),
  performed_at timestamptz DEFAULT now()
);

-- Create scrape_history table
CREATE TABLE IF NOT EXISTS scrape_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text REFERENCES scrape_urls(url),
  start_time timestamptz DEFAULT now(),
  end_time timestamptz,
  status scrape_status NOT NULL,
  error_message text,
  pages_scraped integer DEFAULT 0,
  items_found integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE scrape_urls ENABLE ROW LEVEL SECURITY;
ALTER TABLE scrape_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE scrape_history ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON scrape_urls
  FOR SELECT
  TO authenticated
  USING (deleted_at IS NULL);

CREATE POLICY "Enable write access for authenticated users"
  ON scrape_urls
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
  ON scrape_urls
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable read access for authenticated users"
  ON scrape_audit_logs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON scrape_audit_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable read access for authenticated users"
  ON scrape_history
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON scrape_history
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create function to validate URL format
CREATE OR REPLACE FUNCTION is_valid_url(url text)
RETURNS boolean AS $$
BEGIN
  RETURN url ~* '^https?://[^\s/$.?#].[^\s]*$';
END;
$$ LANGUAGE plpgsql;

-- Create function to log audit events
CREATE OR REPLACE FUNCTION log_scrape_url_audit()
RETURNS trigger AS $$
BEGIN
  INSERT INTO scrape_audit_logs (url, action, changes, performed_by)
  VALUES (
    CASE
      WHEN TG_OP = 'DELETE' THEN OLD.url
      ELSE NEW.url
    END,
    TG_OP,
    CASE
      WHEN TG_OP = 'UPDATE' THEN jsonb_build_object(
        'old', to_jsonb(OLD),
        'new', to_jsonb(NEW)
      )
      WHEN TG_OP = 'INSERT' THEN to_jsonb(NEW)
      WHEN TG_OP = 'DELETE' THEN to_jsonb(OLD)
    END,
    CASE
      WHEN TG_OP = 'DELETE' THEN OLD.updated_by
      ELSE NEW.updated_by
    END
  );
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create audit triggers
CREATE TRIGGER scrape_url_audit_insert
  AFTER INSERT ON scrape_urls
  FOR EACH ROW
  EXECUTE FUNCTION log_scrape_url_audit();

CREATE TRIGGER scrape_url_audit_update
  AFTER UPDATE ON scrape_urls
  FOR EACH ROW
  EXECUTE FUNCTION log_scrape_url_audit();

CREATE TRIGGER scrape_url_audit_delete
  AFTER DELETE ON scrape_urls
  FOR EACH ROW
  EXECUTE FUNCTION log_scrape_url_audit();

-- Create view for active URLs with stats
CREATE OR REPLACE VIEW v_scrape_urls_with_stats AS
SELECT 
  u.url,
  u.date_added,
  u.last_scrape_date,
  u.next_scheduled_scrape,
  u.status,
  u.comments,
  u.active,
  COUNT(h.id) as total_scrapes,
  COUNT(CASE WHEN h.status = 'success' THEN 1 END) as successful_scrapes,
  COUNT(CASE WHEN h.status = 'failed' THEN 1 END) as failed_scrapes,
  MAX(h.items_found) as max_items_found,
  AVG(h.items_found) as avg_items_found,
  MAX(h.pages_scraped) as max_pages_scraped,
  AVG(EXTRACT(EPOCH FROM (h.end_time - h.start_time))) as avg_scrape_duration_seconds
FROM 
  scrape_urls u
LEFT JOIN 
  scrape_history h ON u.url = h.url
WHERE 
  u.deleted_at IS NULL
GROUP BY 
  u.url, u.date_added, u.last_scrape_date, u.next_scheduled_scrape, u.status, u.comments, u.active;

-- Create function to soft delete URLs
CREATE OR REPLACE FUNCTION soft_delete_scrape_url(url_param text, user_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE scrape_urls
  SET 
    deleted_at = now(),
    updated_by = user_id,
    updated_at = now(),
    active = false
  WHERE url = url_param;
END;
$$ LANGUAGE plpgsql;

-- Create function to bulk update URL status
CREATE OR REPLACE FUNCTION bulk_update_scrape_urls_status(urls text[], new_status scrape_status, user_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE scrape_urls
  SET 
    status = new_status,
    updated_by = user_id,
    updated_at = now()
  WHERE url = ANY(urls);
END;
$$ LANGUAGE plpgsql;

-- Create indexes for better performance
CREATE INDEX idx_scrape_urls_status ON scrape_urls(status);
CREATE INDEX idx_scrape_urls_active ON scrape_urls(active);
CREATE INDEX idx_scrape_urls_next_scheduled ON scrape_urls(next_scheduled_scrape);
CREATE INDEX idx_scrape_history_url ON scrape_history(url);
CREATE INDEX idx_scrape_history_status ON scrape_history(status);
CREATE INDEX idx_scrape_audit_logs_url ON scrape_audit_logs(url);
CREATE INDEX idx_scrape_audit_logs_performed_at ON scrape_audit_logs(performed_at);

-- Add constraint for URL format validation
ALTER TABLE scrape_urls
  ADD CONSTRAINT valid_url CHECK (is_valid_url(url));

-- Add constraint for next_scheduled_scrape
ALTER TABLE scrape_urls
  ADD CONSTRAINT future_schedule CHECK (next_scheduled_scrape > now());