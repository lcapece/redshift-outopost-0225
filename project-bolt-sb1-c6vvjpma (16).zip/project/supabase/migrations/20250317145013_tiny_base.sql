/*
  # Add Word Count Column to Redshift News

  1. Changes
    - Add word_count column to redshift_news table
    - Update existing records with calculated word count
    - Add function to calculate word count

  2. Security
    - Maintain existing RLS policies
*/

-- Add word_count column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'redshift_news' AND column_name = 'word_count'
  ) THEN
    ALTER TABLE redshift_news ADD COLUMN word_count integer DEFAULT 0;
  END IF;
END $$;

-- Create function to calculate word count
CREATE OR REPLACE FUNCTION calculate_word_count(text_content text)
RETURNS integer AS $$
BEGIN
  -- Split text on whitespace and count non-empty words
  RETURN array_length(
    regexp_split_to_array(
      regexp_replace(
        COALESCE(text_content, ''),
        '\s+',
        ' '
      ),
      '\s+'
    ),
    1
  );
EXCEPTION
  WHEN OTHERS THEN
    RETURN 0;
END;
$$ LANGUAGE plpgsql;

-- Update existing records with calculated word count
UPDATE redshift_news
SET word_count = calculate_word_count(content)
WHERE word_count = 0 OR word_count IS NULL;

-- Create trigger to automatically update word count on insert or update
CREATE OR REPLACE FUNCTION update_word_count()
RETURNS trigger AS $$
BEGIN
  NEW.word_count := calculate_word_count(NEW.content);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_word_count_trigger
  BEFORE INSERT OR UPDATE OF content
  ON redshift_news
  FOR EACH ROW
  EXECUTE FUNCTION update_word_count();