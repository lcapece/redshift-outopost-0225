-- Create imported_svv_data table
CREATE TABLE IF NOT EXISTS imported_svv_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL,
  schema_name text NOT NULL,
  table_name text NOT NULL,
  encrypted_data text NOT NULL,
  encryption_version integer NOT NULL DEFAULT 1,
  last_refresh_timestamp timestamptz NOT NULL DEFAULT now(),
  created_by_user uuid REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(database_name, schema_name, table_name)
);

-- Enable RLS
ALTER TABLE imported_svv_data ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON imported_svv_data
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert for authenticated users"
  ON imported_svv_data
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by_user);

CREATE POLICY "Enable update for data owners"
  ON imported_svv_data
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by_user)
  WITH CHECK (auth.uid() = created_by_user);

-- Create updated_at trigger
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON imported_svv_data
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes
CREATE INDEX idx_imported_svv_data_composite_key 
  ON imported_svv_data(database_name, schema_name, table_name);

CREATE INDEX idx_imported_svv_data_refresh 
  ON imported_svv_data(last_refresh_timestamp);

CREATE INDEX idx_imported_svv_data_created_by 
  ON imported_svv_data(created_by_user);