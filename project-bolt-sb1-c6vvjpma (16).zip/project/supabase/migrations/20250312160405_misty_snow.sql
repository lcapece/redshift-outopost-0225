/*
  # Sample SVV_TABLE_INFO Data Migration

  1. Overview
    Creates and populates tables with sample SVV_TABLE_INFO data
    for testing and development purposes.

  2. Changes
    - Creates sample_svv_table_info table in public schema
    - Adds random number generation function
    - Populates table with 50 diverse sample records
    - Generates summary reports

  3. Security
    - Table is created in public schema
    - Appropriate RLS policies are added
*/

-- Create sample table for SVV_TABLE_INFO data
CREATE TABLE IF NOT EXISTS sample_svv_table_info (
    database_name text NOT NULL,
    schema_name text NOT NULL,
    table_name text NOT NULL,
    encoded boolean NOT NULL,
    diststyle text NOT NULL,
    dist_key text,
    sortkey1 text,
    sortkey1_enc text,
    sortkey_num integer NOT NULL,
    size_gb numeric NOT NULL,
    pct_empty numeric NOT NULL,
    unsorted_pct numeric NOT NULL,
    stats_off numeric NOT NULL,
    tbl_rows bigint NOT NULL,
    skew_sortkey1 numeric NOT NULL,
    skew_rows numeric NOT NULL,
    estimated_visible_rows bigint NOT NULL,
    risk_event text,
    last_analyze timestamptz
);

-- Create a function to generate random numbers within a range
CREATE OR REPLACE FUNCTION random_between(low INT, high INT) 
RETURNS INT AS $$
BEGIN
    RETURN floor(random() * (high - low + 1) + low);
END;
$$ LANGUAGE plpgsql;

-- Insert sample table data
INSERT INTO sample_svv_table_info (
    database_name,
    schema_name,
    table_name,
    encoded,
    diststyle,
    dist_key,
    sortkey1,
    sortkey1_enc,
    sortkey_num,
    size_gb,
    pct_empty,
    unsorted_pct,
    stats_off,
    tbl_rows,
    skew_sortkey1,
    skew_rows,
    estimated_visible_rows,
    risk_event,
    last_analyze
)
SELECT
    'DATAWAREHOUSE' as database_name,
    CASE 
        WHEN category <= 20 THEN 'analytics'
        WHEN category <= 35 THEN 'staging'
        ELSE 'reporting'
    END as schema_name,
    CASE 
        WHEN category <= 20 THEN 
            CASE 
                WHEN category <= 10 THEN 'fact_' || names.fact_name
                ELSE 'dim_' || names.dim_name
            END
        WHEN category <= 35 THEN 'stage_' || names.stage_name
        ELSE 'v_' || names.view_name
    END as table_name,
    CASE WHEN category % 5 = 0 THEN false ELSE true END as encoded,
    CASE 
        WHEN category % 4 = 0 THEN 'EVEN'
        WHEN category % 4 = 1 THEN 'KEY(id)'
        WHEN category % 4 = 2 THEN 'ALL'
        ELSE 'AUTO'
    END as diststyle,
    CASE 
        WHEN category % 4 = 1 THEN 
            CASE 
                WHEN category <= 10 THEN 'date_id'
                WHEN category <= 20 THEN 'product_id'
                ELSE 'id'
            END
        ELSE NULL
    END as dist_key,
    CASE 
        WHEN category % 3 = 0 THEN 'date_id'
        WHEN category % 3 = 1 THEN 'id'
        ELSE NULL
    END as sortkey1,
    CASE 
        WHEN category % 3 != 2 THEN 'az64'
        ELSE NULL
    END as sortkey1_enc,
    CASE 
        WHEN category % 3 = 2 THEN 0
        ELSE random_between(1, 3)
    END as sortkey_num,
    CASE 
        WHEN category <= 10 THEN random_between(100, 1000)::float / 10
        WHEN category <= 20 THEN random_between(10, 100)::float / 10
        ELSE random_between(1, 10)::float / 10
    END as size_gb,
    random_between(0, 15) as pct_empty,
    CASE 
        WHEN category % 3 = 0 THEN random_between(50, 90)
        ELSE random_between(0, 30)
    END as unsorted_pct,
    CASE 
        WHEN category % 4 = 0 THEN random_between(50, 90)
        ELSE random_between(0, 20)
    END as stats_off,
    CASE 
        WHEN category <= 10 THEN random_between(100000000, 1000000000)
        WHEN category <= 20 THEN random_between(1000000, 10000000)
        WHEN category <= 35 THEN random_between(100000, 1000000)
        ELSE random_between(10000, 100000)
    END as tbl_rows,
    CASE 
        WHEN category % 3 = 0 THEN random_between(400, 800)::float / 100
        ELSE random_between(100, 300)::float / 100
    END as skew_sortkey1,
    CASE 
        WHEN category % 4 = 0 THEN random_between(400, 800)::float / 100
        ELSE random_between(100, 300)::float / 100
    END as skew_rows,
    CASE 
        WHEN category <= 10 THEN random_between(90000000, 950000000)
        WHEN category <= 20 THEN random_between(900000, 9500000)
        WHEN category <= 35 THEN random_between(90000, 950000)
        ELSE random_between(9000, 95000)
    END as estimated_visible_rows,
    CASE 
        WHEN category % 5 = 0 THEN 'STALE_STATS'
        WHEN category % 5 = 1 THEN 'HIGH_SKEW'
        WHEN category % 5 = 2 THEN 'MISSING_STATS'
        WHEN category % 5 = 3 THEN 'UNEVEN_SLICES'
        ELSE NULL
    END as risk_event,
    CASE 
        WHEN category % 4 = 0 THEN NOW() - INTERVAL '45 days'
        WHEN category % 4 = 1 THEN NOW() - INTERVAL '7 days'
        WHEN category % 4 = 2 THEN NOW() - INTERVAL '1 day'
        ELSE NULL
    END as last_analyze
FROM 
    (SELECT generate_series(1, 50) as category) series
CROSS JOIN (
    SELECT 
        unnest(ARRAY[
            'sales', 'orders', 'transactions', 'inventory', 'shipments',
            'returns', 'payments', 'clickstream', 'events', 'metrics'
        ]) as fact_name,
        unnest(ARRAY[
            'customer', 'product', 'store', 'employee', 'vendor',
            'promotion', 'category', 'region', 'time', 'status'
        ]) as dim_name,
        unnest(ARRAY[
            'customer_raw', 'order_raw', 'product_raw', 'sales_raw', 'inventory_raw',
            'shipping_raw', 'vendor_raw', 'employee_raw', 'store_raw', 'event_raw'
        ]) as stage_name,
        unnest(ARRAY[
            'daily_sales', 'customer_metrics', 'product_performance', 'store_analytics', 'inventory_status',
            'shipping_summary', 'vendor_performance', 'employee_stats', 'order_summary', 'event_analytics'
        ]) as view_name
) names;

-- Enable RLS
ALTER TABLE sample_svv_table_info ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Enable public read access for sample data"
  ON sample_svv_table_info
  FOR SELECT
  TO public
  USING (true);

-- Create summary views
CREATE VIEW v_distribution_summary AS
SELECT 
    diststyle,
    COUNT(*) as table_count,
    ROUND(AVG(size_gb)::numeric, 2) as avg_size_gb,
    ROUND(AVG(tbl_rows)::numeric, 0) as avg_rows
FROM sample_svv_table_info
GROUP BY diststyle;

CREATE VIEW v_performance_issues AS
SELECT 
    table_name,
    ARRAY_AGG(issue) as issues
FROM (
    SELECT 
        table_name,
        CASE 
            WHEN stats_off > 20 THEN 'Stale statistics (stats_off > 20)'
            WHEN skew_rows > 4 THEN 'High row skew (> 4)'
            WHEN unsorted_pct > 50 THEN 'High unsorted percentage (> 50%)'
            WHEN last_analyze IS NULL THEN 'Missing statistics'
            WHEN last_analyze < NOW() - INTERVAL '30 days' THEN 'Statistics older than 30 days'
        END as issue
    FROM sample_svv_table_info
    WHERE 
        stats_off > 20 OR
        skew_rows > 4 OR
        unsorted_pct > 50 OR
        last_analyze IS NULL OR
        last_analyze < NOW() - INTERVAL '30 days'
) issues
WHERE issue IS NOT NULL
GROUP BY table_name;

CREATE VIEW v_statistics_summary AS
SELECT 
    CASE 
        WHEN last_analyze IS NULL THEN 'Missing statistics'
        WHEN last_analyze < NOW() - INTERVAL '30 days' THEN 'Stale statistics (>30 days)'
        WHEN last_analyze < NOW() - INTERVAL '7 days' THEN 'Moderate statistics (7-30 days)'
        ELSE 'Fresh statistics (<7 days)'
    END as stats_status,
    COUNT(*) as table_count
FROM sample_svv_table_info
GROUP BY 
    CASE 
        WHEN last_analyze IS NULL THEN 'Missing statistics'
        WHEN last_analyze < NOW() - INTERVAL '30 days' THEN 'Stale statistics (>30 days)'
        WHEN last_analyze < NOW() - INTERVAL '7 days' THEN 'Moderate statistics (7-30 days)'
        ELSE 'Fresh statistics (<7 days)'
    END;

-- Create indexes for better query performance
CREATE INDEX idx_sample_svv_table_info_schema_table 
ON sample_svv_table_info(schema_name, table_name);

CREATE INDEX idx_sample_svv_table_info_diststyle 
ON sample_svv_table_info(diststyle);

CREATE INDEX idx_sample_svv_table_info_last_analyze 
ON sample_svv_table_info(last_analyze);