/*
  # Create Redshift News Table

  1. New Tables
    - `redshift_news`
      - `id` (uuid, primary key)
      - `title` (text, not null)
      - `originalTitle` (text)
      - `summary` (text, not null)
      - `content` (text, not null)
      - `url` (text, not null)
      - `source` (text, not null)
      - `publishedAt` (text, not null)
      - `imageUrl` (text)
      - `relatedArticles` (jsonb)
      - `createdAt` (timestamptz, default now())
  2. Security
    - Enable RLS on `redshift_news` table
    - Add policy for public access to read news articles
    - Add policy for authenticated users to manage news articles
*/

-- Create redshift_news table
CREATE TABLE IF NOT EXISTS redshift_news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  "originalTitle" text,
  summary text NOT NULL,
  content text NOT NULL,
  url text NOT NULL,
  source text NOT NULL,
  "publishedAt" text NOT NULL,
  "imageUrl" text,
  "relatedArticles" jsonb,
  "createdAt" timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE redshift_news ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable public read access"
  ON redshift_news
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage news"
  ON redshift_news
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);