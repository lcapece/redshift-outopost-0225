/*
  # Initial Database Schema

  1. Tables
    - redshift_simulations: Stores query simulations
    - simulation_metrics: Stores metrics for each simulation
    - redshift_news: Stores news articles
    - redshift_scripts: Stores SQL scripts library
    - forum_threads: Stores forum discussions
    - forum_replies: Stores thread replies

  2. Security
    - Enable RLS on all tables
    - Add policies for public/authenticated access
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  -- Drop policies for redshift_news
  DROP POLICY IF EXISTS "Enable public read access for published articles" ON public.redshift_news;
  DROP POLICY IF EXISTS "Enable public read access" ON public.redshift_news;
  
  -- Drop policies for redshift_simulations
  DROP POLICY IF EXISTS "Enable public read access" ON public.redshift_simulations;
  
  -- Drop policies for simulation_metrics
  DROP POLICY IF EXISTS "Enable public read access" ON public.simulation_metrics;
  
  -- Drop policies for redshift_scripts
  DROP POLICY IF EXISTS "Enable public read access for published scripts" ON public.redshift_scripts;
  
  -- Drop policies for forum_threads
  DROP POLICY IF EXISTS "Enable public read access" ON public.forum_threads;
  
  -- Drop policies for forum_replies
  DROP POLICY IF EXISTS "Enable public read access" ON public.forum_replies;
END $$;

-- Create redshift_simulations table
CREATE TABLE IF NOT EXISTS redshift_simulations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  llm_model text NOT NULL,
  sql_query text NOT NULL,
  query_plan text NOT NULL,
  complexity integer NOT NULL
);

-- Create simulation_metrics table
CREATE TABLE IF NOT EXISTS simulation_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  simulation_id uuid REFERENCES redshift_simulations(id) ON DELETE CASCADE,
  dbname text NOT NULL,
  schemaname text NOT NULL,
  tablename text NOT NULL,
  encoded boolean NOT NULL,
  diststyle text NOT NULL,
  dist_key text,
  sortkey1 text,
  sortkey1_enc text,
  sortkey_num integer NOT NULL,
  size_gb numeric NOT NULL,
  pct_empty numeric NOT NULL,
  unsorted_pct numeric NOT NULL,
  stats_off numeric NOT NULL,
  tbl_rows bigint NOT NULL,
  skew_sortkey1 numeric NOT NULL,
  skew_rows numeric NOT NULL,
  estimated_visible_rows bigint NOT NULL,
  risk_event text
);

-- Create redshift_news table
CREATE TABLE IF NOT EXISTS redshift_news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  originalTitle text,
  summary text NOT NULL,
  content text NOT NULL,
  url text NOT NULL,
  source text NOT NULL,
  publishedAt text NOT NULL,
  imageUrl text,
  secondaryImageUrl text,
  relatedArticles jsonb,
  status text DEFAULT 'draft',
  tags text[],
  word_count integer DEFAULT 0,
  processed boolean DEFAULT false,
  createdAt timestamptz DEFAULT now()
);

-- Create redshift_scripts table
CREATE TABLE IF NOT EXISTS redshift_scripts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  script_content text NOT NULL,
  original_url text,
  category text NOT NULL,
  script_type text NOT NULL,
  published_at date DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  tags text[],
  formatted_content text,
  author text,
  views integer DEFAULT 0,
  downloads integer DEFAULT 0,
  status text DEFAULT 'published'
);

-- Create forum_threads table
CREATE TABLE IF NOT EXISTS forum_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  category_id uuid,
  tags text[],
  is_pinned boolean DEFAULT false,
  is_locked boolean DEFAULT false,
  view_count integer DEFAULT 0,
  like_count integer DEFAULT 0,
  reply_count integer DEFAULT 0,
  last_reply_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create forum_replies table
CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid REFERENCES forum_threads(id) ON DELETE CASCADE,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  content text NOT NULL,
  is_solution boolean DEFAULT false,
  like_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE redshift_simulations ENABLE ROW LEVEL SECURITY;
ALTER TABLE simulation_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE redshift_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE redshift_scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Enable read access for simulations"
  ON redshift_simulations FOR SELECT TO public USING (true);

CREATE POLICY "Enable read access for metrics"
  ON simulation_metrics FOR SELECT TO public USING (true);

CREATE POLICY "Enable read access for published news"
  ON redshift_news FOR SELECT TO public USING (status = 'published');

CREATE POLICY "Enable read access for published scripts"
  ON redshift_scripts FOR SELECT TO public USING (status = 'published');

CREATE POLICY "Enable read access for threads"
  ON forum_threads FOR SELECT TO public USING (true);

CREATE POLICY "Enable read access for replies"
  ON forum_replies FOR SELECT TO public USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_simulation_metrics_simulation_id ON simulation_metrics(simulation_id);
CREATE INDEX IF NOT EXISTS idx_redshift_news_status ON redshift_news(status);
CREATE INDEX IF NOT EXISTS idx_redshift_scripts_category ON redshift_scripts(category);
CREATE INDEX IF NOT EXISTS idx_forum_threads_category_id ON forum_threads(category_id);
CREATE INDEX IF NOT EXISTS idx_forum_replies_thread_id ON forum_replies(thread_id);