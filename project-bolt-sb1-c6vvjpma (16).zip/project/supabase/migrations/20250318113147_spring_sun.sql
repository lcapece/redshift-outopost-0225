/*
  # Create Content Sources Table

  1. New Tables
    - `content_sources` - Stores content source configurations and metadata
      - Primary key columns: id (uuid)
      - Required columns: name, url, type, category, etc.
      - Timestamps: created_at, updated_at

  2. Security
    - Enable RLS
    - Add policies for public/authenticated access
*/

-- Create content_sources table
CREATE TABLE IF NOT EXISTS content_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  url text NOT NULL,
  type text NOT NULL CHECK (type IN ('blog', 'documentation', 'video', 'forum')),
  category text NOT NULL,
  quality_score integer NOT NULL DEFAULT 5 CHECK (quality_score >= 1 AND quality_score <= 5),
  last_scraped timestamptz,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX idx_content_sources_status ON content_sources(status);
CREATE INDEX idx_content_sources_type ON content_sources(type);
CREATE INDEX idx_content_sources_created_at ON content_sources(created_at DESC);

-- Enable RLS
ALTER TABLE content_sources ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON content_sources
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON content_sources
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_content_sources_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updated_at
CREATE TRIGGER update_content_sources_updated_at
  BEFORE UPDATE ON content_sources
  FOR EACH ROW
  EXECUTE FUNCTION update_content_sources_updated_at();

-- Insert initial sample data
INSERT INTO content_sources (name, url, type, category, quality_score, status)
VALUES 
  (
    'AWS Redshift Documentation',
    'https://docs.aws.amazon.com/redshift/',
    'documentation',
    'official',
    5,
    'active'
  ),
  (
    'AWS Database Blog - Redshift',
    'https://aws.amazon.com/blogs/database/tag/amazon-redshift/',
    'blog',
    'official',
    5,
    'active'
  ),
  (
    'AWS re:Invent Redshift Sessions',
    'https://www.youtube.com/playlist?list=PL2yQDdvlhXf9vpZZnNokMpyJOlLIKhcEY',
    'video',
    'official',
    5,
    'active'
  )
ON CONFLICT DO NOTHING;