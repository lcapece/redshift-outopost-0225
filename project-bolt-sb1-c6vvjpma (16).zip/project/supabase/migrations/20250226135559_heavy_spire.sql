/*
  # Fix RLS Policies for Public Access

  1. Changes
    - Drop existing policies
    - Create new policies allowing public access for all operations
    - Ensure both authenticated and anonymous users can perform all operations

  2. Security
    - Enable RLS on tables
    - Grant public access for all operations
    - This is safe because the data is not sensitive and is meant to be publicly accessible
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Enable public read access" ON redshift_simulations;
DROP POLICY IF EXISTS "Enable authenticated write access" ON redshift_simulations;
DROP POLICY IF EXISTS "Enable authenticated delete access" ON redshift_simulations;
DROP POLICY IF EXISTS "Enable public read access" ON simulation_metrics;
DROP POLICY IF EXISTS "Enable authenticated write access" ON simulation_metrics;
DROP POLICY IF EXISTS "Enable authenticated delete access" ON simulation_metrics;

-- Create new unified policies for redshift_simulations
CREATE POLICY "Enable full public access"
  ON redshift_simulations
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);

-- Create new unified policies for simulation_metrics
CREATE POLICY "Enable full public access"
  ON simulation_metrics
  FOR ALL
  TO public
  USING (true)
  WITH CHECK (true);