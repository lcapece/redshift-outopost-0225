-- Create SVV data staging table
CREATE TABLE IF NOT EXISTS svv_data_staging (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  database_name text NOT NULL,
  schema_name text NOT NULL,
  table_name text NOT NULL,
  encoded boolean NOT NULL,
  diststyle text NOT NULL,
  sortkey1 text,
  sortkey1_enc text,
  sortkey_num integer NOT NULL,
  size_gb numeric NOT NULL,
  pct_empty numeric NOT NULL,
  unsorted_pct numeric NOT NULL,
  stats_off numeric NOT NULL,
  tbl_rows bigint NOT NULL,
  skew_sortkey1 numeric NOT NULL,
  skew_rows numeric NOT NULL,
  estimated_visible_rows bigint NOT NULL,
  risk_event text,
  created_by_user uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE svv_data_staging ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable access for authenticated users"
  ON svv_data_staging
  FOR ALL
  TO authenticated
  USING (auth.uid() = created_by_user)
  WITH CHECK (auth.uid() = created_by_user);

-- Create upsert function
CREATE OR REPLACE FUNCTION upsert_svv_data(user_id uuid)
RETURNS TABLE (
  original_count integer,
  inserted_count integer,
  final_count integer
) LANGUAGE plpgsql AS $$
DECLARE
  v_original_count integer;
  v_inserted_count integer;
  v_final_count integer;
BEGIN
  -- Get original count
  SELECT COUNT(*) INTO v_original_count
  FROM imported_svv_data
  WHERE created_by_user = user_id;

  -- Perform upsert
  WITH upserted AS (
    INSERT INTO imported_svv_data (
      database_name, schema_name, table_name, encoded, diststyle,
      sortkey1, sortkey1_enc, sortkey_num, size_gb, pct_empty,
      unsorted_pct, stats_off, tbl_rows, skew_sortkey1, skew_rows,
      estimated_visible_rows, risk_event, created_by_user
    )
    SELECT
      database_name, schema_name, table_name, encoded, diststyle,
      sortkey1, sortkey1_enc, sortkey_num, size_gb, pct_empty,
      unsorted_pct, stats_off, tbl_rows, skew_sortkey1, skew_rows,
      estimated_visible_rows, risk_event, created_by_user
    FROM svv_data_staging
    WHERE created_by_user = user_id
    ON CONFLICT (database_name, schema_name, table_name, created_by_user)
    DO UPDATE SET
      encoded = EXCLUDED.encoded,
      diststyle = EXCLUDED.diststyle,
      sortkey1 = EXCLUDED.sortkey1,
      sortkey1_enc = EXCLUDED.sortkey1_enc,
      sortkey_num = EXCLUDED.sortkey_num,
      size_gb = EXCLUDED.size_gb,
      pct_empty = EXCLUDED.pct_empty,
      unsorted_pct = EXCLUDED.unsorted_pct,
      stats_off = EXCLUDED.stats_off,
      tbl_rows = EXCLUDED.tbl_rows,
      skew_sortkey1 = EXCLUDED.skew_sortkey1,
      skew_rows = EXCLUDED.skew_rows,
      estimated_visible_rows = EXCLUDED.estimated_visible_rows,
      risk_event = EXCLUDED.risk_event
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_inserted_count FROM upserted;

  -- Get final count
  SELECT COUNT(*) INTO v_final_count
  FROM imported_svv_data
  WHERE created_by_user = user_id;

  -- Clean up staging table
  DELETE FROM svv_data_staging WHERE created_by_user = user_id;

  RETURN QUERY SELECT v_original_count, v_inserted_count, v_final_count;
END;
$$;

-- Create unique constraint for upsert
ALTER TABLE imported_svv_data 
ADD CONSTRAINT unique_table_per_user 
UNIQUE (database_name, schema_name, table_name, created_by_user);