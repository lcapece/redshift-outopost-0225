/*
  # Script Management System

  1. New Tables
    - script_sources: Tracks URLs and sources for script content
    - script_contents: Stores extracted script content
    - script_versions: Maintains version history
    - scrape_logs: Records scraping activity and results

  2. Security
    - Enable RLS on all tables
    - Add policies for public/authenticated access

  3. Changes
    - Add tracking for script sources and versions
    - Add logging for scrape operations
*/

-- Create script_sources table
CREATE TABLE IF NOT EXISTS script_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('github', 'webpage', 'api', 'other')),
  priority text NOT NULL CHECK (priority IN ('high', 'medium', 'low')),
  enabled boolean DEFAULT true,
  last_scraped timestamptz,
  scrape_frequency integer NOT NULL DEFAULT 24, -- in hours
  status text NOT NULL CHECK (status IN ('pending', 'completed', 'failed')),
  error_message text,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create script_contents table
CREATE TABLE IF NOT EXISTS script_contents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid REFERENCES script_sources(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  language text NOT NULL CHECK (language IN ('sql', 'python', 'shell', 'other')),
  description text NOT NULL,
  tags text[],
  version integer NOT NULL DEFAULT 1,
  extracted_at timestamptz NOT NULL,
  status text NOT NULL CHECK (status IN ('pending_validation', 'validated', 'invalid')),
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create script_versions table
CREATE TABLE IF NOT EXISTS script_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  script_id uuid REFERENCES script_contents(id) ON DELETE CASCADE,
  content text NOT NULL,
  version integer NOT NULL,
  changed_by text NOT NULL,
  change_reason text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(script_id, version)
);

-- Create scrape_logs table
CREATE TABLE IF NOT EXISTS scrape_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id uuid REFERENCES script_sources(id) ON DELETE CASCADE,
  start_time timestamptz NOT NULL,
  end_time timestamptz,
  status text NOT NULL CHECK (status IN ('in_progress', 'completed', 'failed')),
  scripts_found integer NOT NULL DEFAULT 0,
  scripts_extracted integer NOT NULL DEFAULT 0,
  scripts_updated integer NOT NULL DEFAULT 0,
  error_message text,
  metadata jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE script_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_contents ENABLE ROW LEVEL SECURITY;
ALTER TABLE script_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE scrape_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for script_sources
CREATE POLICY "Enable public read access for script_sources"
  ON script_sources
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage script_sources"
  ON script_sources
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for script_contents
CREATE POLICY "Enable public read access for script_contents"
  ON script_contents
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage script_contents"
  ON script_contents
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for script_versions
CREATE POLICY "Enable public read access for script_versions"
  ON script_versions
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable authenticated users to manage script_versions"
  ON script_versions
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create policies for scrape_logs
CREATE POLICY "Enable authenticated users to view scrape_logs"
  ON scrape_logs
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable authenticated users to manage scrape_logs"
  ON scrape_logs
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better performance
CREATE INDEX idx_script_sources_url ON script_sources(url);
CREATE INDEX idx_script_sources_status ON script_sources(status);
CREATE INDEX idx_script_contents_source_id ON script_contents(source_id);
CREATE INDEX idx_script_contents_language ON script_contents(language);
CREATE INDEX idx_script_contents_status ON script_contents(status);
CREATE INDEX idx_script_versions_script_id ON script_versions(script_id);
CREATE INDEX idx_scrape_logs_source_id ON scrape_logs(source_id);
CREATE INDEX idx_scrape_logs_status ON scrape_logs(status);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_script_sources_updated_at
  BEFORE UPDATE ON script_sources
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_script_contents_updated_at
  BEFORE UPDATE ON script_contents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();