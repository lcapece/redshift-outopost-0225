/*
  # Article Source Index System

  1. New Tables
    - `article_sources` - Tracks original article sources and metadata
    - `article_duplicates` - Records duplicate content relationships
    - `article_source_index` - Maintains master index of all content

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users

  3. Functions
    - Add functions for content hash generation
    - Add functions for duplicate detection
    - Add functions for index maintenance
*/

-- Create article_sources table
CREATE TABLE IF NOT EXISTS article_sources (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL UNIQUE,
  domain text NOT NULL,
  title text NOT NULL,
  authors text[],
  publication_date timestamptz NOT NULL,
  content_hash text NOT NULL,
  metadata jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  last_validated_at timestamptz DEFAULT now()
);

-- Create article_duplicates table
CREATE TABLE IF NOT EXISTS article_duplicates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  original_article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  duplicate_url text NOT NULL,
  duplicate_title text NOT NULL,
  duplicate_source text NOT NULL,
  similarity_score numeric NOT NULL,
  detection_method text NOT NULL,
  created_at timestamptz DEFAULT now(),
  metadata jsonb
);

-- Create article_source_index table
CREATE TABLE IF NOT EXISTS article_source_index (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id uuid REFERENCES redshift_news(id) ON DELETE CASCADE,
  source_id uuid REFERENCES article_sources(id) ON DELETE CASCADE,
  content_hash text NOT NULL,
  last_verified_at timestamptz DEFAULT now(),
  is_canonical boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(content_hash)
);

-- Enable RLS
ALTER TABLE article_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_duplicates ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_source_index ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON article_sources
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON article_sources
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON article_duplicates
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON article_duplicates
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable read access for all users"
  ON article_source_index
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable write access for authenticated users"
  ON article_source_index
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes
CREATE INDEX idx_article_sources_domain ON article_sources(domain);
CREATE INDEX idx_article_sources_hash ON article_sources(content_hash);
CREATE INDEX idx_article_sources_date ON article_sources(publication_date);
CREATE INDEX idx_article_duplicates_original ON article_duplicates(original_article_id);
CREATE INDEX idx_article_source_index_hash ON article_source_index(content_hash);
CREATE INDEX idx_article_source_index_article ON article_source_index(article_id);

-- Create function to generate content hash
CREATE OR REPLACE FUNCTION generate_content_hash(
  url text,
  title text,
  content text
) RETURNS text AS $$
BEGIN
  RETURN encode(
    sha256(
      CONCAT(
        COALESCE(url, ''),
        COALESCE(title, ''),
        COALESCE(substring(content, 1, 1000), '')
      )::bytea
    ),
    'hex'
  );
END;
$$ LANGUAGE plpgsql;

-- Create function to check for duplicates
CREATE OR REPLACE FUNCTION check_article_duplicates(
  url text,
  title text,
  content text
) RETURNS TABLE (
  is_duplicate boolean,
  original_id uuid,
  similarity_score numeric
) AS $$
DECLARE
  content_hash text;
BEGIN
  -- Generate content hash
  content_hash := generate_content_hash(url, title, content);
  
  -- Check for exact matches
  RETURN QUERY
  SELECT 
    true as is_duplicate,
    asi.article_id as original_id,
    1.0 as similarity_score
  FROM article_source_index asi
  WHERE asi.content_hash = content_hash
  LIMIT 1;
  
  -- If no exact match found, return false
  IF NOT FOUND THEN
    RETURN QUERY SELECT false, NULL::uuid, 0.0;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Create function to add article to index
CREATE OR REPLACE FUNCTION index_article(
  article_id uuid,
  url text,
  title text,
  content text,
  domain text,
  authors text[],
  publication_date timestamptz
) RETURNS uuid AS $$
DECLARE
  source_id uuid;
  content_hash text;
BEGIN
  -- Generate content hash
  content_hash := generate_content_hash(url, title, content);
  
  -- Create article source
  INSERT INTO article_sources (
    url,
    domain,
    title,
    authors,
    publication_date,
    content_hash
  ) VALUES (
    url,
    domain,
    title,
    authors,
    publication_date,
    content_hash
  )
  RETURNING id INTO source_id;
  
  -- Add to source index
  INSERT INTO article_source_index (
    article_id,
    source_id,
    content_hash
  ) VALUES (
    article_id,
    source_id,
    content_hash
  );
  
  RETURN source_id;
END;
$$ LANGUAGE plpgsql;

-- Create function to validate index entries
CREATE OR REPLACE FUNCTION validate_index_entries(
  older_than interval DEFAULT '7 days'
) RETURNS void AS $$
DECLARE
  invalid_entry record;
BEGIN
  -- Find and process invalid entries
  FOR invalid_entry IN
    SELECT asi.*, rn.url
    FROM article_source_index asi
    JOIN redshift_news rn ON asi.article_id = rn.id
    WHERE asi.last_verified_at < now() - older_than
  LOOP
    -- Verify article still exists
    IF NOT EXISTS (
      SELECT 1 FROM redshift_news WHERE id = invalid_entry.article_id
    ) THEN
      -- Delete invalid index entry
      DELETE FROM article_source_index WHERE id = invalid_entry.id;
      -- Log deletion
      INSERT INTO article_duplicates (
        original_article_id,
        duplicate_url,
        duplicate_title,
        duplicate_source,
        similarity_score,
        detection_method,
        metadata
      ) VALUES (
        invalid_entry.article_id,
        invalid_entry.url,
        'Deleted Article',
        'Unknown',
        1.0,
        'index_validation',
        jsonb_build_object(
          'reason', 'article_deleted',
          'validated_at', now()
        )
      );
    ELSE
      -- Update verification timestamp
      UPDATE article_source_index
      SET last_verified_at = now()
      WHERE id = invalid_entry.id;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create function to clean up old index entries
CREATE OR REPLACE FUNCTION cleanup_old_index_entries(
  older_than interval DEFAULT '90 days'
) RETURNS integer AS $$
DECLARE
  deleted_count integer;
BEGIN
  WITH deleted AS (
    DELETE FROM article_source_index
    WHERE 
      last_verified_at < now() - older_than
      AND NOT is_canonical
    RETURNING id
  )
  SELECT count(*) INTO deleted_count FROM deleted;
  
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;