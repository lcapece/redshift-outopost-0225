/*
  # Add status column to redshift_news table

  1. Changes
    - Add status column to redshift_news table if it doesn't exist
    - Set default value to 'published'
  2. Security
    - Update policies to use the status column
*/

-- Check if status column exists and add it if it doesn't
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_schema = 'public' AND table_name = 'redshift_news' AND column_name = 'status'
  ) THEN
    ALTER TABLE redshift_news ADD COLUMN status text DEFAULT 'published';
  END IF;
END $$;

-- Update policies to use the status column
DO $$ 
BEGIN
  -- Drop the temporary policy if it exists
  DROP POLICY IF EXISTS "Enable public access to redshift_news" ON redshift_news;
  
  -- Create the proper policy using the status column
  IF NOT EXISTS (
    SELECT FROM pg_policies 
    WHERE tablename = 'redshift_news' AND policyname = 'Enable public read access for published articles'
  ) THEN
    EXECUTE 'CREATE POLICY "Enable public read access for published articles" ON redshift_news FOR SELECT TO public USING (status = ''published'')';
  END IF;
END $$;